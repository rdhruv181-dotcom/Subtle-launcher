# Margin — a frosted-glass student launcher (v0.3.0)

Build: open in Android Studio (JDK 17), or push to GitHub and use the included Actions workflow.
Then press Home → choose **Margin** → **Always**.

## Where things are
Swipe down (or tap the greeting) opens the **Quick panel**: capture a task / note / reminder / idea / link and jump to
Tasks, Notes, Reminders, Planner, Focus, Study, Journal, Screen time, Tools and Settings.
Swipe up = app drawer. Long-press home = settings. Tap the clock = Planner.

## Features
- Tasks: quick add, due date/time, priority, categories, subjects, subtasks, repeat, reminders, overdue markers, progress.
- Notes: autosave, pin, search, folders, subjects, checklists, headings and bullets.
- Reminders: one-off/recurring, assignment/exam types, persistent, snooze, done, custom sound, survives reboot.
- Planner: month / week / day views, weekly timetable, events, exams, holidays, countdowns, study time.
- Focus: Pomodoro 25/5, 50/10, custom; task + subject; ambient noise; DND; streaks; history; break notifications.
- Study tracker: daily/weekly goals, 7-day chart, per-subject totals, manual logging.
- Journal: four daily prompts, autosave. Screen time: usage, top apps, unlocks, weekly report, goal.
- Tools: calculator, stopwatch, timer (rings via alarm), unit converter, clipboard, QR (opens camera), files.
- Settings: theme, accent, icon/text size, clock weight, home sections, gestures, backup/restore (JSON).

## Android limits (honest list)
- Apps can't be force-blocked without Accessibility/overlay powers. Focus mode silences notifications (needs Do Not
  Disturb access) and asks before opening your chosen distracting apps *from Margin*.
- Screen time needs Usage access (granted by you in system settings). Unlocks may read 0 on some devices.
- Exact alarms need the "Alarms & reminders" permission on Android 12+; without it reminders still fire, slightly late.
- Ambient sound may stop if the system kills the app in the background.
- Google Calendar sync and rich-text beyond headings/bullets are not included. Data is stored as local JSON files
  (not Room) to keep the build small and dependency-free.
- Not compiled or run by me; the pure logic has unit tests (`gradle testDebugUnitTest`).


## v0.3.0 — Frosted Liquid Glass redesign
- One design system (`ui/theme/Theme.kt`, `ui/components/Glass.kt`, `Icons.kt`): ambient navy/indigo/violet/teal background,
  translucent glass surfaces with thin light borders, line icons drawn in code, springy press feedback.
- Home follows the reference: greeting + Focus button, big clock, UP NEXT card, swipeable Tasks / Focus / Reminder
  (/ Exam / Quick note) cards with dots, glass search bar, four coloured shortcuts (customisable) above the dock.
- Drawer: complete A–Z list (list / grid / text), scrollbar thumb, A–Z index, glass search. Recent apps removed.
- Tasks and reminders use one glass calendar: any date, shortcuts, optional time, clear. Tasks: Today / Upcoming /
  Overdue / Completed / All, description, category, priority, subtasks, reminder.
- Quick Focus sheet from the home button; focus page has a progress ring, pause/resume, end, stopwatch mode.
- Global search across apps, tasks, notes, reminders, settings and tools.

### About the "glass"
Compose cannot blur whatever is behind a view, so surfaces are translucent layers over a gradient background
rather than live backdrop blur. This looks the same on every Android version and is cheap on mid-range phones.
Sheets and dialogs use a more opaque panel so text stays readable.


## v0.4.0 — iOS direction
- Typeface: Inter (bundled, SIL Open Font License, see LICENSE-Inter-OFL.txt), the closest free match to SF Pro.
- Background is deep purple and black, as in the original reference.
- The class schedule card and the timetable feature were removed (old backups containing a timetable still restore).
- iOS chrome everywhere: large titles with a back chevron, inset-grouped lists, coloured icon tiles, iOS switches,
  floating glass tab bar, Cancel/Done modals, bottom sheets with a grabber, push/pop page transitions.
- Tasks laid out like Apple Reminders, Notes like Apple Notes, Calendar like Apple Calendar, Settings like iPhone
  Settings, Search like Spotlight, drawer as an A-Z App Library list. Swipe left on a task or note to delete it.
- Long-press an app for an iOS-style context menu.


## v0.5.0
- Wallpaper: Settings > Appearance > Wallpaper. Pick any photo; it sits behind every screen with adjustable dimming and an
  optional soft blur. It is stored only on the device (not included in backups).
- The Quick panel no longer opens the keyboard by itself, and moving between screens always closes the keyboard.
- New default app list "Flow" (inspired by Niagara): large type, the row at the centre of the screen is biggest and the
  rest shrink and fade, with an A-Z rail that bulges toward your finger. List, Grid and Text styles remain.
