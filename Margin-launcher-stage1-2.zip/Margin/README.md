# Margin — a minimalist student launcher (Stages 1–2)

## Run it
1. Android Studio (Koala or newer) → **Open** this folder. Let Gradle sync (JDK 17).
2. Run on a device/emulator (Android 10+).
3. Press Home → choose **Margin** → **Always**. Or use Settings → "Set Margin as default launcher".

I could not compile this in my sandbox (no Android SDK). If sync/build errors appear, paste them back and I'll fix them before Stage 3.

## What works now
- Real HOME launcher (singleTask, Home-button handling, Back never exits).
- App discovery via PackageManager, live updates on install/uninstall/update.
- Drawer: A–Z sections, instant search (Enter launches first match), Recent, 3 styles (grid / compact / text), hide apps, app info, uninstall.
- Dock (max 5): defaults to phone/browser/camera/messages; long-press to add/remove.
- Home: clock, date, time-of-day greeting (+ optional name), optional battery. Tap clock opens your calendar app.
- Gestures: swipe up = drawer, swipe down = notification shade, long-press = settings.
- Settings (DataStore): theme auto/light/dark (true-black OLED), 5 accents, mono icons, 24h clock, battery, drawer style, hidden apps.

## Known limits (Android, not bugs)
- Swipe-down shade uses a non-SDK method; it works on most phones but isn't guaranteed.
- Recents track apps launched *through Margin* (no extra permission). Usage Access comes with Digital Wellbeing in Stage 4.
- Font is the system font; add Inter in `res/font` and change `AppFont` in `ui/theme/Theme.kt`.
- Hilt/Room/WorkManager are deliberately not added yet to keep the first build lean; they arrive with Stage 3.

## Next: Stage 3 — tasks, notes, reminders, calendar, focus mode
