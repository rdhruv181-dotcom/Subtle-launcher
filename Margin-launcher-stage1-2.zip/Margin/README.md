# Margin — a minimalist student launcher (v0.2.0, Stages 1–5)

Build: open in Android Studio (JDK 17), or push to GitHub and use the included Actions workflow.
Then press Home → choose **Margin** → **Always**.

## Where things are
Swipe down (or tap the greeting) opens the **Quick panel**: capture a task / note / reminder / idea / link and jump to
Tasks, Notes, Reminders, Planner, Focus, Study, Journal, Screen time, Tools and Settings.
Swipe up = app drawer. Long-press home = settings. Tap the clock = Planner.

## Features
- Tasks: quick add, due date/time, priority, categories, subjects, subtasks, repeat, reminders, overdue markers, progress.
- Notes: autosave, pin, search, folders, subjects, checklists, headings and bullets.
- Reminders: one-off/recurring, assignment/exam types, persistent, snooze, done, custom sound, survives reboot.
- Planner: month / week / day views, weekly timetable, events, exams, holidays, countdowns, study time.
- Focus: Pomodoro 25/5, 50/10, custom; task + subject; ambient noise; DND; streaks; history; break notifications.
- Study tracker: daily/weekly goals, 7-day chart, per-subject totals, manual logging.
- Journal: four daily prompts, autosave. Screen time: usage, top apps, unlocks, weekly report, goal.
- Tools: calculator, stopwatch, timer (rings via alarm), unit converter, clipboard, QR (opens camera), files.
- Settings: theme, accent, icon/text size, clock weight, home sections, gestures, backup/restore (JSON).

## Android limits (honest list)
- Apps can't be force-blocked without Accessibility/overlay powers. Focus mode silences notifications (needs Do Not
  Disturb access) and asks before opening your chosen distracting apps *from Margin*.
- Screen time needs Usage access (granted by you in system settings). Unlocks may read 0 on some devices.
- Exact alarms need the "Alarms & reminders" permission on Android 12+; without it reminders still fire, slightly late.
- Ambient sound may stop if the system kills the app in the background.
- Google Calendar sync and rich-text beyond headings/bullets are not included. Data is stored as local JSON files
  (not Room) to keep the build small and dependency-free.
- Not compiled or run by me; the pure logic has unit tests (`gradle testDebugUnitTest`).
