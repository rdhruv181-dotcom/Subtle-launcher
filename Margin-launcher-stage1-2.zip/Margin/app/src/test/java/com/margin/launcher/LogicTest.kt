package com.margin.launcher

import com.margin.launcher.core.*
import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDate
import java.time.LocalDateTime

class LogicTest {
    private val d = LocalDate.of(2026, 11, 17)

    @Test fun dailyRecurringTaskRollsForward() {
        val due = TimeUtil.millis(d, 9, 0)
        val t = Task(1, "Read", due = due, repeat = Repeat.DAILY, subtasks = listOf(SubTask("a", true)))
        val r = TaskLogic.complete(t, TimeUtil.millis(d, 10, 0))
        assertFalse(r.done)
        assertEquals(TimeUtil.millis(d.plusDays(1), 9, 0), r.due)
        assertFalse(r.subtasks.first().done)
    }

    @Test fun oneOffTaskIsClosed() {
        val r = TaskLogic.complete(Task(1, "x", due = TimeUtil.millis(d, 9, 0)), 5L)
        assertTrue(r.done)
        assertEquals(5L, r.doneAt)
    }

    @Test fun dateOnlyTaskDueTodayIsNotOverdue() {
        val t = Task(1, "x", due = TimeUtil.millis(d, 9, 0), hasTime = false)
        assertFalse(TaskLogic.isOverdue(t, TimeUtil.millis(d, 23, 0)))
        assertTrue(TaskLogic.isOverdue(t, TimeUtil.millis(d.plusDays(1), 0, 5)))
    }

    @Test fun timedTaskBecomesOverdueAtDueTime() {
        val t = Task(1, "x", due = TimeUtil.millis(d, 9, 0), hasTime = true)
        assertFalse(TaskLogic.isOverdue(t, TimeUtil.millis(d, 8, 59)))
        assertTrue(TaskLogic.isOverdue(t, TimeUtil.millis(d, 9, 1)))
    }

    @Test fun streakCountsBackFromYesterdayWhenTodayEmpty() {
        val days = setOf(d.minusDays(1), d.minusDays(2), d.minusDays(4))
        assertEquals(2, streak(days, d))
        assertEquals(3, streak(days + d, d))
        assertEquals(0, streak(emptySet(), d))
    }

    @Test fun nextClassSkipsFinishedAndWrapsToNextWeek() {
        val tue = d.dayOfWeek.value
        val classes = listOf(ClassEntry(1, "Maths", tue, 9 * 60, 10 * 60))
        val morning = nextClass(classes, LocalDateTime.of(d, java.time.LocalTime.of(8, 0)))
        assertEquals(d, morning?.second)
        val evening = nextClass(classes, LocalDateTime.of(d, java.time.LocalTime.of(18, 0)))
        assertEquals(d.plusDays(7), evening?.second)
    }

    @Test fun nextAfterSkipsMissedOccurrences() {
        val start = TimeUtil.millis(d, 9, 0)
        val r = TimeUtil.nextAfter(start, Repeat.DAILY, TimeUtil.millis(d.plusDays(3), 12, 0))
        assertEquals(TimeUtil.millis(d.plusDays(4), 9, 0), r)
    }

    @Test fun clockFormatting() {
        assertEquals("9:00 AM", fmtClock(9 * 60, false))
        assertEquals("12:05 PM", fmtClock(12 * 60 + 5, false))
        assertEquals("12:30 AM", fmtClock(30, false))
        assertEquals("18:00", fmtClock(18 * 60, true))
    }

    @Test fun durationFormatting() {
        assertEquals("45m", fmtDuration(45))
        assertEquals("2h", fmtDuration(120))
        assertEquals("1h 5m", fmtDuration(65))
    }
}
