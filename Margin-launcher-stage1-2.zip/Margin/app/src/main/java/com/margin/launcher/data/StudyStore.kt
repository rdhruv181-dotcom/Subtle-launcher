package com.margin.launcher.data

import android.content.Context
import com.margin.launcher.core.*
import com.margin.launcher.system.Scheduling
import org.json.JSONObject
import java.io.File

/** All student data. Everything stays on the device in app-private files. */
class StudyStore(private val ctx: Context) {
    private val dir = File(ctx.filesDir, "data").also { it.mkdirs() }
    private fun file(n: String) = File(dir, "$n.json")

    val tasks = JsonCollection(file("tasks"), ::taskFrom) { it.toJson() }
    val notes = JsonCollection(file("notes"), ::noteFrom) { it.toJson() }
    val reminders = JsonCollection(file("reminders"), ::reminderFrom) { it.toJson() }
    val events = JsonCollection(file("events"), ::eventFrom) { it.toJson() }
    val sessions = JsonCollection(file("sessions"), ::sessionFrom) { it.toJson() }
    val journal = JsonCollection(file("journal"), ::journalFrom) { it.toJson() }
    val subjects = JsonCollection(file("subjects"), ::subjectFrom) { it.toJson() }

    fun saveTask(t: Task) { tasks.upsert(t); Scheduling.syncTask(ctx, t) }
    fun deleteTask(id: Long) { tasks.remove(id); Scheduling.cancel(ctx, "task", id) }
    fun toggleTask(t: Task) {
        saveTask(if (t.done) t.copy(done = false, doneAt = null) else TaskLogic.complete(t, System.currentTimeMillis()))
    }

    fun saveReminder(r: Reminder) { reminders.upsert(r); Scheduling.syncReminder(ctx, r) }
    fun deleteReminder(id: Long) { reminders.remove(id); Scheduling.cancel(ctx, "reminder", id) }

    fun saveEvent(e: Event) { events.upsert(e); Scheduling.syncEvent(ctx, e) }
    fun deleteEvent(id: Long) { events.remove(id); Scheduling.cancel(ctx, "event", id) }

    fun addNote(body: String, folder: String) {
        val now = Ids.next()
        notes.upsert(Note(id = now, body = body.trim(), folder = folder, created = now, updated = now))
    }

    fun exportJson(): JSONObject = JSONObject()
        .put("app", "margin").put("version", 1)
        .put("tasks", tasks.toJsonArray()).put("notes", notes.toJsonArray())
        .put("reminders", reminders.toJsonArray()).put("events", events.toJsonArray())
        .put("sessions", sessions.toJsonArray())
        .put("journal", journal.toJsonArray()).put("subjects", subjects.toJsonArray())

    /** Replaces all data with the backup's contents. Throws if the file isn't a Margin backup. */
    fun importJson(o: JSONObject) {
        require(o.optString("app") == "margin") { "Not a Margin backup" }
        o.optJSONArray("tasks")?.let { tasks.loadFrom(it) }
        o.optJSONArray("notes")?.let { notes.loadFrom(it) }
        o.optJSONArray("reminders")?.let { reminders.loadFrom(it) }
        o.optJSONArray("events")?.let { events.loadFrom(it) }
        o.optJSONArray("sessions")?.let { sessions.loadFrom(it) }
        o.optJSONArray("journal")?.let { journal.loadFrom(it) }
        o.optJSONArray("subjects")?.let { subjects.loadFrom(it) }
        Scheduling.rescheduleAll(ctx, this)
    }
}

object Graph {
    @Volatile private var store: StudyStore? = null
    fun store(ctx: Context): StudyStore =
        store ?: synchronized(this) { store ?: StudyStore(ctx.applicationContext).also { store = it } }
}
