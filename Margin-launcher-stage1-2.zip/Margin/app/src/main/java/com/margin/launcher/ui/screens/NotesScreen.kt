package com.margin.launcher.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.margin.launcher.LauncherViewModel
import com.margin.launcher.UiState
import com.margin.launcher.core.*
import com.margin.launcher.ui.components.*
import com.margin.launcher.ui.theme.M
import kotlinx.coroutines.delay
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

private val STAMP = DateTimeFormatter.ofPattern("d MMM yyyy, HH:mm")
private fun stamp(ms: Long) = Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()).format(STAMP)
private val DEFAULT_FOLDERS = listOf("Inbox", "Ideas", "Links", "Quick")

/** Lines starting with "# " are shown as headings. The text itself is unchanged. */
private class NoteFormat : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText {
        val b = AnnotatedString.Builder(text.text)
        var i = 0
        for (line in text.text.split("\n")) {
            if (line.startsWith("# ")) b.addStyle(SpanStyle(fontWeight = FontWeight.SemiBold, fontSize = 24.sp), i, i + line.length)
            i += line.length + 1
        }
        return TransformedText(b.toAnnotatedString(), OffsetMapping.Identity)
    }
}

@Composable
fun NotesScreen(vm: LauncherViewModel, state: UiState, onBack: () -> Unit) {
    val store = vm.store
    val c = M.colors
    val notes by store.notes.items.collectAsState()
    var query by remember { mutableStateOf("") }
    var folder by remember { mutableStateOf<String?>(null) }
    var editing by remember { mutableStateOf<Note?>(null) }

    val e = editing
    if (e != null) {
        NoteEditor(vm, e) { editing = null }
        return
    }

    val folders = (DEFAULT_FOLDERS + notes.map { it.folder }).distinct()
    val list = notes
        .filter { folder == null || it.folder == folder }
        .filter { n ->
            query.isBlank() || n.title.contains(query, true) || n.body.contains(query, true) ||
                n.checks.any { it.title.contains(query, true) } || n.subject.contains(query, true)
        }
        .sortedWith(compareByDescending<Note> { it.pinned }.thenByDescending { it.updated })

    Page("Notes", onBack, action = {
        GlassIconButton(GIcon.PLUS, "New note", { val id = Ids.next(); editing = Note(id = id, created = id, updated = id) }, size = 40.dp)
    }) {
        Column(Modifier.padding(horizontal = 24.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            GlassSearchBar(query, { query = it }, "Search notes")
            Chips {
                Chip("All", folder == null) { folder = null }
                folders.forEach { f -> Chip(f, folder == f) { folder = if (folder == f) null else f } }
            }
        }
        LazyColumn(Modifier.weight(1f).padding(horizontal = 24.dp), contentPadding = PaddingValues(vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (list.isEmpty()) item { Text(if (notes.isEmpty()) "No notes yet. Tap + New." else "No matching notes.", color = c.secondary) }
            items(list, key = { it.id }) { n ->
                Column(
                    Modifier.fillMaxWidth().glass(16.dp)
                        .clickable { editing = n }.padding(16.dp)
                ) {
                    val head = n.title.ifBlank { n.body.lineSequence().firstOrNull().orEmpty().removePrefix("# ") }.ifBlank { "Untitled" }
                    Row {
                        Text(head, fontSize = 17.sp, fontWeight = FontWeight.Medium, maxLines = 1,
                            overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                        if (n.pinned) Text("Pinned", fontSize = 12.sp, color = c.accent)
                    }
                    val preview = n.body.lineSequence().drop(if (n.title.isBlank()) 1 else 0).joinToString(" ").trim()
                    if (preview.isNotEmpty()) Text(preview, fontSize = 14.sp, color = c.secondary, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    if (n.checks.isNotEmpty()) Text("${n.checks.count { it.done }}/${n.checks.size} done", fontSize = 13.sp, color = c.secondary)
                    Text(listOf(n.folder, n.subject.ifEmpty { null }, stamp(n.updated)).filterNotNull().joinToString(" · "),
                        fontSize = 12.sp, color = c.secondary, modifier = Modifier.padding(top = 6.dp))
                }
            }
        }
    }
}

@Composable
private fun NoteEditor(vm: LauncherViewModel, note: Note, onClose: () -> Unit) {
    val store = vm.store
    val c = M.colors
    var title by remember { mutableStateOf(note.title) }
    var body by remember { mutableStateOf(TextFieldValue(note.body)) }
    var folder by remember { mutableStateOf(note.folder) }
    var subject by remember { mutableStateOf(note.subject) }
    var pinned by remember { mutableStateOf(note.pinned) }
    val checks = remember { mutableStateListOf<SubTask>().apply { addAll(note.checks) } }
    var newCheck by remember { mutableStateOf("") }
    var newFolder by remember { mutableStateOf("") }
    var deleted by remember { mutableStateOf(false) }

    // Autosave: used both after a short pause in typing and when leaving the editor.
    fun save() {
        if (deleted) return
        val base = store.notes.get(note.id) ?: note
        val changed = title != base.title || body.text != base.body || folder != base.folder || subject != base.subject ||
            pinned != base.pinned || checks.toList() != base.checks
        val blank = title.isBlank() && body.text.isBlank() && checks.isEmpty()
        if (changed && !blank) {
            store.notes.upsert(note.copy(title = title, body = body.text, checks = checks.toList(), folder = folder,
                subject = subject, pinned = pinned, updated = System.currentTimeMillis()))
        }
    }
    LaunchedEffect(title, body.text, folder, subject, pinned, checks.toList()) { delay(400); save() }
    DisposableEffect(Unit) { onDispose { save() } }
    BackHandler(onBack = onClose)

    fun toggleLinePrefix(prefix: String) {
        val t = body.text
        val start = t.lastIndexOf('\n', body.selection.start - 1) + 1
        val has = t.startsWith(prefix, start)
        val nt = if (has) t.removeRange(start, start + prefix.length) else t.substring(0, start) + prefix + t.substring(start)
        val shift = if (has) -prefix.length else prefix.length
        val pos = (body.selection.start + shift).coerceIn(0, nt.length)
        body = TextFieldValue(nt, TextRange(pos))
    }

    Page("Note", onClose, action = {
        Text(if (pinned) "Unpin" else "Pin", fontSize = 15.sp, color = c.accent,
            modifier = Modifier.clickable { pinned = !pinned }.padding(12.dp))
    }) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {
            BasicTextField(
                value = title, onValueChange = { title = it }, singleLine = true,
                textStyle = TextStyle(fontSize = 24.sp, fontWeight = FontWeight.Medium, color = c.text),
                cursorBrush = SolidColor(c.accent), modifier = Modifier.fillMaxWidth(),
                decorationBox = { inner -> Box { if (title.isEmpty()) Text("Title", fontSize = 24.sp, color = c.secondary); inner() } },
            )
            Text("Created ${stamp(note.created)}", fontSize = 12.sp, color = c.secondary)

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("Heading", false) { toggleLinePrefix("# ") }
                Chip("Bullet", false) { toggleLinePrefix("• ") }
            }
            BasicTextField(
                value = body, onValueChange = { body = it },
                textStyle = TextStyle(fontSize = 17.sp, color = c.text, lineHeight = 25.sp),
                cursorBrush = SolidColor(c.accent), visualTransformation = NoteFormat(),
                modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 160.dp),
                decorationBox = { inner -> Box { if (body.text.isEmpty()) Text("Start writing…", fontSize = 17.sp, color = c.secondary); inner() } },
            )

            Label("Checklist")
            checks.forEachIndexed { i, s ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CheckCircle(s.done, { checks[i] = s.copy(done = !s.done) }, "Item: ${s.title}")
                    Text(s.title, fontSize = 16.sp, modifier = Modifier.weight(1f),
                        textDecoration = if (s.done) TextDecoration.LineThrough else null)
                    Text("Remove", fontSize = 13.sp, color = c.secondary, modifier = Modifier.clickable { checks.removeAt(i) }.padding(8.dp))
                }
            }
            Field(newCheck, { newCheck = it }, "Add checklist item", imeAction = ImeAction.Done,
                onDone = { if (newCheck.isNotBlank()) { checks.add(SubTask(newCheck.trim())); newCheck = "" } })

            Label("Folder")
            Chips {
                (DEFAULT_FOLDERS + folder).distinct().forEach { f -> Chip(f, folder == f) { folder = f } }
            }
            Field(newFolder, { newFolder = it }, "New folder", imeAction = ImeAction.Done,
                onDone = { if (newFolder.isNotBlank()) { folder = newFolder.trim(); newFolder = "" } })

            Label("Subject")
            SubjectPicker(store, subject) { subject = it }

            Btn("Delete note", { deleted = true; store.notes.remove(note.id); onClose() },
                Modifier.fillMaxWidth().padding(vertical = 12.dp), primary = false, danger = true)
        }
    }
}
