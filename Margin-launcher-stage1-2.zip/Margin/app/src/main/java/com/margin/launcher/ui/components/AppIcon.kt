package com.margin.launcher.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.unit.Dp
import com.margin.launcher.data.AppInfo
import com.margin.launcher.data.AppRepository

@Composable
fun AppIcon(app: AppInfo, repo: AppRepository, size: Dp, mono: Boolean, modifier: Modifier = Modifier) {
    val bmp by produceState<ImageBitmap?>(repo.cached(app.key), app.key) {
        if (value == null) value = repo.icon(app)
    }
    val filter = remember(mono) {
        if (mono) ColorFilter.colorMatrix(ColorMatrix().apply { setToSaturation(0f) }) else null
    }
    Box(modifier.size(size)) {
        bmp?.let { Image(it, contentDescription = null, modifier = Modifier.fillMaxSize(), colorFilter = filter) }
    }
}
