package com.margin.launcher.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.margin.launcher.ui.theme.M
import kotlin.math.cos
import kotlin.math.sin

enum class GIcon {
    CHECK_CIRCLE, CALENDAR, TIMER, NOTE, MOON, SEARCH, PLUS, CLOSE, BELL, SLIDERS, BACK, CHEVRON_RIGHT,
    TOOLS, HOME, GRID, SWIPE, SHIELD, ARCHIVE, INFO, SUN, BOOK, CHART, PHONE, PLAY, PAUSE, STOP, MINUS, STAR, EYE_OFF, TRASH, LIST,
}

/** Consistent line icons drawn on a 24-unit grid, so no icon library is needed. */
@Composable
fun LineIcon(icon: GIcon, modifier: Modifier = Modifier, tint: Color = M.colors.text, size: Dp = 24.dp) {
    Canvas(modifier.size(size)) {
        val u = this.size.minDimension / 24f
        val st = Stroke(width = 1.8f * u, cap = StrokeCap.Round, join = StrokeJoin.Round)
        fun o(x: Float, y: Float) = Offset(x * u, y * u)
        fun ln(x1: Float, y1: Float, x2: Float, y2: Float) = drawLine(tint, o(x1, y1), o(x2, y2), st.width, StrokeCap.Round)
        fun poly(vararg p: Float) {
            val path = Path()
            path.moveTo(p[0] * u, p[1] * u)
            var i = 2
            while (i < p.size) { path.lineTo(p[i] * u, p[i + 1] * u); i += 2 }
            drawPath(path, tint, style = st)
        }
        fun circ(cx: Float, cy: Float, r: Float) = drawCircle(tint, r * u, o(cx, cy), style = st)
        fun dot(cx: Float, cy: Float, r: Float) = drawCircle(tint, r * u, o(cx, cy))
        fun rr(x: Float, y: Float, w: Float, h: Float, r: Float) =
            drawRoundRect(tint, o(x, y), Size(w * u, h * u), CornerRadius(r * u), style = st)

        when (icon) {
            GIcon.CHECK_CIRCLE -> { circ(12f, 12f, 9f); poly(8f, 12.5f, 11f, 15.5f, 16.5f, 9f) }
            GIcon.CALENDAR -> { rr(4f, 5.5f, 16f, 14.5f, 3.5f); ln(4f, 10f, 20f, 10f); ln(8.5f, 3.5f, 8.5f, 7.5f); ln(15.5f, 3.5f, 15.5f, 7.5f) }
            GIcon.TIMER -> { circ(12f, 13.5f, 7.5f); ln(10f, 3.5f, 14f, 3.5f); ln(12f, 3.5f, 12f, 6f); poly(12f, 9.5f, 12f, 13.5f, 15f, 15f) }
            GIcon.NOTE -> { rr(5f, 3f, 14f, 18f, 3f); ln(8.5f, 9f, 15.5f, 9f); ln(8.5f, 13f, 15.5f, 13f); ln(8.5f, 17f, 12f, 17f) }
            GIcon.MOON -> {
                val outer = Path().apply { addOval(Rect(o(12f, 12f), 8.5f * u)) }
                val inner = Path().apply { addOval(Rect(o(16.5f, 8.5f), 7.2f * u)) }
                drawPath(Path.combine(PathOperation.Difference, outer, inner), tint, style = st)
            }
            GIcon.SEARCH -> { circ(11f, 11f, 6.5f); ln(16f, 16f, 20.5f, 20.5f) }
            GIcon.PLUS -> { ln(12f, 5f, 12f, 19f); ln(5f, 12f, 19f, 12f) }
            GIcon.MINUS -> ln(5f, 12f, 19f, 12f)
            GIcon.CLOSE -> { ln(6f, 6f, 18f, 18f); ln(18f, 6f, 6f, 18f) }
            GIcon.BELL -> {
                drawArc(tint, 180f, 180f, false, o(7f, 5.5f), Size(10f * u, 10f * u), style = st)
                poly(5f, 17f, 7f, 15f, 7f, 10.5f); poly(19f, 17f, 17f, 15f, 17f, 10.5f)
                ln(5f, 17f, 19f, 17f); ln(10.5f, 19.5f, 13.5f, 19.5f)
            }
            GIcon.SLIDERS -> {
                ln(4f, 7f, 20f, 7f); ln(4f, 12f, 20f, 12f); ln(4f, 17f, 20f, 17f)
                dot(9f, 7f, 2.2f); dot(15f, 12f, 2.2f); dot(8f, 17f, 2.2f)
            }
            GIcon.BACK -> poly(14.5f, 5.5f, 8f, 12f, 14.5f, 18.5f)
            GIcon.CHEVRON_RIGHT -> poly(9.5f, 5.5f, 16f, 12f, 9.5f, 18.5f)
            GIcon.TOOLS -> { rr(4f, 4f, 6.5f, 6.5f, 2f); rr(13.5f, 4f, 6.5f, 6.5f, 2f); rr(4f, 13.5f, 6.5f, 6.5f, 2f); rr(13.5f, 13.5f, 6.5f, 6.5f, 2f) }
            GIcon.HOME -> { poly(4f, 11f, 12f, 4f, 20f, 11f); poly(6f, 10f, 6f, 20f, 18f, 20f, 18f, 10f) }
            GIcon.GRID -> { for (r in 0..2) for (c in 0..2) dot(6f + c * 6f, 6f + r * 6f, 1.5f) }
            GIcon.SWIPE -> { poly(8f, 10f, 12f, 6f, 16f, 10f); ln(12f, 6f, 12f, 18f) }
            GIcon.SHIELD -> { poly(12f, 3.5f, 19f, 6.5f, 19f, 12f, 12f, 20.5f, 5f, 12f, 5f, 6.5f, 12f, 3.5f); poly(9f, 12f, 11.2f, 14.2f, 15f, 10f) }
            GIcon.ARCHIVE -> { rr(4f, 4f, 16f, 5f, 1.5f); rr(5.5f, 9f, 13f, 10.5f, 2f); ln(10f, 13f, 14f, 13f) }
            GIcon.INFO -> { circ(12f, 12f, 9f); ln(12f, 11f, 12f, 16.5f); dot(12f, 7.8f, 1f) }
            GIcon.SUN -> {
                circ(12f, 12f, 4f)
                for (i in 0 until 8) {
                    val a = Math.toRadians(i * 45.0)
                    val cs = cos(a).toFloat(); val sn = sin(a).toFloat()
                    ln(12f + 6.8f * cs, 12f + 6.8f * sn, 12f + 9f * cs, 12f + 9f * sn)
                }
            }
            GIcon.BOOK -> { rr(5f, 3.5f, 14f, 17f, 2.5f); ln(9f, 3.5f, 9f, 20.5f) }
            GIcon.CHART -> { ln(6f, 19f, 6f, 12f); ln(12f, 19f, 12f, 6f); ln(18f, 19f, 18f, 10f) }
            GIcon.PHONE -> { rr(7f, 3f, 10f, 18f, 2.5f); ln(10.5f, 18f, 13.5f, 18f) }
            GIcon.STAR -> {
                val p = Path()
                for (i in 0 until 10) {
                    val r = if (i % 2 == 0) 9f else 4f
                    val a = Math.toRadians(-90.0 + i * 36.0)
                    val x = (12f + r * cos(a).toFloat()) * u
                    val y = (12.8f + r * sin(a).toFloat()) * u
                    if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
                }
                p.close()
                drawPath(p, tint, style = st)
            }
            GIcon.EYE_OFF -> {
                circ(12f, 12f, 3.2f)
                poly(3f, 12f, 7f, 7.5f, 12f, 6f, 17f, 7.5f, 21f, 12f, 17f, 16.5f, 12f, 18f, 7f, 16.5f, 3f, 12f)
                ln(4f, 4f, 20f, 20f)
            }
            GIcon.TRASH -> {
                ln(5f, 7f, 19f, 7f); poly(9f, 7f, 9f, 4.5f, 15f, 4.5f, 15f, 7f); poly(7f, 7f, 8f, 20f, 16f, 20f, 17f, 7f)
                ln(10.5f, 11f, 10.5f, 16f); ln(13.5f, 11f, 13.5f, 16f)
            }
            GIcon.LIST -> {
                dot(5f, 7f, 1.2f); dot(5f, 12f, 1.2f); dot(5f, 17f, 1.2f)
                ln(9f, 7f, 20f, 7f); ln(9f, 12f, 20f, 12f); ln(9f, 17f, 20f, 17f)
            }
            GIcon.PLAY -> poly(8f, 5.5f, 18f, 12f, 8f, 18.5f, 8f, 5.5f)
            GIcon.PAUSE -> { ln(9f, 6f, 9f, 18f); ln(15f, 6f, 15f, 18f) }
            GIcon.STOP -> rr(6.5f, 6.5f, 11f, 11f, 2f)
        }
    }
}
