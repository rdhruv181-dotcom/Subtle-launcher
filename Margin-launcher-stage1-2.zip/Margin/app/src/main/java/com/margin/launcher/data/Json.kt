package com.margin.launcher.data

import com.margin.launcher.core.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors

private fun JSONObject.optL(n: String): Long? = if (has(n) && !isNull(n)) getLong(n) else null
private fun repeatOf(s: String) = runCatching { Repeat.valueOf(s) }.getOrDefault(Repeat.NONE)

private fun List<SubTask>.toJson() = JSONArray().also { a ->
    forEach { a.put(JSONObject().put("t", it.title).put("d", it.done)) }
}
private fun JSONArray?.toSubs(): List<SubTask> =
    if (this == null) emptyList() else (0 until length()).map { getJSONObject(it).let { o -> SubTask(o.getString("t"), o.optBoolean("d")) } }

fun Task.toJson(): JSONObject = JSONObject()
    .put("id", id).put("title", title).put("description", description).put("hasTime", hasTime).put("priority", priority)
    .put("category", category).put("subject", subject).put("subtasks", subtasks.toJson())
    .put("repeat", repeat.name).put("remindBefore", remindBefore).put("done", done).put("created", created)
    .also { o -> due?.let { o.put("due", it) }; doneAt?.let { o.put("doneAt", it) } }

fun taskFrom(o: JSONObject) = Task(
    id = o.getLong("id"), title = o.getString("title"), description = o.optString("description"), due = o.optL("due"),
    hasTime = o.optBoolean("hasTime"), priority = o.optInt("priority", 1),
    category = o.optString("category", "College"), subject = o.optString("subject"),
    subtasks = o.optJSONArray("subtasks").toSubs(), repeat = repeatOf(o.optString("repeat", "NONE")),
    remindBefore = o.optInt("remindBefore", -1), done = o.optBoolean("done"),
    doneAt = o.optL("doneAt"), created = o.optLong("created"),
)

fun Note.toJson(): JSONObject = JSONObject()
    .put("id", id).put("title", title).put("body", body).put("checks", checks.toJson())
    .put("folder", folder).put("subject", subject).put("pinned", pinned)
    .put("created", created).put("updated", updated)

fun noteFrom(o: JSONObject) = Note(
    id = o.getLong("id"), title = o.optString("title"), body = o.optString("body"),
    checks = o.optJSONArray("checks").toSubs(), folder = o.optString("folder", "Inbox"),
    subject = o.optString("subject"), pinned = o.optBoolean("pinned"),
    created = o.optLong("created"), updated = o.optLong("updated"),
)

fun Reminder.toJson(): JSONObject = JSONObject()
    .put("id", id).put("title", title).put("description", description).put("time", time).put("repeat", repeat.name)
    .put("kind", kind).put("persistent", persistent).put("done", done)

fun reminderFrom(o: JSONObject) = Reminder(
    id = o.getLong("id"), title = o.getString("title"), description = o.optString("description"), time = o.getLong("time"),
    repeat = repeatOf(o.optString("repeat", "NONE")), kind = o.optInt("kind"),
    persistent = o.optBoolean("persistent"), done = o.optBoolean("done"),
)

fun Event.toJson(): JSONObject = JSONObject()
    .put("id", id).put("title", title).put("day", day).put("endDay", endDay)
    .put("startMin", startMin).put("kind", kind).put("subject", subject).put("remindBefore", remindBefore)

fun eventFrom(o: JSONObject) = Event(
    id = o.getLong("id"), title = o.getString("title"), day = o.getLong("day"),
    endDay = o.optLong("endDay", o.getLong("day")), startMin = o.optInt("startMin", -1),
    kind = o.optInt("kind"), subject = o.optString("subject"), remindBefore = o.optInt("remindBefore", -1),
)

fun FocusSession.toJson(): JSONObject = JSONObject()
    .put("id", id).put("start", start).put("minutes", minutes).put("subject", subject)
    .put("completed", completed).put("interruptions", interruptions).put("taskId", taskId)

fun sessionFrom(o: JSONObject) = FocusSession(
    id = o.getLong("id"), start = o.getLong("start"), minutes = o.getInt("minutes"),
    subject = o.optString("subject"), completed = o.optBoolean("completed", true),
    interruptions = o.optInt("interruptions"), taskId = o.optLong("taskId", -1),
)

fun JournalEntry.toJson(): JSONObject = JSONObject()
    .put("id", id).put("good", good).put("done", done).put("improve", improve).put("tomorrow", tomorrow)

fun journalFrom(o: JSONObject) = JournalEntry(
    id = o.getLong("id"), good = o.optString("good"), done = o.optString("done"),
    improve = o.optString("improve"), tomorrow = o.optString("tomorrow"),
)

fun Subject.toJson(): JSONObject = JSONObject().put("id", id).put("name", name)
fun subjectFrom(o: JSONObject) = Subject(o.getLong("id"), o.getString("name"))

private val writer = Executors.newSingleThreadExecutor()

/** A list of items kept in memory as a StateFlow and mirrored to one JSON file (atomic writes). */
class JsonCollection<T : HasId>(
    private val file: File,
    private val read: (JSONObject) -> T,
    private val write: (T) -> JSONObject,
) {
    private val _items = MutableStateFlow(load())
    val items: StateFlow<List<T>> = _items.asStateFlow()

    private fun load(): List<T> {
        if (!file.exists()) return emptyList()
        return try {
            val arr = JSONArray(file.readText())
            (0 until arr.length()).map { read(arr.getJSONObject(it)) }
        } catch (e: Exception) {
            // Keep the unreadable file for recovery instead of crashing or overwriting it.
            runCatching { file.renameTo(File(file.parentFile, file.name + ".corrupt")) }
            emptyList()
        }
    }

    @Synchronized fun upsert(item: T) {
        val cur = _items.value
        _items.value = if (cur.any { it.id == item.id }) cur.map { if (it.id == item.id) item else it } else cur + item
        persist()
    }

    @Synchronized fun remove(id: Long) { _items.value = _items.value.filter { it.id != id }; persist() }
    @Synchronized fun replaceAll(list: List<T>) { _items.value = list; persist() }
    fun get(id: Long): T? = _items.value.firstOrNull { it.id == id }

    fun toJsonArray(): JSONArray = JSONArray().also { a -> _items.value.forEach { a.put(write(it)) } }
    fun loadFrom(arr: JSONArray) = replaceAll((0 until arr.length()).map { read(arr.getJSONObject(it)) })

    private fun persist() {
        val snapshot = toJsonArray().toString()
        writer.execute {
            try {
                val tmp = File(file.path + ".tmp")
                tmp.writeText(snapshot)
                tmp.renameTo(file)
            } catch (_: Exception) { }
        }
    }
}
