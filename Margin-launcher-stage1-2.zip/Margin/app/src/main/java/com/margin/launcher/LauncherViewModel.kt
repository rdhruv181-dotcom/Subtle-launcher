package com.margin.launcher

import android.app.Application
import android.content.Intent
import android.widget.Toast
import androidx.datastore.preferences.core.MutablePreferences
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.margin.launcher.data.*
import com.margin.launcher.system.FocusEngine
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class Screen {
    HOME, DRAWER, SETTINGS, QUICK, TASKS, NOTES, REMINDERS, PLANNER, FOCUS, STUDY, JOURNAL, WELLBEING, TOOLS
}

data class UiState(
    val visibleApps: List<AppInfo> = emptyList(),
    val dock: List<AppInfo> = emptyList(),
    val recents: List<AppInfo> = emptyList(),
    val hiddenApps: List<AppInfo> = emptyList(),
    val settings: UserSettings = UserSettings(),
)

class LauncherViewModel(app: Application) : AndroidViewModel(app) {
    val repo = AppRepository(app)
    val store: StudyStore = Graph.store(app)
    private val prefs = PrefsRepository(app)

    val screen = MutableStateFlow(Screen.HOME)
    val query = MutableStateFlow("")

    val state: StateFlow<UiState> = combine(repo.apps, prefs.flow) { apps, s ->
        val byKey = apps.associateBy { it.key }
        val dockKeys = s.dock ?: repo.defaultDockKeys(apps)
        UiState(
            visibleApps = apps.filter { it.key !in s.hidden },
            dock = dockKeys.mapNotNull { byKey[it] }.filter { it.key !in s.hidden },
            recents = s.recents.mapNotNull { byKey[it] }.filter { it.key !in s.hidden }.take(4),
            hiddenApps = apps.filter { it.key in s.hidden },
            settings = s,
        )
    }.stateIn(viewModelScope, SharingStarted.Eagerly, UiState())

    init {
        FocusEngine.init(app)
        viewModelScope.launch { repo.refresh() }
        repo.registerChanges { viewModelScope.launch { repo.refresh() } }
        // Advances Pomodoro phases while the app is alive (an alarm covers the app being closed).
        viewModelScope.launch { while (true) { FocusEngine.tick(app); delay(1000) } }
    }

    override fun onCleared() = repo.unregisterChanges()

    // ----- navigation -----
    fun goHome() { screen.value = Screen.HOME; query.value = "" }
    fun openDrawer() { screen.value = Screen.DRAWER }
    fun openSettings() { screen.value = Screen.SETTINGS }
    fun go(s: Screen) { screen.value = s }
    fun setQuery(q: String) { query.value = q }

    // ----- apps -----
    fun launch(app: AppInfo) {
        val ctx = getApplication<Application>()
        val intent = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(app.component)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        try {
            ctx.startActivity(intent)
            val recents = (listOf(app.key) + state.value.settings.recents.filter { it != app.key }).take(8)
            viewModelScope.launch { prefs.edit { this[PrefKeys.recents] = recents.joinToString("|") } }
        } catch (e: Exception) {
            toast("Couldn't open ${app.label}")
        }
        goHome()
    }

    fun toggleDock(key: String) {
        val current = state.value.dock.map { it.key }
        val next = if (key in current) current - key else {
            if (current.size >= MAX_DOCK) { toast("The dock holds $MAX_DOCK apps"); return }
            current + key
        }
        save { this[PrefKeys.dock] = next.joinToString("|") }
    }

    fun hide(key: String) {
        val dock = state.value.dock.map { it.key } - key
        val hidden = state.value.settings.hidden + key
        save { this[PrefKeys.hidden] = hidden; this[PrefKeys.dock] = dock.joinToString("|") }
    }

    fun unhide(key: String) {
        val hidden = state.value.settings.hidden - key
        save { this[PrefKeys.hidden] = hidden }
    }

    fun toggleDistracting(key: String) {
        val cur = state.value.settings.distracting
        save { this[PrefKeys.distracting] = if (key in cur) cur - key else cur + key }
    }

    // ----- settings -----
    fun setTheme(m: ThemeMode) = save { this[PrefKeys.theme] = m.name }
    fun setAccent(i: Int) = save { this[PrefKeys.accent] = i }
    fun setDrawerStyle(s: DrawerStyle) = save { this[PrefKeys.drawerStyle] = s.name }
    fun set24h(v: Boolean) = save { this[PrefKeys.use24h] = v }
    fun setShowBattery(v: Boolean) = save { this[PrefKeys.showBattery] = v }
    fun setMonoIcons(v: Boolean) = save { this[PrefKeys.monoIcons] = v }
    fun setName(v: String) = save { this[PrefKeys.name] = v.take(30) }
    fun setIconSize(v: Int) = save { this[PrefKeys.iconSize] = v }
    fun setTextSize(v: Int) = save { this[PrefKeys.textSize] = v }
    fun setClockWeight(v: Int) = save { this[PrefKeys.clockWeight] = v }
    fun setShowSchedule(v: Boolean) = save { this[PrefKeys.showSchedule] = v }
    fun setShowTasks(v: Boolean) = save { this[PrefKeys.showTasks] = v }
    fun setShowReminder(v: Boolean) = save { this[PrefKeys.showReminder] = v }
    fun setShowExam(v: Boolean) = save { this[PrefKeys.showExam] = v }
    fun setShowQuickNote(v: Boolean) = save { this[PrefKeys.showQuickNote] = v }
    fun setSwipeDown(v: Int) = save { this[PrefKeys.swipeDown] = v }
    fun setStudyDaily(v: Int) = save { this[PrefKeys.studyDaily] = v }
    fun setStudyWeekly(v: Int) = save { this[PrefKeys.studyWeekly] = v }
    fun setScreenGoal(v: Int) = save { this[PrefKeys.screenGoal] = v }
    fun setFocusDnd(v: Boolean) = save { this[PrefKeys.focusDnd] = v }

    private fun save(block: MutablePreferences.() -> Unit) {
        viewModelScope.launch { prefs.edit(block) }
    }

    fun toast(msg: String) = Toast.makeText(getApplication(), msg, Toast.LENGTH_SHORT).show()

    companion object { const val MAX_DOCK = 5 }
}
