package com.margin.launcher.ui.screens

import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.margin.launcher.LauncherViewModel
import com.margin.launcher.Screen
import com.margin.launcher.UiState
import com.margin.launcher.core.*
import com.margin.launcher.ui.components.*
import com.margin.launcher.ui.theme.M
import java.time.LocalDate

/** Quick capture plus shortcuts to every part of Margin. Opened by swiping down (or tapping the greeting). */
@Composable
fun QuickPanel(vm: LauncherViewModel, state: UiState, onBack: () -> Unit) {
    val c = M.colors
    val ctx = LocalContext.current
    val store = vm.store
    var mode by remember { mutableIntStateOf(0) }       // 0 task, 1 note, 2 reminder, 3 idea, 4 link
    var text by remember { mutableStateOf("") }
    var taskDay by remember { mutableIntStateOf(0) }    // today, tomorrow, none
    var remindIn by remember { mutableIntStateOf(0) }   // 1 hour, tonight, tomorrow
    val focus = remember { FocusRequester() }
    val askNotif = rememberNotifPermission()
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }

    fun save() {
        val t = text.trim()
        if (t.isEmpty()) return
        val today = LocalDate.now()
        val now = System.currentTimeMillis()
        when (mode) {
            0 -> store.saveTask(Task(Ids.next(), t, due = when (taskDay) {
                0 -> TimeUtil.millis(today, 9, 0)
                1 -> TimeUtil.millis(today.plusDays(1), 9, 0)
                else -> null
            }))
            1 -> store.addNote(t, "Inbox")
            2 -> {
                val at = when (remindIn) {
                    0 -> now + 3_600_000L
                    1 -> TimeUtil.millis(today, 18, 0).let { if (it > now) it else TimeUtil.millis(today.plusDays(1), 18, 0) }
                    else -> TimeUtil.millis(today.plusDays(1), 9, 0)
                }
                askNotif()
                store.saveReminder(Reminder(Ids.next(), t, time = at))
            }
            3 -> store.addNote(t, "Ideas")
            else -> store.addNote(t, "Links")
        }
        text = ""
        vm.toast("Saved")
    }

    Page("Quick", onBack) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Chips { listOf("Task", "Note", "Reminder", "Idea", "Link").forEachIndexed { i, l -> Chip(l, mode == i) { mode = i } } }
            Field(text, { text = it }, when (mode) { 0 -> "New task"; 1 -> "New note"; 2 -> "Remind me to…"; 3 -> "Idea"; else -> "Paste a link" },
                imeAction = ImeAction.Done, focusRequester = focus, onDone = { save() })
            when (mode) {
                0 -> Chips { listOf("Today", "Tomorrow", "No date").forEachIndexed { i, l -> Chip(l, taskDay == i) { taskDay = i } } }
                2 -> Chips { listOf("In 1 hour", "This evening", "Tomorrow 9:00").forEachIndexed { i, l -> Chip(l, remindIn == i) { remindIn = i } } }
                4 -> LinkRow("Paste from clipboard") {
                    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    text = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(ctx)?.toString().orEmpty()
                }
                else -> Unit
            }
            Btn("Save", { save() }, Modifier.fillMaxWidth())

            Label("Go to", Modifier.padding(top = 16.dp))
            val items = listOf(
                "Tasks" to Screen.TASKS, "Notes" to Screen.NOTES, "Reminders" to Screen.REMINDERS, "Planner" to Screen.PLANNER,
                "Focus" to Screen.FOCUS, "Study" to Screen.STUDY, "Journal" to Screen.JOURNAL, "Screen time" to Screen.WELLBEING,
                "Tools" to Screen.TOOLS, "Settings" to Screen.SETTINGS,
            )
            items.chunked(2).forEach { pair ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    pair.forEach { (label, target) ->
                        Box(
                            Modifier.weight(1f).height(56.dp).glass(14.dp).clickable { vm.go(target) },
                            contentAlignment = Alignment.Center,
                        ) { Text(label, fontSize = 16.sp) }
                    }
                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}
