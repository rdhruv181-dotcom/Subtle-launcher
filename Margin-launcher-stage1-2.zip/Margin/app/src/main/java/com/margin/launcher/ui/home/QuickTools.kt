package com.margin.launcher.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.margin.launcher.Screen
import com.margin.launcher.ui.components.GIcon
import com.margin.launcher.ui.components.LineIcon
import com.margin.launcher.ui.components.tactile
import com.margin.launcher.ui.theme.M

data class ToolDef(val screen: Screen, val label: String, val icon: GIcon, val c1: Color, val c2: Color)

/** Everything that can be pinned to the four home shortcuts. */
val ALL_TOOLS: List<ToolDef> = listOf(
    ToolDef(Screen.TASKS, "Tasks", GIcon.CHECK_CIRCLE, Color(0xFF4FA3FF), Color(0xFF1F6BFF)),
    ToolDef(Screen.PLANNER, "Calendar", GIcon.CALENDAR, Color(0xFFFF9A7A), Color(0xFFEE4B4B)),
    ToolDef(Screen.FOCUS, "Focus", GIcon.TIMER, Color(0xFF7C7CFF), Color(0xFF4B3FD6)),
    ToolDef(Screen.NOTES, "Notes", GIcon.NOTE, Color(0xFFFFD84D), Color(0xFFFFA512)),
    ToolDef(Screen.REMINDERS, "Reminders", GIcon.BELL, Color(0xFFFF7EB6), Color(0xFFD6336C)),
    ToolDef(Screen.STUDY, "Study", GIcon.CHART, Color(0xFF4ADE9C), Color(0xFF0EA66B)),
    ToolDef(Screen.JOURNAL, "Journal", GIcon.BOOK, Color(0xFFB690FF), Color(0xFF7A3FD1)),
    ToolDef(Screen.WELLBEING, "Screen time", GIcon.PHONE, Color(0xFF5CE1E6), Color(0xFF0E9AA7)),
    ToolDef(Screen.TOOLS, "Tools", GIcon.TOOLS, Color(0xFFB0B8CC), Color(0xFF6B7490)),
)

fun toolFor(name: String): ToolDef? = ALL_TOOLS.firstOrNull { it.screen.name == name }

/** A coloured glass squircle with a line icon and an optional count badge. */
@Composable
fun QuickToolTile(def: ToolDef, badge: Int, modifier: Modifier, onClick: () -> Unit) {
    val c = M.colors
    val shape = RoundedCornerShape(24.dp)
    Box(modifier.tactile(onClick).semantics { contentDescription = def.label + if (badge > 0) ", $badge pending" else "" }) {
        Box(
            Modifier.fillMaxSize().clip(shape)
                .background(Brush.linearGradient(listOf(def.c1, def.c2)))
                .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.28f), Color.Transparent)))
                .border(1.dp, Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.5f), Color.White.copy(alpha = 0.05f))), shape),
            contentAlignment = Alignment.Center,
        ) { LineIcon(def.icon, tint = Color.White, size = 32.dp) }
        if (badge > 0) {
            Box(
                Modifier.align(Alignment.TopEnd).offset(x = 7.dp, y = (-7).dp).size(24.dp).clip(CircleShape)
                    .background(c.alert).border(2.dp, c.bg, CircleShape),
                contentAlignment = Alignment.Center,
            ) { Text(if (badge > 9) "9+" else "$badge", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White) }
        }
    }
}
