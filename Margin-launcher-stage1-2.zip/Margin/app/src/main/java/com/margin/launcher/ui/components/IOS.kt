package com.margin.launcher.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.margin.launcher.ui.theme.M
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/** A rounded-square app-style icon with a white glyph, as used in iOS Settings rows. */
@Composable
fun IconTile(icon: GIcon, color: Color, size: Dp = 30.dp) {
    Box(
        Modifier.size(size).clip(RoundedCornerShape(size * 0.24f))
            .background(Brush.verticalGradient(listOf(color.copy(alpha = 0.95f), color.copy(alpha = 0.78f)))),
        contentAlignment = Alignment.Center,
    ) { LineIcon(icon, tint = Color.White, size = size * 0.62f) }
}

/** Header above a group, in small grey capitals. */
@Composable
fun GroupHeader(text: String) {
    Text(
        text.uppercase(), fontSize = 13.sp, color = M.colors.secondary, letterSpacing = 0.3.sp,
        modifier = Modifier.padding(start = 36.dp, end = 20.dp, top = 18.dp, bottom = 7.dp),
    )
}

@Composable
fun GroupFooter(text: String) {
    Text(text, fontSize = 13.sp, color = M.colors.secondary,
        modifier = Modifier.padding(start = 36.dp, end = 36.dp, top = 7.dp, bottom = 4.dp))
}

/** Inset-grouped container: rows sit on one rounded glass panel with hairline dividers between them. */
@Composable
fun InsetGroup(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier.padding(horizontal = 16.dp).fillMaxWidth().glass(20.dp), content = content)
}

@Composable
fun RowDivider(indent: Dp = 16.dp) {
    Box(Modifier.padding(start = indent).fillMaxWidth().height(0.6.dp).background(M.colors.text.copy(alpha = 0.12f)))
}

/** Padding for controls (switches, segmented controls, fields) placed inside an InsetGroup. */
@Composable
fun GroupPad(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), content = content)
}

/** Standard list row: optional coloured icon tile, title, value and a disclosure chevron. */
@Composable
fun ListRow(
    title: String,
    modifier: Modifier = Modifier,
    icon: GIcon? = null,
    iconColor: Color = Color(0xFF0A84FF),
    value: String = "",
    chevron: Boolean = true,
    destructive: Boolean = false,
    onClick: (() -> Unit)? = null,
) {
    val c = M.colors
    Row(
        modifier.fillMaxWidth()
            .then(if (onClick != null) Modifier.clickable(role = Role.Button, onClick = onClick) else Modifier)
            .defaultMinSize(minHeight = 50.dp).padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) { IconTile(icon, iconColor); Spacer(Modifier.width(14.dp)) }
        Text(title, fontSize = 17.sp, color = if (destructive) c.alert else c.text, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
        if (value.isNotEmpty()) Text(value, fontSize = 17.sp, color = c.secondary, modifier = Modifier.padding(start = 8.dp), maxLines = 1)
        if (chevron && onClick != null) { Spacer(Modifier.width(6.dp)); LineIcon(GIcon.CHEVRON_RIGHT, tint = c.secondary.copy(alpha = 0.7f), size = 16.dp) }
    }
}

/** Floating glass tab bar, as at the bottom of iPhone apps. */
@Composable
fun <T> GlassTabBar(items: List<Triple<T, GIcon, String>>, selected: T, onSelect: (T) -> Unit, modifier: Modifier = Modifier) {
    val c = M.colors
    Row(modifier.fillMaxWidth().glass(34.dp, strong = true).padding(6.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        items.forEach { (key, icon, label) ->
            val sel = key == selected
            Column(
                Modifier.weight(1f).clip(RoundedCornerShape(28.dp))
                    .background(if (sel) c.text.copy(alpha = 0.12f) else Color.Transparent)
                    .clickable(role = Role.Tab) { onSelect(key) }.padding(vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                LineIcon(icon, tint = if (sel) c.accent else c.secondary, size = 22.dp)
                Text(label, fontSize = 11.sp, fontWeight = FontWeight.Medium, color = if (sel) c.accent else c.secondary)
            }
        }
    }
}

/** Swipe a row left to reveal a red Delete action; swipe past the threshold to delete. */
@Composable
fun SwipeToDelete(onDelete: () -> Unit, modifier: Modifier = Modifier, radius: Dp = 22.dp, content: @Composable () -> Unit) {
    val c = M.colors
    val dragX = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current
    val threshold = with(density) { 96.dp.toPx() }
    val maxPull = with(density) { 140.dp.toPx() }
    Box(modifier) {
        Box(
            Modifier.matchParentSize().clip(RoundedCornerShape(radius))
                .graphicsLayer { alpha = (-dragX.value / 40f).coerceIn(0f, 1f) }.background(c.alert),
            contentAlignment = Alignment.CenterEnd,
        ) {
            Text("Delete", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = Color.White, modifier = Modifier.padding(end = 28.dp))
        }
        Box(
            Modifier.offset { IntOffset(dragX.value.roundToInt(), 0) }
                .pointerInput(Unit) {
                    detectHorizontalDragGestures(
                        onDragEnd = { scope.launch { if (dragX.value < -threshold) onDelete() else dragX.animateTo(0f, spring(dampingRatio = 0.8f)) } },
                        onDragCancel = { scope.launch { dragX.animateTo(0f, spring(dampingRatio = 0.8f)) } },
                    ) { change, dx ->
                        change.consume()
                        scope.launch { dragX.snapTo((dragX.value + dx).coerceIn(-maxPull, 0f)) }
                    }
                }
        ) { content() }
    }
}
