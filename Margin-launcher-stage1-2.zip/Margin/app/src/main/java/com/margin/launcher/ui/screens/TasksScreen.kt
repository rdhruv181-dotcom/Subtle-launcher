package com.margin.launcher.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.margin.launcher.LauncherViewModel
import com.margin.launcher.UiState
import com.margin.launcher.core.*
import com.margin.launcher.data.StudyStore
import com.margin.launcher.ui.components.*
import com.margin.launcher.ui.theme.M
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter

private val TIME_FMT = DateTimeFormatter.ofPattern("HH:mm")

fun dueText(t: Task, today: LocalDate): String {
    val due = t.due ?: return ""
    val d = TimeUtil.toDate(due)
    val base = when (d) {
        today -> "Today"
        today.plusDays(1) -> "Tomorrow"
        today.minusDays(1) -> "Yesterday"
        else -> d.format(DAY_FMT)
    }
    return if (t.hasTime) base + " " + TimeUtil.toTime(due).format(TIME_FMT) else base
}

@Composable
fun TasksScreen(vm: LauncherViewModel, state: UiState, onBack: () -> Unit) {
    val store = vm.store
    val c = M.colors
    val tasks by store.tasks.items.collectAsState()
    val today = LocalDate.now()
    val now = System.currentTimeMillis()
    var tab by remember { mutableIntStateOf(0) }
    var cat by remember { mutableStateOf<String?>(null) }
    var editing by remember { mutableStateOf<Task?>(null) }
    var editingIsNew by remember { mutableStateOf(false) }
    var quick by remember { mutableStateOf("") }
    var quickDate by remember { mutableIntStateOf(0) }
    val askNotif = rememberNotifPermission()

    val e = editing
    if (e != null) {
        TaskEditor(store, e, editingIsNew, askNotif) { editing = null }
        return
    }

    val open = tasks.filter { !it.done && (cat == null || it.category == cat) }
    val cmp = compareBy<Task>({ it.due ?: Long.MAX_VALUE }, { -it.priority })
    val todayList = open.filter { t -> t.due != null && !TimeUtil.toDate(t.due).isAfter(today) }.sortedWith(cmp)
    val upcoming = open.filter { t -> t.due == null || TimeUtil.toDate(t.due).isAfter(today) }.sortedWith(cmp)
    val done = tasks.filter { it.done && (cat == null || it.category == cat) }.sortedByDescending { it.doneAt ?: 0L }
    val doneToday = tasks.count { t -> t.done && t.doneAt != null && TimeUtil.toDate(t.doneAt) == today }
    val shown = when (tab) { 0 -> todayList; 1 -> upcoming; else -> done }

    fun addQuick() {
        val title = quick.trim()
        if (title.isEmpty()) return
        val due = when (quickDate) {
            0 -> TimeUtil.millis(today, 9, 0)
            1 -> TimeUtil.millis(today.plusDays(1), 9, 0)
            2 -> TimeUtil.millis(today.plusDays(7), 9, 0)
            else -> null
        }
        store.saveTask(Task(id = Ids.next(), title = title, due = due))
        quick = ""
        if (quickDate == 0) tab = 0 else if (due != null) tab = 1
    }

    Page("Tasks", onBack, action = {
        Btn("+ New", { editingIsNew = true; editing = Task(id = Ids.next(), title = "", due = TimeUtil.millis(today, 9, 0)) }, primary = false)
    }) {
        Column(Modifier.padding(horizontal = 24.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            val total = todayList.size + doneToday
            if (total > 0) {
                Text("$doneToday of $total done today", fontSize = 14.sp, color = c.secondary)
                ProgressBar(doneToday / total.toFloat())
            }
            Segmented(listOf(0 to "Today (${todayList.size})", 1 to "Upcoming", 2 to "Done"), tab) { tab = it }
            Chips {
                Chip("All", cat == null) { cat = null }
                TASK_CATEGORIES.forEach { k -> Chip(k, cat == k) { cat = if (cat == k) null else k } }
            }
        }

        LazyColumn(Modifier.weight(1f).padding(horizontal = 16.dp), contentPadding = PaddingValues(vertical = 8.dp)) {
            if (shown.isEmpty()) {
                item {
                    Text(
                        when (tab) { 0 -> "Nothing due today."; 1 -> "Nothing upcoming."; else -> "No completed tasks yet." },
                        color = c.secondary, modifier = Modifier.padding(24.dp),
                    )
                }
            }
            items(shown, key = { it.id }) { t ->
                TaskRow(t, today, now, onToggle = { store.toggleTask(t) }, onOpen = { editingIsNew = false; editing = t })
            }
        }

        // Quick add: type, pick a day, press Add.
        Column(Modifier.padding(horizontal = 24.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Chips {
                listOf("Today", "Tomorrow", "Next week", "No date").forEachIndexed { i, l -> Chip(l, quickDate == i) { quickDate = i } }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Field(quick, { quick = it }, "Add a task", Modifier.weight(1f), imeAction = ImeAction.Done, onDone = { addQuick() })
                Btn("Add", { addQuick() })
            }
        }
    }
}

@Composable
private fun TaskRow(t: Task, today: LocalDate, now: Long, onToggle: () -> Unit, onOpen: () -> Unit) {
    val c = M.colors
    val overdue = TaskLogic.isOverdue(t, now)
    val meta = listOfNotNull(
        t.subject.ifEmpty { null },
        t.category.takeIf { it != "College" },
        if (t.due != null) dueText(t, today) + if (t.repeat != Repeat.NONE) " ↻" else "" else null,
        if (t.subtasks.isNotEmpty()) "${t.subtasks.count { it.done }}/${t.subtasks.size}" else null,
    ).joinToString(" · ")
    Row(Modifier.fillMaxWidth().clickable(onClick = onOpen), verticalAlignment = Alignment.CenterVertically) {
        CheckCircle(t.done, onToggle, (if (t.done) "Mark not done: " else "Complete: ") + t.title)
        Column(Modifier.weight(1f).padding(vertical = 6.dp)) {
            Text(
                t.title, fontSize = 17.sp, maxLines = 2, overflow = TextOverflow.Ellipsis,
                textDecoration = if (t.done) TextDecoration.LineThrough else null,
                color = if (t.done) c.secondary else c.text,
            )
            if (meta.isNotEmpty()) Text(
                (if (overdue) "Overdue · " else "") + meta, fontSize = 13.sp,
                color = if (overdue) c.alert else c.secondary,
            )
            if (t.subtasks.isNotEmpty() && !t.done) ProgressBar(TaskLogic.progress(t), Modifier.padding(top = 6.dp, end = 12.dp))
        }
        if (t.priority == 2 && !t.done) Text("High", fontSize = 12.sp, color = c.alert, modifier = Modifier.padding(end = 12.dp))
    }
}

@Composable
private fun TaskEditor(store: StudyStore, original: Task, isNew: Boolean, askNotif: () -> Unit, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val c = M.colors
    var title by remember { mutableStateOf(original.title) }
    var due by remember { mutableStateOf(original.due) }
    var hasTime by remember { mutableStateOf(original.hasTime) }
    var priority by remember { mutableIntStateOf(original.priority) }
    var category by remember { mutableStateOf(original.category) }
    var subject by remember { mutableStateOf(original.subject) }
    var repeat by remember { mutableStateOf(original.repeat) }
    var remind by remember { mutableIntStateOf(original.remindBefore) }
    val subs = remember { mutableStateListOf<SubTask>().apply { addAll(original.subtasks) } }
    var newSub by remember { mutableStateOf("") }
    BackHandler(onBack = onClose)

    Page(if (isNew) "New task" else "Edit task", onClose) {
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Field(title, { title = it }, "What needs doing?")

            Label("Due")
            Chips {
                val cur = due
                val date = cur?.let { TimeUtil.toDate(it) } ?: LocalDate.now()
                Chip(if (cur != null) date.format(DAY_FMT) else "Pick a date", cur != null) {
                    pickDate(ctx, date) { nd ->
                        val tm = if (hasTime && cur != null) TimeUtil.toTime(cur) else LocalTime.of(9, 0)
                        due = TimeUtil.millis(nd, tm.hour, tm.minute)
                    }
                }
                Chip(if (hasTime && cur != null) TimeUtil.toTime(cur).format(TIME_FMT) else "Add time", hasTime) {
                    val tm = if (cur != null) TimeUtil.toTime(cur) else LocalTime.of(9, 0)
                    pickTime(ctx, tm.hour, tm.minute) { h, m -> hasTime = true; due = TimeUtil.millis(date, h, m) }
                }
                if (cur != null) Chip("Clear", false) { due = null; hasTime = false; remind = -1 }
            }

            Label("Priority")
            Segmented(listOf(0 to "Low", 1 to "Normal", 2 to "High"), priority) { priority = it }

            Label("Category")
            Chips { TASK_CATEGORIES.forEach { k -> Chip(k, category == k) { category = k } } }

            Label("Subject")
            SubjectPicker(store, subject) { subject = it }

            Label("Checklist")
            subs.forEachIndexed { i, s ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CheckCircle(s.done, { subs[i] = s.copy(done = !s.done) }, "Subtask: ${s.title}")
                    Text(s.title, fontSize = 16.sp, modifier = Modifier.weight(1f),
                        textDecoration = if (s.done) TextDecoration.LineThrough else null)
                    Text("Remove", fontSize = 13.sp, color = c.secondary,
                        modifier = Modifier.clickable { subs.removeAt(i) }.padding(8.dp))
                }
            }
            Field(newSub, { newSub = it }, "Add a step", imeAction = ImeAction.Done,
                onDone = { if (newSub.isNotBlank()) { subs.add(SubTask(newSub.trim())); newSub = "" } })

            Label("Repeat")
            Segmented(listOf(Repeat.NONE to "Never", Repeat.DAILY to "Daily", Repeat.WEEKLY to "Weekly", Repeat.MONTHLY to "Monthly"), repeat) { repeat = it }

            if (due != null) {
                Label("Remind me")
                Segmented(listOf(-1 to "Off", 0 to "On time", 60 to "1 hour", 1440 to "1 day"), remind) { remind = it }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(vertical = 12.dp)) {
                Btn("Save", {
                    val t = original.copy(
                        title = title.trim(), due = due, hasTime = hasTime, priority = priority, category = category,
                        subject = subject, subtasks = subs.toList(), repeat = repeat,
                        remindBefore = if (due == null) -1 else remind,
                    )
                    if (t.title.isNotEmpty()) {
                        if (t.remindBefore >= 0) askNotif()
                        store.saveTask(t)
                        onClose()
                    }
                }, Modifier.weight(1f))
                if (!isNew) Btn("Delete", { store.deleteTask(original.id); onClose() }, primary = false, danger = true)
            }
        }
    }
}
