package com.margin.launcher.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.margin.launcher.LauncherViewModel
import com.margin.launcher.UiState
import com.margin.launcher.core.*
import com.margin.launcher.data.StudyStore
import com.margin.launcher.ui.components.*
import com.margin.launcher.ui.theme.IOS
import com.margin.launcher.ui.theme.M
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.time.temporal.TemporalAdjusters

private val TIME_FMT = DateTimeFormatter.ofPattern("HH:mm")

fun dueText(t: Task, today: LocalDate): String {
    val due = t.due ?: return ""
    val d = TimeUtil.toDate(due)
    val base = when (d) {
        today -> "Today"
        today.plusDays(1) -> "Tomorrow"
        today.minusDays(1) -> "Yesterday"
        else -> d.format(DAY_FMT)
    }
    return if (t.hasTime) base + " " + TimeUtil.toTime(due).format(TIME_FMT) else base
}

private val CATEGORY_COLORS = mapOf(
    "College" to IOS.Blue, "Assignment" to IOS.Orange, "Exams" to IOS.Red, "Projects" to IOS.Purple, "Personal" to IOS.Green,
)

private data class Smart(val key: String, val title: String, val icon: GIcon, val color: Color, val count: Int)

/** Laid out like Apple Reminders: smart-list tiles, then your lists, then a list with a coloured title. */
@Composable
fun TasksScreen(vm: LauncherViewModel, state: UiState, onBack: () -> Unit) {
    val store = vm.store
    val c = M.colors
    val tasks by store.tasks.items.collectAsState()
    val today = LocalDate.now()
    val now = System.currentTimeMillis()
    var view by remember { mutableStateOf<String?>(null) }     // null = lists, else "today", "cat:Exams", ...
    var editing by remember { mutableStateOf<Task?>(null) }
    var editingIsNew by remember { mutableStateOf(false) }
    var quick by remember { mutableStateOf("") }
    var quickDate by remember { mutableStateOf<LocalDate?>(today) }
    var pickQuickDate by remember { mutableStateOf(false) }
    val askNotif = rememberNotifPermission()
    BackHandler(enabled = view != null && editing == null) { view = null }

    val e = editing
    if (e != null) {
        TaskEditor(store, e, editingIsNew, askNotif) { editing = null }
        return
    }

    val openItems = tasks.filter { !it.done }
    val cmp = compareBy<Task>({ it.due ?: Long.MAX_VALUE }, { -it.priority })
    val overdue = openItems.filter { TaskLogic.isOverdue(it, now) }.sortedWith(cmp)
    val todayList = openItems.filter { t -> t.due != null && TimeUtil.toDate(t.due) == today }.sortedWith(cmp)
    val upcoming = openItems.filter { t -> t.due == null || TimeUtil.toDate(t.due).isAfter(today) }.sortedWith(cmp)
    val done = tasks.filter { it.done }.sortedByDescending { it.doneAt ?: 0L }
    val smart = listOf(
        Smart("today", "Today", GIcon.CALENDAR, IOS.Blue, todayList.size),
        Smart("upcoming", "Upcoming", GIcon.CALENDAR, IOS.Red, upcoming.size),
        Smart("overdue", "Overdue", GIcon.BELL, IOS.Orange, overdue.size),
        Smart("all", "All", GIcon.LIST, IOS.Gray, openItems.size),
        Smart("completed", "Completed", GIcon.CHECK_CIRCLE, IOS.Green, done.size),
    )

    fun openEditor(due: Long?, category: String = "College") {
        editingIsNew = true
        editing = Task(id = Ids.next(), title = "", due = due, category = category)
    }

    val v = view
    if (v == null) {
        // ------------------------------------------------------------ lists home
        Page("Tasks", onBack, action = {
            GlassIconButton(GIcon.PLUS, "New task", { openEditor(TimeUtil.millis(today, 9, 0)) }, size = 40.dp)
        }) {
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
                Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    smart.chunked(2).forEach { pair ->
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            pair.forEach { sm -> SmartTile(sm, Modifier.weight(1f)) { view = sm.key } }
                            if (pair.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }
                }
                GroupHeader("My lists")
                InsetGroup {
                    TASK_CATEGORIES.forEachIndexed { i, cat ->
                        if (i > 0) RowDivider(60.dp)
                        ListRow(cat, icon = GIcon.LIST, iconColor = CATEGORY_COLORS[cat] ?: IOS.Blue,
                            value = "${openItems.count { it.category == cat }}", onClick = { view = "cat:$cat" })
                    }
                }
                GroupFooter("Swipe a task left to delete it.")
            }
        }
        return
    }

    // ---------------------------------------------------------------- a single list
    val cat = if (v.startsWith("cat:")) v.removePrefix("cat:") else null
    val listColor = cat?.let { CATEGORY_COLORS[it] } ?: smart.firstOrNull { it.key == v }?.color ?: IOS.Blue
    val listTitle = cat ?: smart.firstOrNull { it.key == v }?.title ?: "Tasks"
    val shown = when {
        cat != null -> openItems.filter { it.category == cat }.sortedWith(cmp)
        v == "today" -> todayList
        v == "upcoming" -> upcoming
        v == "overdue" -> overdue
        v == "completed" -> done
        else -> openItems.sortedWith(cmp) + done
    }

    fun addQuick() {
        val title = quick.trim()
        if (title.isEmpty()) return
        store.saveTask(Task(id = Ids.next(), title = title, category = cat ?: "College",
            due = quickDate?.let { TimeUtil.millis(it, 9, 0) }))
        quick = ""
    }

    Page(listTitle, { view = null }, backLabel = "Lists", titleColor = listColor, action = {
        Text("${shown.size}", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = listColor, modifier = Modifier.padding(end = 10.dp))
        GlassIconButton(GIcon.PLUS, "New task", { openEditor(quickDate?.let { TimeUtil.millis(it, 9, 0) }, cat ?: "College") }, size = 40.dp)
    }) {
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(vertical = 8.dp)) {
            if (shown.isEmpty()) {
                item { Text("No tasks", color = c.secondary, fontSize = 17.sp, modifier = Modifier.padding(horizontal = 24.dp, vertical = 16.dp)) }
            }
            items(shown, key = { it.id }) { t ->
                SwipeToDelete(onDelete = { store.deleteTask(t.id) }, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp), radius = 18.dp) {
                    TaskRow(t, today, now, listColor, onToggle = { store.toggleTask(t) }, onOpen = { editingIsNew = false; editing = t })
                }
            }
        }

        // Inline add, like tapping "New Reminder" at the bottom of a list.
        Column(Modifier.padding(horizontal = 16.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Chips {
                Chip("Today", quickDate == today) { quickDate = today }
                Chip("Tomorrow", quickDate == today.plusDays(1)) { quickDate = today.plusDays(1) }
                Chip("No date", quickDate == null) { quickDate = null }
                val custom = quickDate
                val isCustom = custom != null && custom != today && custom != today.plusDays(1)
                Chip(if (isCustom && custom != null) custom.format(DAY_FMT) else "Pick date", isCustom) { pickQuickDate = true }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Field(quick, { quick = it }, "New task", Modifier.weight(1f), imeAction = ImeAction.Done, onDone = { addQuick() })
                Btn("Add", { addQuick() })
            }
        }
    }

    if (pickQuickDate) {
        GlassDateTimePicker(PickMode.DATE, "Due date", quickDate, null, allowClear = true,
            onDismiss = { pickQuickDate = false }) { d, _ -> quickDate = d; pickQuickDate = false }
    }
}

@Composable
private fun SmartTile(sm: Smart, modifier: Modifier, onClick: () -> Unit) {
    val c = M.colors
    GlassCard(modifier, radius = 22.dp, onClick = onClick) {
        Column(Modifier.padding(horizontal = 14.dp, vertical = 12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(34.dp).clip(CircleShape).background(sm.color), contentAlignment = Alignment.Center) {
                    LineIcon(sm.icon, tint = Color.White, size = 20.dp)
                }
                Spacer(Modifier.weight(1f))
                Text("${sm.count}", fontSize = 30.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(8.dp))
            Text(sm.title, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = c.secondary)
        }
    }
}

@Composable
private fun TaskRow(t: Task, today: LocalDate, now: Long, listColor: Color, onToggle: () -> Unit, onOpen: () -> Unit) {
    val c = M.colors
    val overdue = TaskLogic.isOverdue(t, now)
    val meta = listOfNotNull(
        t.subject.ifEmpty { null },
        if (t.due != null) dueText(t, today) + if (t.repeat != Repeat.NONE) " ↻" else "" else null,
        if (t.subtasks.isNotEmpty()) "${t.subtasks.count { it.done }}/${t.subtasks.size}" else null,
    ).joinToString(" · ")
    GlassCard(Modifier.fillMaxWidth(), radius = 18.dp, onClick = onOpen) {
        Row(Modifier.padding(end = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            CheckCircle(t.done, onToggle, (if (t.done) "Mark not done: " else "Complete: ") + t.title, tint = listColor)
            Column(Modifier.weight(1f).padding(vertical = 10.dp)) {
                Text(
                    (if (t.priority == 2 && !t.done) "! " else "") + t.title, fontSize = 17.sp, maxLines = 2, overflow = TextOverflow.Ellipsis,
                    textDecoration = if (t.done) TextDecoration.LineThrough else null,
                    color = if (t.done) c.secondary else c.text,
                )
                if (meta.isNotEmpty()) Text((if (overdue) "Overdue · " else "") + meta, fontSize = 13.sp, color = if (overdue) c.alert else c.secondary)
                if (t.subtasks.isNotEmpty() && !t.done) ProgressBar(TaskLogic.progress(t), Modifier.padding(top = 6.dp, end = 8.dp), color = listColor)
            }
        }
    }
}

/** The "New Reminder" modal: Cancel / Add, grouped sections. */
@Composable
private fun TaskEditor(store: StudyStore, original: Task, isNew: Boolean, askNotif: () -> Unit, onClose: () -> Unit) {
    val c = M.colors
    var title by remember { mutableStateOf(original.title) }
    var description by remember { mutableStateOf(original.description) }
    var due by remember { mutableStateOf(original.due) }
    var hasTime by remember { mutableStateOf(original.hasTime) }
    var priority by remember { mutableIntStateOf(original.priority) }
    var category by remember { mutableStateOf(original.category) }
    var subject by remember { mutableStateOf(original.subject) }
    var repeat by remember { mutableStateOf(original.repeat) }
    var remind by remember { mutableIntStateOf(original.remindBefore) }
    val subs = remember { mutableStateListOf<SubTask>().apply { addAll(original.subtasks) } }
    var newSub by remember { mutableStateOf("") }
    var picker by remember { mutableStateOf(false) }
    BackHandler(onBack = onClose)

    fun setDate(d: LocalDate) {
        val cur = due
        val tm = if (hasTime && cur != null) TimeUtil.toTime(cur) else LocalTime.of(9, 0)
        due = TimeUtil.millis(d, tm.hour, tm.minute)
    }
    val today = LocalDate.now()
    val curDate = due?.let { TimeUtil.toDate(it) }

    fun save() {
        val t = original.copy(
            title = title.trim(), description = description.trim(), due = due, hasTime = hasTime,
            priority = priority, category = category, subject = subject, subtasks = subs.toList(),
            repeat = repeat, remindBefore = if (due == null) -1 else remind,
        )
        if (t.title.isNotEmpty()) {
            if (t.remindBefore >= 0) askNotif()
            store.saveTask(t)
            onClose()
        }
    }

    ModalPage(if (isNew) "New Task" else "Details", onClose, { save() }, if (isNew) "Add" else "Done") {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(bottom = 32.dp)) {
            Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Field(title, { title = it }, "Title")
                Field(description, { description = it }, "Notes", singleLine = false, minLines = 3)
            }

            GroupHeader("Date")
            InsetGroup {
                ListRow("Date", icon = GIcon.CALENDAR, iconColor = IOS.Red,
                    value = curDate?.let { it.format(DAY_FMT) + " " + it.year } ?: "None", onClick = { picker = true })
                if (due != null) {
                    RowDivider(60.dp)
                    ListRow("Time", icon = GIcon.TIMER, iconColor = IOS.Blue,
                        value = if (hasTime) due?.let { fmtClock(TimeUtil.toTime(it).let { t -> t.hour * 60 + t.minute }, false) } ?: "" else "None",
                        onClick = { picker = true })
                }
                RowDivider()
                GroupPad {
                    Chips {
                        Chip("Today", curDate == today) { setDate(today) }
                        Chip("Tomorrow", curDate == today.plusDays(1)) { setDate(today.plusDays(1)) }
                        val weekend = today.with(TemporalAdjusters.nextOrSame(DayOfWeek.SATURDAY))
                        Chip("This weekend", curDate == weekend) { setDate(weekend) }
                        Chip("Custom date", curDate != null && curDate != today && curDate != today.plusDays(1) && curDate != weekend) { picker = true }
                        if (due != null) Chip("Clear", false) { due = null; hasTime = false; remind = -1 }
                    }
                }
            }

            GroupHeader("Details")
            InsetGroup {
                GroupPad { Segmented(listOf(0 to "Low", 1 to "Normal", 2 to "High"), priority) { priority = it } }
                RowDivider()
                GroupPad { Chips { TASK_CATEGORIES.forEach { k -> Chip(k, category == k) { category = k } } } }
                RowDivider()
                GroupPad { SubjectPicker(store, subject) { subject = it } }
            }

            GroupHeader("Subtasks")
            InsetGroup {
                GroupPad {
                    subs.forEachIndexed { i, s ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CheckCircle(s.done, { subs[i] = s.copy(done = !s.done) }, "Subtask: ${s.title}")
                            Text(s.title, fontSize = 16.sp, modifier = Modifier.weight(1f), textDecoration = if (s.done) TextDecoration.LineThrough else null)
                            Text("Remove", fontSize = 13.sp, color = c.secondary, modifier = Modifier.clickable { subs.removeAt(i) }.padding(8.dp))
                        }
                    }
                    Field(newSub, { newSub = it }, "Add a step", imeAction = ImeAction.Done,
                        onDone = { if (newSub.isNotBlank()) { subs.add(SubTask(newSub.trim())); newSub = "" } })
                }
            }

            GroupHeader("Repeat and reminder")
            InsetGroup {
                GroupPad { Segmented(listOf(Repeat.NONE to "Never", Repeat.DAILY to "Daily", Repeat.WEEKLY to "Weekly", Repeat.MONTHLY to "Monthly"), repeat) { repeat = it } }
                if (due != null) {
                    RowDivider()
                    GroupPad { Segmented(listOf(-1 to "No alert", 0 to "On time", 60 to "1 hour", 1440 to "1 day"), remind) { remind = it } }
                }
            }

            if (!isNew) {
                Spacer(Modifier.height(18.dp))
                InsetGroup { ListRow("Delete Task", destructive = true, chevron = false, onClick = { store.deleteTask(original.id); onClose() }) }
            }
        }
    }

    if (picker) {
        val cur = due
        GlassDateTimePicker(
            PickMode.DATE_TIME, "Due date and time",
            initialDate = curDate,
            initialMinute = if (hasTime && cur != null) TimeUtil.toTime(cur).let { it.hour * 60 + it.minute } else null,
            allowClear = true,
            onDismiss = { picker = false },
        ) { d, minute ->
            if (d == null) { due = null; hasTime = false; remind = -1 }
            else { due = TimeUtil.millis(d, (minute ?: 540) / 60, (minute ?: 540) % 60); hasTime = minute != null }
            picker = false
        }
    }
}
