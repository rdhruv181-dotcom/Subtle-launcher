package com.margin.launcher.ui.screens

import android.app.DownloadManager
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.provider.MediaStore
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.margin.launcher.LauncherViewModel
import com.margin.launcher.UiState
import com.margin.launcher.system.Alarms
import com.margin.launcher.ui.components.*
import com.margin.launcher.ui.theme.M
import kotlinx.coroutines.delay
import kotlin.math.abs

@Composable
fun ToolsScreen(vm: LauncherViewModel, state: UiState, onBack: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    Page("Tools", onBack) {
        Column(Modifier.padding(horizontal = 24.dp)) {
            Chips {
                listOf("Calculator", "Stopwatch", "Timer", "Convert", "Shortcuts").forEachIndexed { i, l -> Chip(l, tab == i) { tab = i } }
            }
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(24.dp)) {
            when (tab) {
                0 -> Calculator()
                1 -> Stopwatch()
                2 -> TimerTool()
                3 -> Converter()
                else -> Shortcuts(vm)
            }
        }
    }
}

// ---------------- Calculator ----------------
@Composable
private fun Calculator() {
    val c = M.colors
    var display by remember { mutableStateOf("0") }
    var acc by remember { mutableStateOf<Double?>(null) }
    var op by remember { mutableStateOf<Char?>(null) }
    var fresh by remember { mutableStateOf(true) }

    fun fmt(d: Double): String =
        if (d.isNaN() || d.isInfinite()) "Error"
        else if (d == Math.rint(d) && abs(d) < 1e12) d.toLong().toString()
        else "%.8f".format(d).trimEnd('0').trimEnd('.')

    fun apply(a: Double, b: Double, o: Char): Double = when (o) {
        '+' -> a + b
        '−' -> a - b
        '×' -> a * b
        else -> if (b == 0.0) Double.NaN else a / b
    }

    fun press(k: String) {
        when {
            k[0].isDigit() -> { display = if (fresh || display == "0") k else display + k; fresh = false }
            k == "." -> { if (fresh) { display = "0."; fresh = false } else if (!display.contains('.')) display += "." }
            k == "C" -> { display = "0"; acc = null; op = null; fresh = true }
            k == "⌫" -> { display = if (!fresh && display.length > 1) display.dropLast(1) else "0" }
            k == "%" -> display = fmt((display.toDoubleOrNull() ?: 0.0) / 100)
            k == "=" -> {
                val a = acc; val o = op
                if (a != null && o != null) { display = fmt(apply(a, display.toDoubleOrNull() ?: 0.0, o)); acc = null; op = null; fresh = true }
            }
            else -> {
                val cur = display.toDoubleOrNull() ?: 0.0
                val a = acc; val o = op
                val next = if (a != null && o != null && !fresh) apply(a, cur, o) else cur
                acc = next; display = fmt(next); op = k[0]; fresh = true
            }
        }
    }

    Text(display, fontSize = 56.sp, fontWeight = FontWeight.Light, textAlign = TextAlign.End, maxLines = 1,
        modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp))
    val rows = listOf(listOf("C", "⌫", "%", "÷"), listOf("7", "8", "9", "×"), listOf("4", "5", "6", "−"), listOf("1", "2", "3", "+"), listOf("0", ".", "="))
    rows.forEach { row ->
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            row.forEach { k ->
                val isOp = k in listOf("÷", "×", "−", "+", "=")
                Box(
                    Modifier.weight(if (k == "0") 2f else 1f).height(60.dp).clip(RoundedCornerShape(14.dp))
                        .background(if (isOp) c.accent else c.surface).clickable { press(k) },
                    contentAlignment = Alignment.Center,
                ) { Text(k, fontSize = 22.sp, color = if (isOp) c.onAccent else c.text) }
            }
        }
    }
}

// ---------------- Stopwatch ----------------
@Composable
private fun Stopwatch() {
    var running by remember { mutableStateOf(false) }
    var base by remember { mutableLongStateOf(0L) }          // accumulated ms while stopped
    var startedAt by remember { mutableLongStateOf(0L) }
    var shown by remember { mutableLongStateOf(0L) }
    LaunchedEffect(running) { while (running) { shown = base + System.currentTimeMillis() - startedAt; delay(40) } }
    val t = shown
    Text("%02d:%02d.%02d".format(t / 60000, t / 1000 % 60, t / 10 % 100), fontSize = 56.sp, fontWeight = FontWeight.Light,
        modifier = Modifier.fillMaxWidth().padding(vertical = 24.dp), textAlign = TextAlign.Center)
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
        Btn(if (running) "Stop" else "Start", {
            if (running) { base += System.currentTimeMillis() - startedAt; running = false }
            else { startedAt = System.currentTimeMillis(); running = true }
        }, Modifier.weight(1f))
        Btn("Reset", { running = false; base = 0; shown = 0 }, Modifier.weight(1f), primary = false)
    }
}

// ---------------- Timer ----------------
@Composable
private fun TimerTool() {
    val ctx = LocalContext.current
    var minutes by remember { mutableIntStateOf(10) }
    var endAt by remember { mutableLongStateOf(0L) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    val running = endAt > now
    LaunchedEffect(endAt) { while (System.currentTimeMillis() < endAt) { now = System.currentTimeMillis(); delay(250) }; now = System.currentTimeMillis() }
    val left = if (running) (endAt - now + 999) / 1000 else minutes * 60L
    Text("%02d:%02d".format(left / 60, left % 60), fontSize = 56.sp, fontWeight = FontWeight.Light,
        modifier = Modifier.fillMaxWidth().padding(vertical = 24.dp), textAlign = TextAlign.Center)
    if (!running) Chips { listOf(1, 5, 10, 15, 30, 45, 60).forEach { m -> Chip("$m min", minutes == m) { minutes = m } } }
    Spacer(Modifier.height(16.dp))
    Btn(if (running) "Cancel" else "Start timer", {
        if (running) { Alarms.cancel(ctx, "timer", 1); endAt = 0 }
        else {
            endAt = System.currentTimeMillis() + minutes * 60_000L
            now = System.currentTimeMillis()
            // An alarm makes the timer ring even if Margin is closed.
            Alarms.schedule(ctx, "timer", 1, endAt, "Timer finished", "$minutes minute timer is up")
        }
    }, Modifier.fillMaxWidth())
}

// ---------------- Unit converter ----------------
private data class UnitDef(val name: String, val toBase: Double)
private val CATEGORIES: Map<String, List<UnitDef>> = mapOf(
    "Length" to listOf(UnitDef("m", 1.0), UnitDef("km", 1000.0), UnitDef("cm", 0.01), UnitDef("mm", 0.001), UnitDef("mi", 1609.344), UnitDef("ft", 0.3048), UnitDef("in", 0.0254)),
    "Mass" to listOf(UnitDef("kg", 1.0), UnitDef("g", 0.001), UnitDef("lb", 0.45359237), UnitDef("oz", 0.028349523)),
    "Volume" to listOf(UnitDef("L", 1.0), UnitDef("mL", 0.001), UnitDef("cup", 0.2365882), UnitDef("gal", 3.785411784)),
    "Temp" to listOf(UnitDef("°C", 1.0), UnitDef("°F", 1.0), UnitDef("K", 1.0)),
)

private fun convert(cat: String, v: Double, from: UnitDef, to: UnitDef): Double {
    if (cat == "Temp") {
        val c = when (from.name) { "°F" -> (v - 32) * 5 / 9; "K" -> v - 273.15; else -> v }
        return when (to.name) { "°F" -> c * 9 / 5 + 32; "K" -> c + 273.15; else -> c }
    }
    return v * from.toBase / to.toBase
}

@Composable
private fun Converter() {
    val c = M.colors
    var cat by remember { mutableStateOf("Length") }
    var from by remember { mutableIntStateOf(0) }
    var to by remember { mutableIntStateOf(1) }
    var input by remember { mutableStateOf("1") }
    val units = CATEGORIES.getValue(cat)
    val f = units[from.coerceIn(units.indices)]
    val t = units[to.coerceIn(units.indices)]
    val v = input.toDoubleOrNull()
    Chips { CATEGORIES.keys.forEach { k -> Chip(k, cat == k) { cat = k; from = 0; to = 1 } } }
    Spacer(Modifier.height(12.dp))
    Field(input, { input = it.filter { ch -> ch.isDigit() || ch == '.' || ch == '-' }.take(15) }, "Value", keyboardType = KeyboardType.Decimal)
    Label("From", Modifier.padding(top = 12.dp))
    Chips { units.forEachIndexed { i, u -> Chip(u.name, from == i) { from = i } } }
    Label("To", Modifier.padding(top = 12.dp))
    Chips { units.forEachIndexed { i, u -> Chip(u.name, to == i) { to = i } } }
    Text(
        if (v == null) "Enter a number" else "%.6f".format(convert(cat, v, f, t)).trimEnd('0').trimEnd('.') + " " + t.name,
        fontSize = 32.sp, fontWeight = FontWeight.Light, modifier = Modifier.padding(top = 24.dp),
    )
}

// ---------------- Shortcuts: clipboard, QR, files ----------------
@Composable
private fun Shortcuts(vm: LauncherViewModel) {
    val ctx = LocalContext.current
    val c = M.colors
    Label("Clipboard")
    LinkRow("Save clipboard as a note") {
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val text = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(ctx)?.toString().orEmpty()
        if (text.isBlank()) vm.toast("Clipboard is empty") else { vm.store.addNote(text, "Inbox"); vm.toast("Saved to Notes") }
    }
    LinkRow("Copy latest note") {
        val n = vm.store.notes.items.value.maxByOrNull { it.updated }
        if (n == null) vm.toast("No notes yet") else {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(android.content.ClipData.newPlainText("note", (n.title + "\n" + n.body).trim()))
            vm.toast("Copied")
        }
    }
    Label("Scan", Modifier.padding(top = 16.dp))
    LinkRow("QR scanner (opens your camera)") {
        runCatching { ctx.startActivity(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            .onFailure { vm.toast("No camera app found") }
    }
    Text("Most camera apps read QR codes automatically when you point at one.", fontSize = 13.sp, color = c.secondary)
    Label("Files", Modifier.padding(top = 16.dp))
    LinkRow("Downloads") {
        runCatching { ctx.startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            .onFailure { vm.toast("Couldn't open Downloads") }
    }
    LinkRow("Browse files") {
        runCatching {
            ctx.startActivity(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }.onFailure { vm.toast("No file browser found") }
    }
}
