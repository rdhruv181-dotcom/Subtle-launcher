package com.margin.launcher.system

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.random.Random

/** Generates ambient noise on the fly, so no audio files are bundled. 1 = white, 2 = brown, 3 = rain-like. */
object NoisePlayer {
    @Volatile private var running = false
    @Volatile private var generation = 0
    private var kind = 0

    @Synchronized fun start(k: Int) {
        if (running && kind == k) return
        kind = k
        running = true
        val gen = ++generation
        Thread {
            try { play(k, gen) } catch (_: Exception) { }
        }.also { it.isDaemon = true }.start()
    }

    @Synchronized fun stop() { running = false; generation++ }

    val isPlaying: Boolean get() = running

    private fun play(k: Int, gen: Int) {
        val rate = 22050
        val min = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val track = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(maxOf(min, 8192))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        track.play()
        val buf = ShortArray(2048)
        val rnd = Random(System.nanoTime())
        var brown = 0f
        var low = 0f
        while (running && gen == generation) {
            for (i in buf.indices) {
                val w = rnd.nextFloat() * 2f - 1f
                val v = when (k) {
                    1 -> w * 0.35f
                    2 -> { brown = (brown + 0.02f * w) / 1.02f; brown * 3.5f }
                    else -> { low = low * 0.6f + w * 0.4f; low * 0.8f }
                }
                buf[i] = (v.coerceIn(-1f, 1f) * 10000).toInt().toShort()
            }
            track.write(buf, 0, buf.size)
        }
        track.stop()
        track.release()
    }
}
