package com.margin.launcher.ui.screens

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.margin.launcher.LauncherViewModel
import com.margin.launcher.UiState
import com.margin.launcher.core.fmtDuration
import com.margin.launcher.system.Wellbeing
import com.margin.launcher.system.WellbeingRepo
import com.margin.launcher.ui.components.*
import com.margin.launcher.ui.theme.M
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.format.TextStyle as DowStyle
import java.util.Locale

@Composable
fun WellbeingScreen(vm: LauncherViewModel, state: UiState, onBack: () -> Unit) {
    val c = M.colors
    val ctx = LocalContext.current
    val s = state.settings
    var granted by remember { mutableStateOf(WellbeingRepo.hasAccess(ctx)) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { granted = WellbeingRepo.hasAccess(ctx) }

    val data by produceState<Wellbeing?>(null, granted) {
        value = if (granted) withContext(Dispatchers.IO) {
            runCatching { WellbeingRepo.load(ctx, vm.repo.apps.value) }.getOrNull()
        } else null
    }

    Page("Screen time", onBack) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (!granted) {
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(c.surface).padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("One-time setup", fontSize = 18.sp, fontWeight = FontWeight.Medium)
                    Text("Android only shares app usage with apps you allow in Usage access. Margin reads it on this device only; nothing is uploaded.",
                        fontSize = 15.sp, color = c.secondary)
                    Btn("Open Usage access", { runCatching { ctx.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) } }, Modifier.fillMaxWidth())
                }
            } else {
                val d = data
                if (d == null) {
                    Text("Loading…", color = c.secondary)
                } else {
                    val todayMin = (d.todayMs / 60_000).toInt()
                    Text("Today", fontSize = 14.sp, color = c.secondary)
                    Text(fmtDuration(todayMin), fontSize = 44.sp, fontWeight = FontWeight.Light)
                    ProgressBar(todayMin / s.screenGoalMin.toFloat(), color = if (todayMin > s.screenGoalMin) c.alert else c.accent)
                    Text(
                        if (todayMin > s.screenGoalMin) "Over your ${fmtDuration(s.screenGoalMin)} goal" else "${fmtDuration(s.screenGoalMin - todayMin)} left of your ${fmtDuration(s.screenGoalMin)} goal",
                        fontSize = 13.sp, color = c.secondary,
                    )
                    Text("Unlocked ${d.unlocks} time${if (d.unlocks == 1) "" else "s"} today", fontSize = 15.sp, modifier = Modifier.padding(top = 4.dp))

                    Label("Most used today", Modifier.padding(top = 12.dp))
                    if (d.topToday.isEmpty()) Text("No usage recorded yet.", color = c.secondary)
                    val top = d.topToday.firstOrNull()?.second ?: 1L
                    d.topToday.forEach { (app, ms) ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            AppIcon(app, vm.repo, 30.dp, s.monoIcons)
                            Text(app.label, fontSize = 16.sp, modifier = Modifier.weight(1f).padding(start = 12.dp))
                            Text(fmtDuration((ms / 60_000).toInt()), fontSize = 14.sp, color = c.secondary)
                        }
                        ProgressBar(ms / top.toFloat())
                    }

                    Label("Weekly report", Modifier.padding(top = 12.dp))
                    val mins = d.days.map { (it.second / 60_000).toInt() }
                    val maxM = maxOf(mins.maxOrNull() ?: 1, s.screenGoalMin, 1)
                    Row(Modifier.fillMaxWidth().height(130.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Bottom) {
                        d.days.forEachIndexed { i, (date, _) ->
                            Column(Modifier.weight(1f).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                                Box(Modifier.fillMaxWidth(0.6f).fillMaxHeight((mins[i] / maxM.toFloat()).coerceIn(0.02f, 0.85f)).clip(RoundedCornerShape(5.dp))
                                    .background(if (date == LocalDate.now()) c.accent else c.surface))
                                Text(date.dayOfWeek.getDisplayName(DowStyle.NARROW, Locale.getDefault()), fontSize = 12.sp, color = c.secondary, modifier = Modifier.padding(top = 4.dp))
                            }
                        }
                    }
                    val total = mins.sum()
                    Text("Total ${fmtDuration(total)} · average ${fmtDuration(total / 7)} a day", fontSize = 15.sp)
                    Text("${mins.count { it <= s.screenGoalMin }} of 7 days within your goal", fontSize = 13.sp, color = c.secondary)
                }
            }

            Label("Daily goal", Modifier.padding(top = 12.dp))
            Chips { listOf(60, 120, 180, 240, 360, 480).forEach { m -> Chip(fmtDuration(m), s.screenGoalMin == m) { vm.setScreenGoal(m) } } }
            Spacer(Modifier.height(24.dp))
        }
    }
}
