package com.margin.launcher.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.margin.launcher.LauncherViewModel
import com.margin.launcher.UiState
import com.margin.launcher.core.JournalEntry
import com.margin.launcher.ui.components.*
import com.margin.launcher.ui.theme.M
import kotlinx.coroutines.delay
import java.time.LocalDate

@Composable
fun JournalScreen(vm: LauncherViewModel, state: UiState, onBack: () -> Unit) {
    val c = M.colors
    val ctx = LocalContext.current
    val store = vm.store
    val entries by store.journal.items.collectAsState()
    var date by remember { mutableStateOf(LocalDate.now()) }
    var picker by remember { mutableStateOf(false) }
    val id = date.toEpochDay()
    val saved = entries.firstOrNull { it.id == id } ?: JournalEntry(id)

    var good by remember(date) { mutableStateOf(saved.good) }
    var done by remember(date) { mutableStateOf(saved.done) }
    var improve by remember(date) { mutableStateOf(saved.improve) }
    var tomorrow by remember(date) { mutableStateOf(saved.tomorrow) }

    fun save() {
        val cur = store.journal.get(id) ?: JournalEntry(id)
        if (good == cur.good && done == cur.done && improve == cur.improve && tomorrow == cur.tomorrow) return
        if (good.isBlank() && done.isBlank() && improve.isBlank() && tomorrow.isBlank()) store.journal.remove(id)
        else store.journal.upsert(JournalEntry(id, good, done, improve, tomorrow))
    }
    LaunchedEffect(date, good, done, improve, tomorrow) { delay(500); save() }
    DisposableEffect(date) { onDispose { save() } }

    Page("Journal", onBack) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("‹", fontSize = 28.sp, modifier = Modifier.clickable { date = date.minusDays(1) }.padding(horizontal = 14.dp, vertical = 6.dp))
            Text(date.format(DAY_FMT) + if (date == LocalDate.now()) " · today" else "", fontSize = 17.sp, fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center, modifier = Modifier.weight(1f).clickable { picker = true })
            Text("›", fontSize = 28.sp, modifier = Modifier.clickable { if (date.isBefore(LocalDate.now())) date = date.plusDays(1) }.padding(horizontal = 14.dp, vertical = 6.dp))
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 24.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Prompt("How was your day?", good, singleLine = false) { good = it }
            Prompt("What did you accomplish?", done) { done = it }
            Prompt("What needs improvement?", improve) { improve = it }
            Prompt("What are tomorrow's priorities?", tomorrow) { tomorrow = it }
            Text("Saved automatically on this device.", fontSize = 12.sp, color = c.secondary, modifier = Modifier.padding(vertical = 12.dp))
        }
    }

    if (picker) {
        GlassDateTimePicker(PickMode.DATE, "Jump to a day", date, null, false, { picker = false }) { d, _ ->
            if (d != null && !d.isAfter(LocalDate.now())) date = d
            picker = false
        }
    }
}

@Composable
private fun Prompt(question: String, value: String, singleLine: Boolean = false, onChange: (String) -> Unit) {
    Label(question, Modifier.padding(top = 10.dp))
    Field(value, onChange, "Write here…", singleLine = false, minLines = 3)
}
