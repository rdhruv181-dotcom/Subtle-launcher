package com.margin.launcher.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.margin.launcher.data.AppInfo
import com.margin.launcher.ui.theme.M

/** Long-press menu in the style of an iOS context menu: label on the left, symbol on the right. */
@Composable
fun AppMenu(
    app: AppInfo,
    inDock: Boolean,
    onDismiss: () -> Unit,
    onToggleDock: () -> Unit,
    onHide: () -> Unit,
    onInfo: () -> Unit,
    onUninstall: () -> Unit,
) {
    Dialog(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 30.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(app.label, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center,
                modifier = Modifier.glassPanel(18.dp).padding(horizontal = 20.dp, vertical = 8.dp))
            Spacer(Modifier.height(12.dp))
            Column(Modifier.fillMaxWidth().glassPanel(20.dp)) {
                MenuRow(if (inDock) "Remove from Favourites" else "Add to Favourites", GIcon.STAR) { onToggleDock(); onDismiss() }
                GlassDivider()
                MenuRow("Hide App", GIcon.EYE_OFF) { onHide(); onDismiss() }
                GlassDivider()
                MenuRow("App Info", GIcon.INFO) { onInfo(); onDismiss() }
                GlassDivider()
                MenuRow("Delete App", GIcon.TRASH, danger = true) { onUninstall(); onDismiss() }
            }
        }
    }
}

@Composable
private fun MenuRow(label: String, icon: GIcon, danger: Boolean = false, onClick: () -> Unit) {
    val col = if (danger) M.colors.alert else M.colors.text
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, fontSize = 17.sp, color = col, modifier = Modifier.weight(1f))
        LineIcon(icon, tint = col, size = 22.dp)
    }
}
