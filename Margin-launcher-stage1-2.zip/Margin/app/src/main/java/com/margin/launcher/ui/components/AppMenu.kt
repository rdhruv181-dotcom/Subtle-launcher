package com.margin.launcher.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.margin.launcher.data.AppInfo
import com.margin.launcher.ui.theme.M

@Composable
fun AppMenu(
    app: AppInfo,
    inDock: Boolean,
    onDismiss: () -> Unit,
    onToggleDock: () -> Unit,
    onHide: () -> Unit,
    onInfo: () -> Unit,
    onUninstall: () -> Unit,
) {
    Dialog(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().glassPanel(26.dp).padding(vertical = 10.dp)) {
            Text(app.label, fontSize = 18.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(horizontal = 22.dp, vertical = 12.dp))
            GlassDivider()
            MenuRow(if (inDock) "Remove from favourites" else "Add to favourites") { onToggleDock(); onDismiss() }
            MenuRow("Hide") { onHide(); onDismiss() }
            MenuRow("App info") { onInfo(); onDismiss() }
            MenuRow("Uninstall", danger = true) { onUninstall(); onDismiss() }
        }
    }
}

@Composable
private fun MenuRow(label: String, danger: Boolean = false, onClick: () -> Unit) {
    Text(label, fontSize = 16.sp, color = if (danger) M.colors.alert else M.colors.text,
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 22.dp, vertical = 15.dp))
}
