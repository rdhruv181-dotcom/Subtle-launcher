package com.margin.launcher.ui.drawer

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.margin.launcher.UiState
import com.margin.launcher.data.AppInfo
import com.margin.launcher.data.AppRepository
import com.margin.launcher.data.DrawerStyle
import com.margin.launcher.ui.components.AppIcon
import com.margin.launcher.ui.theme.M

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun DrawerScreen(
    state: UiState,
    repo: AppRepository,
    query: String,
    onQuery: (String) -> Unit,
    onClose: () -> Unit,
    onLaunch: (AppInfo) -> Unit,
    onMenu: (AppInfo) -> Unit,
) {
    val c = M.colors
    val s = state.settings
    val haptic = LocalHapticFeedback.current
    val q = query.trim()

    val results = remember(q, state.visibleApps) {
        if (q.isEmpty()) emptyList()
        else state.visibleApps
            .filter { it.label.contains(q, ignoreCase = true) }
            .sortedWith(compareBy({ !it.label.startsWith(q, ignoreCase = true) }, { it.label.lowercase() }))
    }
    val sections = remember(state.visibleApps) {
        state.visibleApps
            .groupBy { a -> a.label.firstOrNull()?.takeIf { it.isLetter() }?.uppercaseChar() ?: '#' }
            .toSortedMap(compareBy<Char> { it == '#' }.thenBy { it })
    }
    val columns = if (s.drawerStyle == DrawerStyle.GRID) 4 else 1
    var drag by remember { mutableFloatStateOf(0f) }

    Column(
        Modifier.fillMaxSize().background(c.bg)
            .pointerInput(Unit) { detectVerticalDragGestures { _, _ -> } } // swallow touches meant for the layer below
            .systemBarsPadding().imePadding()
    ) {
        // Drag handle: pull down to close.
        Box(
            Modifier.fillMaxWidth().height(28.dp).pointerInput(Unit) {
                val threshold = 56.dp.toPx()
                detectVerticalDragGestures(
                    onDragStart = { drag = 0f },
                    onDragEnd = { if (drag > threshold) onClose(); drag = 0f },
                ) { _, dy -> drag += dy }
            },
            contentAlignment = Alignment.Center,
        ) {
            Box(Modifier.width(36.dp).height(4.dp).clip(RoundedCornerShape(2.dp)).background(c.hairline))
        }

        // Search
        BasicTextField(
            value = query,
            onValueChange = onQuery,
            singleLine = true,
            textStyle = TextStyle(fontSize = 18.sp, color = c.text),
            cursorBrush = SolidColor(c.accent),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { results.firstOrNull()?.let(onLaunch) }),
            modifier = Modifier.padding(horizontal = 20.dp).fillMaxWidth(),
            decorationBox = { inner ->
                Box(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(c.surface)
                        .padding(horizontal = 16.dp, vertical = 14.dp)
                ) {
                    if (query.isEmpty()) Text("Search apps", fontSize = 18.sp, color = c.secondary)
                    inner()
                }
            },
        )

        LazyVerticalGrid(
            columns = GridCells.Fixed(columns),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = 24.dp),
            modifier = Modifier.weight(1f),
        ) {
            if (q.isNotEmpty()) {
                if (results.isEmpty()) {
                    item(key = "empty", span = { GridItemSpan(maxLineSpan) }) {
                        Text("No apps match “$q”", color = c.secondary, modifier = Modifier.padding(top = 28.dp))
                    }
                }
                items(results, key = { it.key }) { app -> Cell(app, s.drawerStyle, repo, s.monoIcons, onLaunch, onMenu, haptic) }
            } else {
                if (state.recents.isNotEmpty()) {
                    item(key = "h_recent", span = { GridItemSpan(maxLineSpan) }) { SectionLabel("Recent") }
                    items(state.recents, key = { "r_" + it.key }) { app -> Cell(app, s.drawerStyle, repo, s.monoIcons, onLaunch, onMenu, haptic) }
                }
                for ((letter, apps) in sections) {
                    item(key = "h_$letter", span = { GridItemSpan(maxLineSpan) }) { SectionLabel(letter.toString()) }
                    items(apps, key = { it.key }) { app -> Cell(app, s.drawerStyle, repo, s.monoIcons, onLaunch, onMenu, haptic) }
                }
            }
        }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text, fontSize = 13.sp, fontWeight = FontWeight.Medium, letterSpacing = 1.sp,
        color = M.colors.secondary, modifier = Modifier.padding(top = 20.dp, bottom = 6.dp),
    )
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun Cell(
    app: AppInfo,
    style: DrawerStyle,
    repo: AppRepository,
    mono: Boolean,
    onLaunch: (AppInfo) -> Unit,
    onMenu: (AppInfo) -> Unit,
    haptic: androidx.compose.ui.hapticfeedback.HapticFeedback,
) {
    val click = Modifier.clip(RoundedCornerShape(12.dp)).combinedClickable(
        onClick = { onLaunch(app) },
        onLongClick = { haptic.performHapticFeedback(HapticFeedbackType.LongPress); onMenu(app) },
    )
    when (style) {
        DrawerStyle.GRID -> Column(
            click.fillMaxWidth().padding(vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            AppIcon(app, repo, 52.dp, mono)
            Spacer(Modifier.height(6.dp))
            Text(app.label, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center, color = M.colors.secondary)
        }
        DrawerStyle.TEXT -> Text(
            app.label, fontSize = 26.sp, fontWeight = FontWeight.Light, maxLines = 1,
            overflow = TextOverflow.Ellipsis, modifier = click.fillMaxWidth().padding(vertical = 10.dp, horizontal = 4.dp),
        )
        DrawerStyle.COMPACT -> Row(
            click.fillMaxWidth().padding(vertical = 8.dp, horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            AppIcon(app, repo, 30.dp, mono)
            Spacer(Modifier.width(16.dp))
            Text(app.label, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}
