package com.margin.launcher.ui.drawer

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.margin.launcher.UiState
import com.margin.launcher.data.AppInfo
import com.margin.launcher.data.AppRepository
import com.margin.launcher.data.DrawerStyle
import com.margin.launcher.ui.components.*
import com.margin.launcher.ui.theme.M
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.exp

private sealed class FlowEntry {
    class Header(val letter: Char) : FlowEntry()
    class App(val app: AppInfo) : FlowEntry()
}

/**
 * The complete alphabetical app list. The default "Flow" style is inspired by Niagara: big type, the row
 * in the middle of the screen is the largest, and an A–Z rail on the right bulges towards your finger.
 */
@Composable
fun DrawerScreen(
    state: UiState,
    repo: AppRepository,
    query: String,
    onQuery: (String) -> Unit,
    onClose: () -> Unit,
    onLaunch: (AppInfo) -> Unit,
    onMenu: (AppInfo) -> Unit,
) {
    val c = M.colors
    val s = state.settings
    val q = query.trim()

    val results = remember(q, state.visibleApps) {
        if (q.isEmpty()) emptyList()
        else state.visibleApps
            .filter { it.label.contains(q, ignoreCase = true) }
            .sortedWith(compareBy({ !it.label.startsWith(q, ignoreCase = true) }, { it.label.lowercase() }))
    }
    val sections = remember(state.visibleApps) {
        state.visibleApps
            .groupBy { a -> a.label.firstOrNull()?.takeIf { it.isLetter() }?.uppercaseChar() ?: '#' }
            .toSortedMap(compareBy<Char> { it == '#' }.thenBy { it })
    }
    val flow = s.drawerStyle == DrawerStyle.FLOW

    // Item index of each section header, for the A–Z rail (grid styles).
    val gridLetters = remember(sections) {
        var idx = 0
        sections.map { (ch, apps) -> val p = ch to idx; idx += 1 + apps.size; p }
    }
    val flowEntries = remember(sections, results, q) {
        if (q.isNotEmpty()) results.map { FlowEntry.App(it) as FlowEntry }
        else buildList<FlowEntry> {
            sections.forEach { (ch, apps) ->
                add(FlowEntry.Header(ch))
                apps.forEach { add(FlowEntry.App(it)) }
            }
        }
    }
    val flowLetters = remember(flowEntries) {
        flowEntries.mapIndexedNotNull { i, e -> if (e is FlowEntry.Header) e.letter to i else null }
    }

    val columns = if (s.drawerStyle == DrawerStyle.GRID) 4 else 1
    val gridState = rememberLazyGridState()
    val listState = rememberLazyListState()
    var bubble by remember { mutableStateOf<Char?>(null) }
    var drag by remember { mutableFloatStateOf(0f) }

    Column(
        Modifier.fillMaxSize().glassBackground()
            .pointerInput(Unit) { detectTapGestures { } }
            .systemBarsPadding().imePadding()
    ) {
        // Drag handle: pull down to close.
        Box(
            Modifier.fillMaxWidth().height(28.dp).pointerInput(Unit) {
                val threshold = 56.dp.toPx()
                detectVerticalDragGestures(
                    onDragStart = { drag = 0f },
                    onDragEnd = { if (drag > threshold) onClose(); drag = 0f },
                ) { _, dy -> drag += dy }
            },
            contentAlignment = Alignment.Center,
        ) { Box(Modifier.width(40.dp).height(4.dp).clip(RoundedCornerShape(2.dp)).background(c.text.copy(alpha = 0.25f))) }

        GlassSearchBar(
            value = query, onChange = onQuery, hint = "Search apps",
            modifier = Modifier.padding(horizontal = 20.dp),
            onSearch = { results.firstOrNull()?.let(onLaunch) },
        )

        Box(Modifier.weight(1f)) {
            if (flow) {
                FlowList(flowEntries, listState, repo, s.monoIcons, onLaunch, onMenu, Modifier.fillMaxSize())
                if (q.isEmpty() && state.visibleApps.size > 8) {
                    FastScroller(
                        firstVisible = { listState.firstVisibleItemIndex },
                        total = { listState.layoutInfo.totalItemsCount },
                        visibleCount = { listState.layoutInfo.visibleItemsInfo.size },
                        isScrolling = { listState.isScrollInProgress },
                        letters = flowLetters, showIndex = s.drawerIndex, wave = true,
                        scrollTo = { listState.scrollToItem(it) }, onBubble = { bubble = it },
                        modifier = Modifier.align(Alignment.CenterEnd),
                    )
                }
            } else {
                LazyVerticalGrid(
                    state = gridState,
                    columns = GridCells.Fixed(columns),
                    contentPadding = PaddingValues(start = 20.dp, end = if (q.isEmpty()) 44.dp else 20.dp, top = 8.dp, bottom = 24.dp),
                    modifier = Modifier.fillMaxSize(),
                ) {
                    if (q.isNotEmpty()) {
                        if (results.isEmpty()) {
                            item(key = "empty", span = { GridItemSpan(maxLineSpan) }) {
                                Text("No apps match “$q”", color = c.secondary, modifier = Modifier.padding(top = 28.dp))
                            }
                        }
                        items(results, key = { it.key }) { app -> Cell(app, s.drawerStyle, repo, s.monoIcons, s.iconDp, onLaunch, onMenu) }
                    } else {
                        for ((letter, apps) in sections) {
                            item(key = "h_$letter", span = { GridItemSpan(maxLineSpan) }) { SectionLabel(letter.toString()) }
                            items(apps, key = { it.key }) { app -> Cell(app, s.drawerStyle, repo, s.monoIcons, s.iconDp, onLaunch, onMenu) }
                        }
                    }
                }
                if (q.isEmpty() && state.visibleApps.size > 8) {
                    FastScroller(
                        firstVisible = { gridState.firstVisibleItemIndex },
                        total = { gridState.layoutInfo.totalItemsCount },
                        visibleCount = { gridState.layoutInfo.visibleItemsInfo.size },
                        isScrolling = { gridState.isScrollInProgress },
                        letters = gridLetters, showIndex = s.drawerIndex, wave = false,
                        scrollTo = { gridState.scrollToItem(it) }, onBubble = { bubble = it },
                        modifier = Modifier.align(Alignment.CenterEnd),
                    )
                }
            }
            bubble?.let { ch ->
                Box(Modifier.align(Alignment.Center).size(88.dp).glassPanel(44.dp), contentAlignment = Alignment.Center) {
                    Text(ch.toString(), fontSize = 42.sp, fontWeight = FontWeight.Light)
                }
            }
        }
    }
}

/**
 * Niagara-style list: names in large type; the row nearest the middle of the screen is full size and the
 * rows toward the edges shrink and fade, so the list feels like it flows past a focal point.
 */
@Composable
private fun FlowList(
    entries: List<FlowEntry>,
    state: LazyListState,
    repo: AppRepository,
    mono: Boolean,
    onLaunch: (AppInfo) -> Unit,
    onMenu: (AppInfo) -> Unit,
    modifier: Modifier,
) {
    val c = M.colors
    LazyColumn(
        state = state, modifier = modifier,
        contentPadding = PaddingValues(start = 28.dp, end = 64.dp, top = 140.dp, bottom = 260.dp),
    ) {
        items(entries.size, key = { i -> when (val e = entries[i]) { is FlowEntry.Header -> "h_" + e.letter; is FlowEntry.App -> e.app.key } }) { i ->
            val entry = entries[i]
            val key = when (entry) { is FlowEntry.Header -> "h_" + entry.letter; is FlowEntry.App -> entry.app.key }
            Box(
                Modifier.fillMaxWidth().graphicsLayer {
                    val info = state.layoutInfo
                    val item = info.visibleItemsInfo.firstOrNull { it.key == key }
                    if (item != null) {
                        val half = info.viewportSize.height / 2f
                        val dist = if (half > 0f) abs(item.offset + item.size / 2f - half) / half else 0f
                        val f = (1f - dist).coerceIn(0f, 1f)
                        val sc = 0.78f + 0.22f * f
                        scaleX = sc
                        scaleY = sc
                        alpha = 0.30f + 0.70f * f
                        transformOrigin = TransformOrigin(0f, 0.5f)
                    }
                }
            ) {
                when (entry) {
                    is FlowEntry.Header -> Row(Modifier.fillMaxWidth().padding(top = 22.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(entry.letter.toString(), fontSize = 40.sp, fontWeight = FontWeight.Bold, color = c.accent)
                        Spacer(Modifier.width(16.dp))
                        Box(Modifier.weight(1f).height(1.dp).background(c.text.copy(alpha = 0.14f)))
                    }
                    is FlowEntry.App -> Row(
                        Modifier.fillMaxWidth().tactile(onClick = { onLaunch(entry.app) }, onLongClick = { onMenu(entry.app) }, haptic = false)
                            .padding(vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        AppIcon(entry.app, repo, 34.dp, mono)
                        Spacer(Modifier.width(18.dp))
                        Text(entry.app.label, fontSize = 28.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
    }
}

/**
 * Always-visible scrollbar thumb plus an A–Z rail. Drag or tap anywhere on it to jump. With wave = true the
 * letters bulge toward the finger like Niagara's alphabet strip.
 */
@Composable
private fun FastScroller(
    firstVisible: () -> Int,
    total: () -> Int,
    visibleCount: () -> Int,
    isScrolling: () -> Boolean,
    letters: List<Pair<Char, Int>>,
    showIndex: Boolean,
    wave: Boolean,
    scrollTo: suspend (Int) -> Unit,
    onBubble: (Char?) -> Unit,
    modifier: Modifier = Modifier,
) {
    val c = M.colors
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current
    val haptic = LocalHapticFeedback.current
    var trackH by remember { mutableIntStateOf(0) }
    var dragging by remember { mutableStateOf(false) }
    var fingerY by remember { mutableFloatStateOf(-1f) }
    var lastLetter by remember { mutableStateOf<Char?>(null) }

    val n = total()
    val vis = visibleCount()
    val first = firstVisible()
    val frac = if (n > vis) (first.toFloat() / (n - vis)).coerceIn(0f, 1f) else 0f
    val thumbMin = with(density) { 40.dp.toPx() }
    val thumbPx = if (n > 0) (trackH * vis / n.toFloat()).coerceIn(thumbMin, maxOf(trackH.toFloat(), thumbMin)) else thumbMin
    val alpha by animateFloatAsState(if (dragging || isScrolling()) 0.8f else 0.35f, label = "thumbAlpha")

    fun seek(y: Float) {
        if (trackH <= 0 || n <= 0) return
        fingerY = y
        val f = (y / trackH).coerceIn(0f, 1f)
        if (showIndex && letters.isNotEmpty()) {
            val l = letters[(f * letters.size).toInt().coerceIn(0, letters.lastIndex)]
            onBubble(l.first)
            if (l.first != lastLetter) {
                lastLetter = l.first
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            }
            scope.launch { scrollTo(l.second) }
        } else {
            val idx = (f * (n - 1)).toInt().coerceIn(0, n - 1)
            onBubble(letters.lastOrNull { it.second <= idx }?.first)
            scope.launch { scrollTo(idx) }
        }
    }

    fun release() { dragging = false; fingerY = -1f; lastLetter = null; onBubble(null) }

    Box(
        modifier.fillMaxHeight().width(44.dp).onSizeChanged { trackH = it.height }
            .pointerInput(letters, showIndex, n) { detectTapGestures(onTap = { seek(it.y); release() }) }
            .pointerInput(letters, showIndex, n) {
                detectVerticalDragGestures(
                    onDragStart = { dragging = true; seek(it.y) },
                    onDragEnd = { release() },
                    onDragCancel = { release() },
                ) { change, _ -> seek(change.position.y) }
            }
    ) {
        if (showIndex) {
            Column(Modifier.align(Alignment.CenterEnd).fillMaxHeight().padding(end = 12.dp)) {
                letters.forEachIndexed { i, (ch, _) ->
                    Box(
                        Modifier.weight(1f).graphicsLayer {
                            if (wave && fingerY >= 0f && trackH > 0) {
                                val cy = (i + 0.5f) * trackH / letters.size
                                val d = (cy - fingerY) / (trackH / 7f)
                                val k = exp(-d * d)
                                translationX = -46.dp.toPx() * k
                                val sc = 1f + 0.9f * k
                                scaleX = sc
                                scaleY = sc
                            }
                        },
                        contentAlignment = Alignment.Center,
                    ) { Text(ch.toString(), fontSize = 11.sp, fontWeight = FontWeight.Medium, color = c.secondary) }
                }
            }
        }
        Box(
            Modifier.align(Alignment.TopEnd)
                .offset { IntOffset(0, (frac * (trackH - thumbPx)).toInt().coerceAtLeast(0)) }
                .padding(end = 2.dp).width(4.dp).height(with(density) { thumbPx.toDp() })
                .clip(CircleShape).background(c.text.copy(alpha = alpha))
        )
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 1.5.sp,
        color = M.colors.accent, modifier = Modifier.padding(top = 20.dp, bottom = 6.dp, start = 4.dp),
    )
}

@Composable
private fun Cell(
    app: AppInfo,
    style: DrawerStyle,
    repo: AppRepository,
    mono: Boolean,
    iconDp: Int,
    onLaunch: (AppInfo) -> Unit,
    onMenu: (AppInfo) -> Unit,
) {
    val click = Modifier.tactile(onClick = { onLaunch(app) }, onLongClick = { onMenu(app) }, haptic = false)
    when (style) {
        DrawerStyle.GRID -> Column(
            click.fillMaxWidth().padding(vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            AppIcon(app, repo, iconDp.dp, mono)
            Spacer(Modifier.height(6.dp))
            Text(app.label, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center, color = M.colors.secondary)
        }
        DrawerStyle.TEXT -> Text(
            app.label, fontSize = 26.sp, fontWeight = FontWeight.Light, maxLines = 1,
            overflow = TextOverflow.Ellipsis, modifier = click.fillMaxWidth().padding(vertical = 10.dp, horizontal = 4.dp),
        )
        else -> Column(click.fillMaxWidth()) {
            Row(Modifier.padding(vertical = 8.dp, horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                AppIcon(app, repo, 46.dp, mono)
                Spacer(Modifier.width(16.dp))
                Text(app.label, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            RowDivider(66.dp)
        }
    }
}
