package com.margin.launcher.ui.drawer

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.margin.launcher.UiState
import com.margin.launcher.data.AppInfo
import com.margin.launcher.data.AppRepository
import com.margin.launcher.data.DrawerStyle
import com.margin.launcher.ui.components.*
import com.margin.launcher.ui.theme.M
import kotlinx.coroutines.launch

/** The complete alphabetical app list: glass search bar, section headers, scrollbar and A–Z index. */
@Composable
fun DrawerScreen(
    state: UiState,
    repo: AppRepository,
    query: String,
    onQuery: (String) -> Unit,
    onClose: () -> Unit,
    onLaunch: (AppInfo) -> Unit,
    onMenu: (AppInfo) -> Unit,
) {
    val c = M.colors
    val s = state.settings
    val q = query.trim()

    val results = remember(q, state.visibleApps) {
        if (q.isEmpty()) emptyList()
        else state.visibleApps
            .filter { it.label.contains(q, ignoreCase = true) }
            .sortedWith(compareBy({ !it.label.startsWith(q, ignoreCase = true) }, { it.label.lowercase() }))
    }
    val sections = remember(state.visibleApps) {
        state.visibleApps
            .groupBy { a -> a.label.firstOrNull()?.takeIf { it.isLetter() }?.uppercaseChar() ?: '#' }
            .toSortedMap(compareBy<Char> { it == '#' }.thenBy { it })
    }
    // Item index of each section header, for the A–Z index.
    val letters = remember(sections) {
        var idx = 0
        sections.map { (ch, apps) -> val p = ch to idx; idx += 1 + apps.size; p }
    }
    val columns = if (s.drawerStyle == DrawerStyle.GRID) 4 else 1
    val gridState = rememberLazyGridState()
    var bubble by remember { mutableStateOf<Char?>(null) }
    var drag by remember { mutableFloatStateOf(0f) }

    Column(
        Modifier.fillMaxSize().glassBackground()
            .pointerInput(Unit) { detectTapGestures { } }
            .systemBarsPadding().imePadding()
    ) {
        // Drag handle: pull down to close.
        Box(
            Modifier.fillMaxWidth().height(28.dp).pointerInput(Unit) {
                val threshold = 56.dp.toPx()
                detectVerticalDragGestures(
                    onDragStart = { drag = 0f },
                    onDragEnd = { if (drag > threshold) onClose(); drag = 0f },
                ) { _, dy -> drag += dy }
            },
            contentAlignment = Alignment.Center,
        ) { Box(Modifier.width(40.dp).height(4.dp).clip(RoundedCornerShape(2.dp)).background(c.text.copy(alpha = 0.25f))) }

        GlassSearchBar(
            value = query, onChange = onQuery, hint = "App Library",
            modifier = Modifier.padding(horizontal = 20.dp),
            onSearch = { results.firstOrNull()?.let(onLaunch) },
        )

        Box(Modifier.weight(1f)) {
            LazyVerticalGrid(
                state = gridState,
                columns = GridCells.Fixed(columns),
                contentPadding = PaddingValues(start = 20.dp, end = if (q.isEmpty()) 44.dp else 20.dp, top = 8.dp, bottom = 24.dp),
                modifier = Modifier.fillMaxSize(),
            ) {
                if (q.isNotEmpty()) {
                    if (results.isEmpty()) {
                        item(key = "empty", span = { GridItemSpan(maxLineSpan) }) {
                            Text("No apps match “$q”", color = c.secondary, modifier = Modifier.padding(top = 28.dp))
                        }
                    }
                    items(results, key = { it.key }) { app -> Cell(app, s.drawerStyle, repo, s.monoIcons, s.iconDp, onLaunch, onMenu) }
                } else {
                    for ((letter, apps) in sections) {
                        item(key = "h_$letter", span = { GridItemSpan(maxLineSpan) }) { SectionLabel(letter.toString()) }
                        items(apps, key = { it.key }) { app -> Cell(app, s.drawerStyle, repo, s.monoIcons, s.iconDp, onLaunch, onMenu) }
                    }
                }
            }

            if (q.isEmpty() && state.visibleApps.size > 8) {
                FastScroller(gridState, letters, s.drawerIndex, { bubble = it }, Modifier.align(Alignment.CenterEnd))
            }
            bubble?.let { ch ->
                Box(Modifier.align(Alignment.Center).size(88.dp).glassPanel(44.dp), contentAlignment = Alignment.Center) {
                    Text(ch.toString(), fontSize = 42.sp, fontWeight = FontWeight.Light)
                }
            }
        }
    }
}

/** Always-visible scrollbar thumb plus an optional A–Z rail. Drag or tap anywhere on it to jump. */
@Composable
private fun FastScroller(
    state: LazyGridState,
    letters: List<Pair<Char, Int>>,
    showIndex: Boolean,
    onBubble: (Char?) -> Unit,
    modifier: Modifier = Modifier,
) {
    val c = M.colors
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current
    var trackH by remember { mutableIntStateOf(0) }
    var dragging by remember { mutableStateOf(false) }

    val total = state.layoutInfo.totalItemsCount
    val visible = state.layoutInfo.visibleItemsInfo.size
    val first = state.firstVisibleItemIndex
    val frac = if (total > visible) (first.toFloat() / (total - visible)).coerceIn(0f, 1f) else 0f
    val thumbMin = with(density) { 40.dp.toPx() }
    val thumbPx = if (total > 0) (trackH * visible / total.toFloat()).coerceIn(thumbMin, maxOf(trackH.toFloat(), thumbMin)) else thumbMin
    val alpha by animateFloatAsState(if (dragging || state.isScrollInProgress) 0.8f else 0.35f, label = "thumbAlpha")

    fun seek(y: Float) {
        if (trackH <= 0 || total <= 0) return
        val f = (y / trackH).coerceIn(0f, 1f)
        if (showIndex && letters.isNotEmpty()) {
            val l = letters[(f * letters.size).toInt().coerceIn(0, letters.lastIndex)]
            onBubble(l.first)
            scope.launch { state.scrollToItem(l.second) }
        } else {
            val idx = (f * (total - 1)).toInt().coerceIn(0, total - 1)
            onBubble(letters.lastOrNull { it.second <= idx }?.first)
            scope.launch { state.scrollToItem(idx) }
        }
    }

    Box(
        modifier.fillMaxHeight().width(36.dp).onSizeChanged { trackH = it.height }
            .pointerInput(letters, showIndex, total) { detectTapGestures(onTap = { seek(it.y) }) }
            .pointerInput(letters, showIndex, total) {
                detectVerticalDragGestures(
                    onDragStart = { dragging = true; seek(it.y) },
                    onDragEnd = { dragging = false; onBubble(null) },
                    onDragCancel = { dragging = false; onBubble(null) },
                ) { change, _ -> seek(change.position.y) }
            }
    ) {
        if (showIndex) {
            Column(
                Modifier.align(Alignment.CenterEnd).fillMaxHeight().padding(end = 10.dp, top = 4.dp, bottom = 4.dp),
                verticalArrangement = Arrangement.SpaceEvenly,
            ) {
                letters.forEach { (ch, _) -> Text(ch.toString(), fontSize = 10.sp, fontWeight = FontWeight.Medium, color = c.secondary) }
            }
        }
        Box(
            Modifier.align(Alignment.TopEnd)
                .offset { IntOffset(0, (frac * (trackH - thumbPx)).toInt().coerceAtLeast(0)) }
                .padding(end = 2.dp).width(4.dp).height(with(density) { thumbPx.toDp() })
                .clip(CircleShape).background(c.text.copy(alpha = alpha))
        )
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 1.5.sp,
        color = M.colors.accent, modifier = Modifier.padding(top = 20.dp, bottom = 6.dp, start = 4.dp),
    )
}

@Composable
private fun Cell(
    app: AppInfo,
    style: DrawerStyle,
    repo: AppRepository,
    mono: Boolean,
    iconDp: Int,
    onLaunch: (AppInfo) -> Unit,
    onMenu: (AppInfo) -> Unit,
) {
    val click = Modifier.tactile(onClick = { onLaunch(app) }, onLongClick = { onMenu(app) }, haptic = false)
    when (style) {
        DrawerStyle.GRID -> Column(
            click.fillMaxWidth().padding(vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            AppIcon(app, repo, iconDp.dp, mono)
            Spacer(Modifier.height(6.dp))
            Text(app.label, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center, color = M.colors.secondary)
        }
        DrawerStyle.TEXT -> Text(
            app.label, fontSize = 26.sp, fontWeight = FontWeight.Light, maxLines = 1,
            overflow = TextOverflow.Ellipsis, modifier = click.fillMaxWidth().padding(vertical = 10.dp, horizontal = 4.dp),
        )
        DrawerStyle.COMPACT -> Column(click.fillMaxWidth()) {
            Row(Modifier.padding(vertical = 8.dp, horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                AppIcon(app, repo, 46.dp, mono)
                Spacer(Modifier.width(16.dp))
                Text(app.label, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            RowDivider(66.dp)
        }
    }
}
