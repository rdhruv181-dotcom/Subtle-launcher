package com.margin.launcher.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.margin.launcher.core.fmtClock
import com.margin.launcher.ui.theme.M
import kotlin.math.roundToInt
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.TextStyle as DowStyle
import java.time.temporal.TemporalAdjusters
import java.util.Locale

// ---------------------------------------------------------------------------------------------
// Surfaces
// ---------------------------------------------------------------------------------------------

/** The user's wallpaper (if any) and how strongly to dim it. */
data class WallpaperState(val image: ImageBitmap?, val dim: Int)

val LocalWallpaper = compositionLocalOf { WallpaperState(null, 1) }

/**
 * Background for every screen: the user's wallpaper dimmed for readability, or otherwise an ambient
 * purple-and-black gradient. Gradients are cheap to draw, so this works on every device. Real backdrop blur
 * is not used because Compose can't blur what is behind a view; glass cards are translucent layers instead.
 */
@Composable
fun Modifier.glassBackground(): Modifier {
    val c = M.colors
    val wp = LocalWallpaper.current
    return this.drawBehind {
        val img = wp.image
        if (img != null) {
            val scale = maxOf(size.width / img.width, size.height / img.height)
            val dw = (img.width * scale).roundToInt()
            val dh = (img.height * scale).roundToInt()
            drawImage(
                img,
                dstOffset = IntOffset(((size.width - dw) / 2f).roundToInt(), ((size.height - dh) / 2f).roundToInt()),
                dstSize = IntSize(dw, dh),
                filterQuality = FilterQuality.High,
            )
            val tint = if (c.dark) Color.Black else Color.White
            val a = when (wp.dim) { 0 -> 0.18f; 2 -> 0.55f; else -> 0.36f }
            drawRect(tint.copy(alpha = a))
            drawRect(Brush.verticalGradient(listOf(Color.Transparent, tint.copy(alpha = 0.30f))))
        } else {
            drawRect(Brush.verticalGradient(listOf(c.bgTop, c.bgMid, c.bgBottom)))
            drawRect(Brush.radialGradient(listOf(c.glowA.copy(alpha = 0.34f), Color.Transparent),
                center = Offset(size.width * 0.12f, size.height * 0.10f), radius = size.maxDimension * 0.75f))
            drawRect(Brush.radialGradient(listOf(c.glowB.copy(alpha = 0.40f), Color.Transparent),
                center = Offset(size.width * 0.95f, size.height * 0.34f), radius = size.maxDimension * 0.60f))
            drawRect(Brush.radialGradient(listOf(c.glowC.copy(alpha = 0.22f), Color.Transparent),
                center = Offset(size.width * 0.50f, size.height * 1.02f), radius = size.maxDimension * 0.65f))
        }
    }
}

/** A frosted surface: translucent fill, soft top highlight and a thin light border. */
@Composable
fun Modifier.glass(radius: Dp = 22.dp, strong: Boolean = false): Modifier {
    val c = M.colors
    val shape = RoundedCornerShape(radius)
    return this.clip(shape)
        .background(if (strong) c.surfaceStrong else c.surface)
        .background(Brush.verticalGradient(listOf(c.highlight, Color.Transparent)))
        .border(1.dp, Brush.verticalGradient(listOf(c.borderTop, c.borderBottom)), shape)
}

/** Nearly opaque glass for sheets and dialogs that sit over other content, so text stays readable. */
@Composable
fun Modifier.glassPanel(radius: Dp = 28.dp): Modifier {
    val c = M.colors
    val shape = RoundedCornerShape(radius)
    return this.clip(shape)
        .background(c.bg.copy(alpha = 0.95f))
        .background(c.surface)
        .background(Brush.verticalGradient(listOf(c.highlight, Color.Transparent)))
        .border(1.dp, Brush.verticalGradient(listOf(c.borderTop, c.borderBottom)), shape)
}

/** Springy press feedback plus a light haptic tick. Apply before the surface modifiers so the whole surface scales. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Modifier.tactile(
    onClick: () -> Unit,
    onLongClick: (() -> Unit)? = null,
    haptic: Boolean = true,
    role: Role = Role.Button,
): Modifier {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(
        if (pressed) 0.95f else 1f, spring(dampingRatio = 0.6f, stiffness = 500f), label = "press",
    )
    val hf = LocalHapticFeedback.current
    return this.graphicsLayer { scaleX = scale; scaleY = scale }
        .combinedClickable(
            interactionSource = src, indication = null, role = role,
            onClick = { if (haptic) hf.performHapticFeedback(HapticFeedbackType.TextHandleMove); onClick() },
            onLongClick = onLongClick?.let { lc -> { hf.performHapticFeedback(HapticFeedbackType.LongPress); lc() } },
        )
}

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    radius: Dp = 28.dp,
    strong: Boolean = false,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    val m = if (onClick != null) modifier.tactile(onClick) else modifier
    Column(m.glass(radius, strong), content = content)
}

@Composable
fun GlassDivider() {
    Box(Modifier.fillMaxWidth().height(1.dp).background(M.colors.hairline))
}

// ---------------------------------------------------------------------------------------------
// Controls
// ---------------------------------------------------------------------------------------------

@Composable
fun GlassButton(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    primary: Boolean = true,
    danger: Boolean = false,
    icon: GIcon? = null,
    color: Color? = null,
) {
    val c = M.colors
    val shape = RoundedCornerShape(26.dp)
    val fg = when { primary -> if (color != null) Color.White else c.onAccent; danger -> c.alert; else -> c.text }
    val surface = if (primary) {
        Modifier.clip(shape)
            .background(Brush.verticalGradient(listOf(color ?: c.accent, (color ?: c.accent).copy(alpha = 0.78f))))
            .border(1.dp, Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.45f), Color.White.copy(alpha = 0.05f))), shape)
    } else Modifier.glass(26.dp)
    Row(
        modifier.defaultMinSize(minHeight = 50.dp).tactile(onClick).then(surface).padding(horizontal = 18.dp),
        horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) { LineIcon(icon, tint = fg, size = 20.dp); Spacer(Modifier.width(8.dp)) }
        Text(label, fontSize = 16.sp, fontWeight = FontWeight.Medium, color = fg)
    }
}

@Composable
fun GlassIconButton(
    icon: GIcon,
    description: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 44.dp,
    tint: Color = M.colors.text,
) {
    Box(
        modifier.size(size).tactile(onClick).glass(size / 2).semantics { contentDescription = description },
        contentAlignment = Alignment.Center,
    ) { LineIcon(icon, tint = tint, size = size * 0.5f) }
}

@Composable
fun GlassSwitch(checked: Boolean, onChange: (Boolean) -> Unit) {
    val c = M.colors
    val track by animateColorAsState(if (checked) com.margin.launcher.ui.theme.IOS.Green else c.text.copy(alpha = 0.16f), label = "track")
    val x by animateDpAsState(if (checked) 22.dp else 2.dp, spring(dampingRatio = 0.7f, stiffness = 500f), label = "thumb")
    Box(
        Modifier.size(51.dp, 31.dp)
            .toggleable(value = checked, role = Role.Switch, onValueChange = onChange)
            .clip(CircleShape).background(track)
    ) {
        Box(Modifier.offset(x, 2.dp).size(27.dp).shadow(3.dp, CircleShape).clip(CircleShape).background(Color.White))
    }
}

@Composable
fun GlassSearchBar(
    value: String,
    onChange: (String) -> Unit,
    hint: String,
    modifier: Modifier = Modifier,
    focusRequester: FocusRequester? = null,
    onSearch: () -> Unit = {},
) {
    val c = M.colors
    Row(
        modifier.fillMaxWidth().glass(28.dp).padding(horizontal = 18.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        LineIcon(GIcon.SEARCH, tint = c.secondary, size = 22.dp)
        Spacer(Modifier.width(12.dp))
        Box(Modifier.weight(1f)) {
            if (value.isEmpty()) Text(hint, fontSize = 17.sp, color = c.secondary)
            BasicTextField(
                value = value, onValueChange = onChange, singleLine = true,
                textStyle = TextStyle(fontSize = 17.sp, color = c.text),
                cursorBrush = SolidColor(c.accent),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { onSearch() }),
                modifier = Modifier.fillMaxWidth().then(if (focusRequester != null) Modifier.focusRequester(focusRequester) else Modifier),
            )
        }
        if (value.isNotEmpty()) {
            Box(
                Modifier.size(32.dp).clip(CircleShape).clickable(role = Role.Button) { onChange("") }
                    .semantics { contentDescription = "Clear search" },
                contentAlignment = Alignment.Center,
            ) { LineIcon(GIcon.CLOSE, tint = c.secondary, size = 16.dp) }
        }
    }
}

/** Non-editable search bar for the home screen: tapping it opens global search. */
@Composable
fun GlassSearchPill(hint: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val c = M.colors
    Row(
        modifier.fillMaxWidth().tactile(onClick, haptic = false).glass(28.dp).padding(horizontal = 18.dp, vertical = 16.dp)
            .semantics { contentDescription = "Search" },
        verticalAlignment = Alignment.CenterVertically,
    ) {
        LineIcon(GIcon.SEARCH, tint = c.secondary, size = 22.dp)
        Spacer(Modifier.width(12.dp))
        Text(hint, fontSize = 17.sp, color = c.secondary)
    }
}

@Composable
fun GlassNavBar(title: String, onBack: () -> Unit, action: (@Composable () -> Unit)? = null) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp).glass(28.dp).padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        GlassIconButton(GIcon.BACK, "Back", onBack, size = 40.dp)
        Text(
            title, fontSize = 20.sp, fontWeight = FontWeight.SemiBold,
            modifier = Modifier.weight(1f).padding(horizontal = 12.dp).semantics { heading() },
        )
        action?.invoke()
    }
}

/** A titled group of settings rows on one glass panel. */
@Composable
fun GlassSettingsSection(title: String, icon: GIcon, content: @Composable ColumnScope.() -> Unit) {
    val c = M.colors
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(start = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            LineIcon(icon, tint = c.accent, size = 18.dp)
            Spacer(Modifier.width(8.dp))
            Text(title.uppercase(), fontSize = 12.sp, fontWeight = FontWeight.Medium, letterSpacing = 1.5.sp, color = c.secondary,
                modifier = Modifier.semantics { heading() })
        }
        Column(Modifier.fillMaxWidth().glass(26.dp).padding(horizontal = 16.dp, vertical = 8.dp), content = content)
    }
}

/** Slides up over a dimmed screen. Place it in a full-screen Box. */
@Composable
fun GlassBottomSheet(visible: Boolean, onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Box(Modifier.fillMaxSize()) {
        AnimatedVisibility(visible, enter = fadeIn(), exit = fadeOut()) {
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.5f)).pointerInput(Unit) { detectTapGestures { onDismiss() } })
        }
        AnimatedVisibility(
            visible,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = slideInVertically(spring(dampingRatio = 0.85f, stiffness = 380f)) { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut(),
        ) {
            Column(
                Modifier.fillMaxWidth().padding(10.dp).navigationBarsPadding().imePadding()
                    .glassPanel(38.dp).pointerInput(Unit) { detectTapGestures { } }
                    .verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                // iOS-style grabber
                Box(Modifier.align(Alignment.CenterHorizontally).width(38.dp).height(5.dp).clip(CircleShape).background(M.colors.text.copy(alpha = 0.28f)))
                content()
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Date & time picker
// ---------------------------------------------------------------------------------------------

enum class PickMode { DATE, DATE_TIME, TIME }

/**
 * One calendar for tasks, reminders, events and the journal. Any date can be chosen; shortcuts are
 * just a faster way to get to common ones. Time is optional in DATE_TIME mode.
 * onResult gets (null, null) when the user taps Clear.
 */
@Composable
fun GlassDateTimePicker(
    mode: PickMode,
    title: String,
    initialDate: LocalDate?,
    initialMinute: Int?,
    allowClear: Boolean,
    onDismiss: () -> Unit,
    onResult: (LocalDate?, Int?) -> Unit,
) {
    val c = M.colors
    val today = LocalDate.now()
    var date by remember { mutableStateOf(initialDate) }
    var ym by remember { mutableStateOf(YearMonth.from(initialDate ?: today)) }
    var timeOn by remember { mutableStateOf(mode == PickMode.TIME || initialMinute != null) }
    var minute by remember { mutableIntStateOf(initialMinute ?: (9 * 60)) }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier.fillMaxWidth().padding(16.dp).glassPanel(30.dp).verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(title, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.semantics { heading() })

            if (mode != PickMode.TIME) {
                Chips {
                    val pick = { d: LocalDate -> date = d; ym = YearMonth.from(d) }
                    Chip("Today", date == today) { pick(today) }
                    Chip("Tomorrow", date == today.plusDays(1)) { pick(today.plusDays(1)) }
                    val weekend = today.with(TemporalAdjusters.nextOrSame(DayOfWeek.SATURDAY))
                    Chip("This weekend", date == weekend) { pick(weekend) }
                    val nextWeek = today.with(TemporalAdjusters.next(DayOfWeek.MONDAY))
                    Chip("Next week", date == nextWeek) { pick(nextWeek) }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    GlassIconButton(GIcon.BACK, "Previous month", { ym = ym.minusMonths(1) }, size = 40.dp)
                    Text(
                        ym.month.getDisplayName(DowStyle.FULL, Locale.getDefault()) + " " + ym.year,
                        fontSize = 17.sp, fontWeight = FontWeight.Medium,
                        modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    )
                    GlassIconButton(GIcon.CHEVRON_RIGHT, "Next month", { ym = ym.plusMonths(1) }, size = 40.dp)
                }
                Row(Modifier.fillMaxWidth()) {
                    (1..7).forEach { i ->
                        Text(DayOfWeek.of(i).getDisplayName(DowStyle.NARROW, Locale.getDefault()), fontSize = 12.sp, color = c.secondary,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center, modifier = Modifier.weight(1f))
                    }
                }
                val offset = ym.atDay(1).dayOfWeek.value - 1
                val len = ym.lengthOfMonth()
                for (r in 0 until (offset + len + 6) / 7) {
                    Row(Modifier.fillMaxWidth()) {
                        for (col in 0..6) {
                            val n = r * 7 + col - offset + 1
                            if (n < 1 || n > len) {
                                Spacer(Modifier.weight(1f).height(44.dp))
                            } else {
                                val d = ym.atDay(n)
                                val sel = d == date
                                Box(
                                    Modifier.weight(1f).height(44.dp).padding(2.dp).clip(CircleShape)
                                        .background(if (sel) c.accent else Color.Transparent)
                                        .then(if (d == today && !sel) Modifier.border(1.dp, c.accent, CircleShape) else Modifier)
                                        .clickable(role = Role.Button) { date = d; ym = YearMonth.from(d) }
                                        .semantics { contentDescription = d.format(DAY_FMT) },
                                    contentAlignment = Alignment.Center,
                                ) {
                                    Text("$n", fontSize = 15.sp, fontWeight = if (sel) FontWeight.SemiBold else FontWeight.Normal,
                                        color = if (sel) c.onAccent else if (d.isBefore(today)) c.secondary else c.text)
                                }
                            }
                        }
                    }
                }
                Text(
                    date?.let { "Selected: " + it.format(DAY_FMT) + " " + it.year } ?: "No date selected",
                    fontSize = 14.sp, color = c.secondary,
                )
            }

            if (mode != PickMode.DATE) {
                if (mode == PickMode.DATE_TIME) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Set a time", fontSize = 16.sp, modifier = Modifier.weight(1f))
                        GlassSwitch(timeOn) { timeOn = it }
                    }
                }
                if (timeOn) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                        Stepper("%02d".format(minute / 60), "hour",
                            onMinus = { minute = ((minute / 60 + 23) % 24) * 60 + minute % 60 },
                            onPlus = { minute = ((minute / 60 + 1) % 24) * 60 + minute % 60 })
                        Text(":", fontSize = 36.sp, fontWeight = FontWeight.Light, modifier = Modifier.padding(horizontal = 10.dp))
                        Stepper("%02d".format(minute % 60), "minute",
                            onMinus = { minute = (minute / 60) * 60 + (minute % 60 + 55) % 60 },
                            onPlus = { minute = (minute / 60) * 60 + (minute % 60 + 5) % 60 })
                    }
                    Text(fmtClock(minute, false), fontSize = 14.sp, color = c.secondary,
                        modifier = Modifier.fillMaxWidth(), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                    Chips {
                        listOf(8 * 60, 12 * 60, 15 * 60, 18 * 60, 21 * 60).forEach { m ->
                            Chip(fmtClock(m, false), minute == m) { minute = m }
                        }
                    }
                }
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (allowClear) GlassButton("Clear", { onResult(null, null) }, Modifier.weight(1f), primary = false, danger = true)
                GlassButton("Cancel", onDismiss, Modifier.weight(1f), primary = false)
                GlassButton("Done", {
                    onResult(if (mode == PickMode.TIME) null else date, if (mode == PickMode.DATE || !timeOn) null else minute)
                }, Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun Stepper(label: String, name: String, onMinus: () -> Unit, onPlus: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        GlassIconButton(GIcon.PLUS, "Increase $name", onPlus, size = 40.dp)
        Text(label, fontSize = 44.sp, fontWeight = FontWeight.Light)
        GlassIconButton(GIcon.MINUS, "Decrease $name", onMinus, size = 40.dp)
    }
}
