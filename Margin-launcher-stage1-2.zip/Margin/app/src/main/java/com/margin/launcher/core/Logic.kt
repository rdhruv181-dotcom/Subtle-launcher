package com.margin.launcher.core

import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId

/** Pure logic (no Android classes) so it can be unit-tested on the JVM. */
object TimeUtil {
    val zone: ZoneId get() = ZoneId.systemDefault()

    fun toDate(ms: Long): LocalDate = Instant.ofEpochMilli(ms).atZone(zone).toLocalDate()
    fun toTime(ms: Long): LocalTime = Instant.ofEpochMilli(ms).atZone(zone).toLocalTime()
    fun millis(date: LocalDate, hour: Int, minute: Int): Long =
        date.atTime(hour, minute).atZone(zone).toInstant().toEpochMilli()

    fun next(ms: Long, repeat: Repeat): Long {
        val dt = Instant.ofEpochMilli(ms).atZone(zone).toLocalDateTime()
        val n = when (repeat) {
            Repeat.NONE -> dt
            Repeat.DAILY -> dt.plusDays(1)
            Repeat.WEEKLY -> dt.plusWeeks(1)
            Repeat.MONTHLY -> dt.plusMonths(1)
        }
        return n.atZone(zone).toInstant().toEpochMilli()
    }

    fun nextAfter(ms: Long, repeat: Repeat, now: Long): Long {
        if (repeat == Repeat.NONE) return ms
        var t = ms
        while (t <= now) t = next(t, repeat)
        return t
    }
}

object TaskLogic {
    fun isOverdue(t: Task, now: Long): Boolean {
        val d = t.due ?: return false
        if (t.done) return false
        return if (t.hasTime) d < now else TimeUtil.toDate(d).isBefore(TimeUtil.toDate(now))
    }

    /** Completing a recurring task rolls it to its next date instead of closing it. */
    fun complete(t: Task, now: Long): Task {
        val due = t.due
        return if (t.repeat != Repeat.NONE && due != null) {
            t.copy(due = TimeUtil.nextAfter(due, t.repeat, now), subtasks = t.subtasks.map { it.copy(done = false) })
        } else t.copy(done = true, doneAt = now)
    }

    fun progress(t: Task): Float =
        if (t.subtasks.isEmpty()) (if (t.done) 1f else 0f) else t.subtasks.count { it.done } / t.subtasks.size.toFloat()
}

/** Consecutive days (ending today, or yesterday if today is empty) that contain study time. */
fun streak(days: Set<LocalDate>, today: LocalDate): Int {
    var d = if (today in days) today else today.minusDays(1)
    var n = 0
    while (d in days) { n++; d = d.minusDays(1) }
    return n
}

fun minutesPerDay(sessions: List<FocusSession>): Map<LocalDate, Int> =
    sessions.groupBy { TimeUtil.toDate(it.start) }.mapValues { e -> e.value.sumOf { it.minutes } }

/** Next class that hasn't finished yet, looking up to a week ahead. */
fun nextClass(classes: List<ClassEntry>, now: LocalDateTime): Pair<ClassEntry, LocalDate>? {
    val nowMin = now.hour * 60 + now.minute
    for (offset in 0..7) {
        val date = now.toLocalDate().plusDays(offset.toLong())
        val c = classes
            .filter { it.dow == date.dayOfWeek.value && (offset > 0 || it.endMin > nowMin) }
            .minByOrNull { it.startMin }
        if (c != null) return c to date
    }
    return null
}

fun fmtMin(m: Int): String = "%02d:%02d".format(m / 60, m % 60)

fun fmtDuration(minutes: Int): String = when {
    minutes < 60 -> "${minutes}m"
    minutes % 60 == 0 -> "${minutes / 60}h"
    else -> "${minutes / 60}h ${minutes % 60}m"
}
