package com.margin.launcher.data

import android.content.ComponentName
import androidx.compose.runtime.Immutable

@Immutable
data class AppInfo(
    val key: String,            // ComponentName.flattenToString()
    val label: String,
    val packageName: String,
    val component: ComponentName,
)
