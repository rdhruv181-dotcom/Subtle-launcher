package com.margin.launcher.ui.home

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.margin.launcher.Screen
import com.margin.launcher.UiState
import com.margin.launcher.core.*
import com.margin.launcher.data.AppInfo
import com.margin.launcher.data.AppRepository
import com.margin.launcher.data.StudyStore
import com.margin.launcher.system.FocusEngine
import com.margin.launcher.ui.SystemActions
import com.margin.launcher.ui.components.AppIcon
import com.margin.launcher.ui.screens.dueText
import com.margin.launcher.ui.screens.reminderWhen
import com.margin.launcher.ui.theme.M
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomeScreen(
    state: UiState,
    repo: AppRepository,
    store: StudyStore,
    enabled: Boolean,
    onOpenDrawer: () -> Unit,
    onOpenSettings: () -> Unit,
    onSwipeDown: () -> Unit,
    onNavigate: (Screen) -> Unit,
    onLaunch: (AppInfo) -> Unit,
    onDockMenu: (AppInfo) -> Unit,
) {
    val c = M.colors
    val ctx = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val s = state.settings
    val now by rememberNow()
    var drag by remember { mutableFloatStateOf(0f) }

    val tasks by store.tasks.items.collectAsState()
    val classes by store.classes.items.collectAsState()
    val reminders by store.reminders.items.collectAsState()
    val events by store.events.items.collectAsState()
    val focus by FocusEngine.state.collectAsState()

    Column(
        Modifier
            .fillMaxSize()
            .pointerInput(enabled) {
                if (!enabled) return@pointerInput
                val threshold = 56.dp.toPx()
                detectVerticalDragGestures(
                    onDragStart = { drag = 0f },
                    onDragCancel = { drag = 0f },
                    onDragEnd = {
                        if (drag < -threshold) onOpenDrawer() else if (drag > threshold) onSwipeDown()
                        drag = 0f
                    },
                ) { _, dy -> drag += dy }
            }
            .pointerInput(enabled) {
                if (!enabled) return@pointerInput
                detectTapGestures(onLongPress = {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    onOpenSettings()
                })
            }
            .systemBarsPadding().imePadding()
            .padding(horizontal = 28.dp)
    ) {
        Spacer(Modifier.height(40.dp))

        Text(
            greeting(now.hour, s.name), fontSize = 17.sp, color = c.secondary,
            modifier = Modifier.clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { onNavigate(Screen.QUICK) },
        )
        Spacer(Modifier.height(4.dp))

        Row(
            verticalAlignment = Alignment.Bottom,
            modifier = Modifier.clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { onNavigate(Screen.PLANNER) },
        ) {
            val pattern = if (s.use24h) "HH:mm" else "h:mm"
            Text(
                now.format(DateTimeFormatter.ofPattern(pattern)),
                fontSize = 76.sp,
                fontWeight = when (s.clockWeight) { 1 -> FontWeight.Normal; 2 -> FontWeight.Medium; else -> FontWeight.Light },
                letterSpacing = (-2).sp,
            )
            if (!s.use24h) {
                Text(now.format(DateTimeFormatter.ofPattern("a")), fontSize = 20.sp, color = c.secondary,
                    modifier = Modifier.padding(start = 8.dp, bottom = 16.dp))
            }
        }
        Text(now.format(DateTimeFormatter.ofPattern("EEEE, d MMMM")), fontSize = 17.sp, color = c.secondary)
        if (s.showBattery) {
            Spacer(Modifier.height(10.dp))
            BatteryLine()
        }

        Spacer(Modifier.height(22.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            val today = now.toLocalDate()
            val nowMs = System.currentTimeMillis()

            if (focus.active) {
                val sec by produceState(nowMs, focus.phaseEnd, focus.paused) { while (true) { value = System.currentTimeMillis(); delay(1000) } }
                val left = (if (focus.paused) focus.pausedLeft else (focus.phaseEnd - sec).coerceAtLeast(0)) / 1000
                HomeItem(if (focus.phase == 0) "Focusing" else "Break", "%02d:%02d".format(left / 60, left % 60) +
                    focus.subject.takeIf { it.isNotEmpty() }?.let { " · $it" }.orEmpty(), accent = true) { onNavigate(Screen.FOCUS) }
            }

            if (s.showSchedule) nextClass(classes, now)?.let { (k, date) ->
                val whenText = when (date) { today -> ""; today.plusDays(1) -> "Tomorrow "; else -> date.dayOfWeek.name.take(3).lowercase().replaceFirstChar { it.uppercase() } + " " }
                HomeItem("Next class", "${k.subject} · $whenText${fmtMin(k.startMin)}" + if (k.room.isNotEmpty()) " · ${k.room}" else "") { onNavigate(Screen.PLANNER) }
            }

            if (s.showTasks) {
                val due = tasks.filter { t -> !t.done && t.due != null && !TimeUtil.toDate(t.due).isAfter(today) }.sortedBy { it.due }
                val overdue = due.count { TaskLogic.isOverdue(it, nowMs) }
                val text = when {
                    due.isEmpty() -> "Nothing due today"
                    else -> "${due.size} task${if (due.size == 1) "" else "s"}" + (if (overdue > 0) " · $overdue overdue" else "") + " · " + due.first().title
                }
                HomeItem("Today", text) { onNavigate(Screen.TASKS) }
            }

            if (s.showReminder) reminders.filter { !it.done }.minByOrNull { it.time }?.let { r ->
                HomeItem("Reminder", "${r.title} · ${reminderWhen(r.time, r.repeat)}") { onNavigate(Screen.REMINDERS) }
            }

            if (s.showExam) events.filter { it.kind == 1 && it.endDay >= today.toEpochDay() }.minByOrNull { maxOf(it.day, today.toEpochDay()) }?.let { e ->
                val days = maxOf(e.day, today.toEpochDay()) - today.toEpochDay()
                HomeItem("Exam", e.title + " · " + when (days) { 0L -> "today"; 1L -> "tomorrow"; else -> "in $days days" }) { onNavigate(Screen.PLANNER) }
            }

            if (s.showQuickNote) {
                var note by remember { mutableStateOf("") }
                val save = {
                    if (note.isNotBlank()) { store.addNote(note, "Quick"); note = ""; android.widget.Toast.makeText(ctx, "Note saved", android.widget.Toast.LENGTH_SHORT).show() }
                }
                BasicTextField(
                    value = note, onValueChange = { note = it }, singleLine = true,
                    textStyle = TextStyle(fontSize = 16.sp, color = c.text),
                    cursorBrush = SolidColor(c.accent),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = { save() }),
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                    decorationBox = { inner ->
                        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(c.surface).padding(horizontal = 14.dp, vertical = 12.dp)) {
                            if (note.isEmpty()) Text("Quick note…", fontSize = 16.sp, color = c.secondary)
                            inner()
                        }
                    },
                )
            }
        }

        // Discoverability cue for the app drawer.
        Box(
            Modifier.fillMaxWidth().height(28.dp).clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { onOpenDrawer() },
            contentAlignment = Alignment.Center,
        ) {
            Box(Modifier.width(36.dp).height(4.dp).clip(RoundedCornerShape(2.dp)).background(c.hairline))
        }

        if (state.dock.isEmpty()) {
            Text("Long-press an app in the drawer to pin it here.", fontSize = 14.sp, color = c.secondary, modifier = Modifier.padding(vertical = 22.dp))
        } else {
            Row(
                Modifier.fillMaxWidth().padding(bottom = 16.dp).clip(RoundedCornerShape(24.dp)).background(c.surface).padding(vertical = 14.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
            ) {
                state.dock.forEach { app ->
                    AppIcon(
                        app, repo, s.iconDp.dp, s.monoIcons,
                        Modifier.clip(RoundedCornerShape(14.dp)).combinedClickable(
                            onClick = { onLaunch(app) },
                            onLongClick = { haptic.performHapticFeedback(HapticFeedbackType.LongPress); onDockMenu(app) },
                        ),
                    )
                }
            }
        }
    }
}

@Composable
private fun HomeItem(caption: String, text: String, accent: Boolean = false, onClick: () -> Unit) {
    val c = M.colors
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable(onClick = onClick).padding(vertical = 4.dp)) {
        Text(caption.uppercase(), fontSize = 11.sp, letterSpacing = 1.sp, color = c.secondary)
        Text(text, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, color = if (accent) c.accent else c.text)
    }
}

private fun greeting(hour: Int, name: String): String {
    val base = when (hour) {
        in 5..11 -> "Good morning"
        in 12..16 -> "Good afternoon"
        in 17..21 -> "Good evening"
        else -> "Good night"
    }
    return if (name.isBlank()) base else "$base, ${name.trim()}"
}

@Composable
private fun rememberNow(): State<LocalDateTime> = produceState(LocalDateTime.now()) {
    while (true) {
        value = LocalDateTime.now()
        delay(60_000L - (System.currentTimeMillis() % 60_000L) + 50L)
    }
}

@Composable
private fun BatteryLine() {
    val ctx = LocalContext.current
    var text by remember { mutableStateOf("") }
    DisposableEffect(Unit) {
        fun render(i: Intent?) {
            if (i == null) return
            val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
            if (level >= 0) text = "${level * 100 / scale}%" + if (charging) " · Charging" else ""
        }
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) = render(i)
        }
        render(ContextCompat.registerReceiver(ctx, receiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED), ContextCompat.RECEIVER_NOT_EXPORTED))
        onDispose { ctx.unregisterReceiver(receiver) }
    }
    if (text.isNotEmpty()) Text(text, fontSize = 14.sp, color = M.colors.secondary)
}
