package com.margin.launcher.ui.home

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.margin.launcher.Screen
import com.margin.launcher.UiState
import com.margin.launcher.core.*
import com.margin.launcher.data.AppInfo
import com.margin.launcher.data.AppRepository
import com.margin.launcher.data.StudyStore
import com.margin.launcher.system.FocusEngine
import com.margin.launcher.system.displayMs
import com.margin.launcher.ui.components.*
import com.margin.launcher.ui.theme.M
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

@Composable
fun HomeScreen(
    state: UiState,
    repo: AppRepository,
    store: StudyStore,
    enabled: Boolean,
    onOpenDrawer: () -> Unit,
    onOpenSettings: () -> Unit,
    onSwipeDown: () -> Unit,
    onNavigate: (Screen) -> Unit,
    onOpenFocus: () -> Unit,
    onOpenSearch: () -> Unit,
    onLaunch: (AppInfo) -> Unit,
    onDockMenu: (AppInfo) -> Unit,
) {
    val c = M.colors
    val ctx = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val s = state.settings
    val now by rememberNow()
    var drag by remember { mutableFloatStateOf(0f) }

    val tasks by store.tasks.items.collectAsState()
    val classes by store.classes.items.collectAsState()
    val reminders by store.reminders.items.collectAsState()
    val events by store.events.items.collectAsState()
    val sessions by store.sessions.items.collectAsState()
    val focus by FocusEngine.state.collectAsState()
    val tick by produceState(System.currentTimeMillis(), focus.active) {
        while (true) { value = System.currentTimeMillis(); delay(if (focus.active) 1000L else 30_000L) }
    }

    val today = now.toLocalDate()
    val dueTasks = tasks.filter { t -> !t.done && t.due != null && !TimeUtil.toDate(t.due).isAfter(today) }
    val nextReminder = reminders.filter { !it.done }.minByOrNull { it.time }
    val nextExam = events.filter { it.kind == 1 && it.endDay >= today.toEpochDay() }.minByOrNull { maxOf(it.day, today.toEpochDay()) }
    val todayMin = sessions.filter { TimeUtil.toDate(it.start) == today }.sumOf { it.minutes }

    val kinds = buildList {
        if (s.showTasks) add("tasks")
        add("focus")
        if (s.showReminder) add("reminder")
        if (s.showExam && nextExam != null) add("exam")
        if (s.showQuickNote) add("note")
    }
    val pager = rememberPagerState(pageCount = { kinds.size })

    Column(
        Modifier
            .fillMaxSize()
            .pointerInput(enabled) {
                if (!enabled) return@pointerInput
                val threshold = 56.dp.toPx()
                detectVerticalDragGestures(
                    onDragStart = { drag = 0f },
                    onDragCancel = { drag = 0f },
                    onDragEnd = {
                        if (drag < -threshold) onOpenDrawer() else if (drag > threshold) onSwipeDown()
                        drag = 0f
                    },
                ) { _, dy -> drag += dy }
            }
            .pointerInput(enabled) {
                if (!enabled) return@pointerInput
                detectTapGestures(onLongPress = {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    onOpenSettings()
                })
            }
            .systemBarsPadding().imePadding()
            .padding(horizontal = 20.dp)
    ) {
        Spacer(Modifier.height(12.dp))

        // Greeting + quick Focus button
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(
                greeting(now.hour, s.name), fontSize = 22.sp, fontWeight = FontWeight.Medium,
                color = c.text.copy(alpha = 0.85f), maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f).clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { onNavigate(Screen.QUICK) },
            )
            val label = if (focus.active) {
                val sec = focus.displayMs(tick) / 1000
                "%02d:%02d".format(sec / 60, sec % 60)
            } else "Focus"
            FocusPill(focus.active, label, onOpenFocus)
        }

        // Clock + date
        Row(
            verticalAlignment = Alignment.Bottom,
            modifier = Modifier.padding(top = 4.dp).clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { onNavigate(Screen.PLANNER) },
        ) {
            val pattern = if (s.use24h) "HH:mm" else "h:mm"
            Text(
                now.format(DateTimeFormatter.ofPattern(pattern)),
                fontSize = 88.sp,
                fontWeight = when (s.clockWeight) { 1 -> FontWeight.Normal; 2 -> FontWeight.Medium; else -> FontWeight.Light },
                letterSpacing = (-3).sp,
            )
            if (!s.use24h) {
                Text(now.format(DateTimeFormatter.ofPattern("a")), fontSize = 28.sp, fontWeight = FontWeight.Medium,
                    color = c.secondary, modifier = Modifier.padding(start = 10.dp, bottom = 16.dp))
            }
        }
        Text(now.format(DateTimeFormatter.ofPattern("EEEE, d MMMM")), fontSize = 21.sp, color = c.text.copy(alpha = 0.78f))
        if (s.showBattery) { Spacer(Modifier.height(6.dp)); BatteryLine() }

        Spacer(Modifier.height(14.dp))

        // UP NEXT
        if (s.showSchedule) {
            UpNextCard(nextClass(classes, now), s.use24h, today) { onNavigate(Screen.PLANNER) }
            Spacer(Modifier.height(10.dp))
        }

        // Swipeable cards + pagination dots
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
            HorizontalPager(
                state = pager,
                contentPadding = PaddingValues(end = 44.dp),
                pageSpacing = 12.dp,
                modifier = Modifier.fillMaxWidth().height(140.dp),
            ) { page ->
                when (kinds.getOrNull(page)) {
                    "tasks" -> TaskCard(tasks, today, tick) { onNavigate(Screen.TASKS) }
                    "focus" -> FocusCard(todayMin, s.studyDailyMin, focus, tick,
                        onStart = {
                            if (!focus.active) FocusEngine.start(ctx, 25, 5, "", "", 0, s.focusDnd)
                            onNavigate(Screen.FOCUS)
                        },
                        onOpen = { onNavigate(Screen.FOCUS) })
                    "reminder" -> ReminderCard(nextReminder) { onNavigate(Screen.REMINDERS) }
                    "exam" -> nextExam?.let { ExamCard(it, today) { onNavigate(Screen.PLANNER) } }
                    "note" -> QuickNoteCard { store.addNote(it, "Quick"); android.widget.Toast.makeText(ctx, "Note saved", android.widget.Toast.LENGTH_SHORT).show() }
                    else -> Spacer(Modifier.fillMaxSize())
                }
            }
            Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.Center) {
                kinds.indices.forEach { i ->
                    val active = pager.currentPage == i
                    val w by animateDpAsState(if (active) 10.dp else 7.dp, label = "dot")
                    val col by animateColorAsState(if (active) c.text else c.text.copy(alpha = 0.3f), label = "dotColor")
                    Box(Modifier.padding(horizontal = 4.dp).size(w).clip(CircleShape).background(col))
                }
            }
        }

        Spacer(Modifier.height(8.dp))
        GlassSearchPill("Search apps, tasks, notes", onOpenSearch)
        Spacer(Modifier.height(12.dp))

        // Four customisable shortcuts, always on the home screen.
        Row(
            Modifier.fillMaxWidth().glass(34.dp).padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            s.quickTools.mapNotNull { toolFor(it) }.forEach { def ->
                val badge = when (def.screen) {
                    Screen.TASKS -> dueTasks.size
                    Screen.REMINDERS -> reminders.count { !it.done && it.time < tick }
                    else -> 0
                }
                QuickToolTile(def, badge, Modifier.weight(1f).aspectRatio(1f)) {
                    if (def.screen == Screen.FOCUS && !focus.active) onNavigate(Screen.FOCUS) else onNavigate(def.screen)
                }
            }
        }

        Spacer(Modifier.height(10.dp))

        // Favourites dock
        if (state.dock.isEmpty()) {
            Text("Long-press an app in the drawer to add it to your dock.", fontSize = 14.sp, color = c.secondary,
                modifier = Modifier.fillMaxWidth().glass(26.dp).padding(18.dp))
        } else {
            Row(
                Modifier.fillMaxWidth().glass(30.dp).padding(horizontal = 12.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
            ) {
                state.dock.forEach { app ->
                    AppIcon(
                        app, repo, (s.iconDp * 0.85f).dp, s.monoIcons,
                        Modifier.tactile(onClick = { onLaunch(app) }, onLongClick = { onDockMenu(app) }),
                    )
                }
            }
        }
        Spacer(Modifier.height(10.dp))
    }
}

@Composable
private fun FocusPill(active: Boolean, label: String, onClick: () -> Unit) {
    val c = M.colors
    val tint = if (active) c.accent else c.text
    Row(
        Modifier.tactile(onClick).glass(26.dp).padding(horizontal = 16.dp, vertical = 11.dp)
            .semantics { contentDescription = if (active) "Focus session running, open" else "Start focus mode" },
        verticalAlignment = Alignment.CenterVertically,
    ) {
        LineIcon(GIcon.MOON, tint = tint, size = 20.dp)
        Spacer(Modifier.width(8.dp))
        Text(label, fontSize = 17.sp, fontWeight = FontWeight.Medium, color = tint)
    }
}

@Composable
private fun UpNextCard(next: Pair<ClassEntry, LocalDate>?, use24h: Boolean, today: LocalDate, onClick: () -> Unit) {
    val c = M.colors
    GlassCard(Modifier.fillMaxWidth(), radius = 30.dp, onClick = onClick) {
        Column(Modifier.padding(horizontal = 22.dp, vertical = 16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(9.dp).clip(CircleShape).background(c.alert))
                Spacer(Modifier.width(10.dp))
                Text("UP NEXT", fontSize = 13.sp, fontWeight = FontWeight.Medium, letterSpacing = 2.sp, color = c.secondary)
            }
            Spacer(Modifier.height(6.dp))
            if (next == null) {
                Text("No classes scheduled", fontSize = 26.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                Text("Add your timetable in the Planner", fontSize = 16.sp, color = c.secondary)
            } else {
                val (k, date) = next
                val whenText = when (date) { today -> "Today"; today.plusDays(1) -> "Tomorrow"; else -> date.format(DAY_FMT) }
                Text(k.subject, fontSize = 30.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    listOfNotNull(whenText, fmtClock(k.startMin, use24h), k.room.ifEmpty { null }).joinToString(" · "),
                    fontSize = 17.sp, color = c.secondary, maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

private fun greeting(hour: Int, name: String): String {
    val base = when (hour) {
        in 5..11 -> "Good morning"
        in 12..16 -> "Good afternoon"
        in 17..21 -> "Good evening"
        else -> "Good night"
    }
    return if (name.isBlank()) base else "$base, ${name.trim()}"
}

@Composable
private fun rememberNow(): State<LocalDateTime> = produceState(LocalDateTime.now()) {
    while (true) {
        value = LocalDateTime.now()
        delay(60_000L - (System.currentTimeMillis() % 60_000L) + 50L)
    }
}

@Composable
private fun BatteryLine() {
    val ctx = LocalContext.current
    var text by remember { mutableStateOf("") }
    DisposableEffect(Unit) {
        fun render(i: Intent?) {
            if (i == null) return
            val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
            if (level >= 0) text = "${level * 100 / scale}%" + if (charging) " · Charging" else ""
        }
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) = render(i)
        }
        render(ContextCompat.registerReceiver(ctx, receiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED), ContextCompat.RECEIVER_NOT_EXPORTED))
        onDispose { ctx.unregisterReceiver(receiver) }
    }
    if (text.isNotEmpty()) Text(text, fontSize = 14.sp, color = M.colors.secondary)
}
