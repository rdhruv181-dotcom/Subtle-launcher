package com.margin.launcher.ui.home

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.margin.launcher.UiState
import com.margin.launcher.data.AppInfo
import com.margin.launcher.data.AppRepository
import com.margin.launcher.ui.SystemActions
import com.margin.launcher.ui.components.AppIcon
import com.margin.launcher.ui.theme.M
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomeScreen(
    state: UiState,
    repo: AppRepository,
    enabled: Boolean,
    onOpenDrawer: () -> Unit,
    onOpenSettings: () -> Unit,
    onLaunch: (AppInfo) -> Unit,
    onDockMenu: (AppInfo) -> Unit,
) {
    val c = M.colors
    val ctx = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val s = state.settings
    val now by rememberNow()
    var drag by remember { mutableFloatStateOf(0f) }

    Column(
        Modifier
            .fillMaxSize()
            // Swipe up = drawer, swipe down = notification shade.
            .pointerInput(enabled) {
                if (!enabled) return@pointerInput
                val threshold = 56.dp.toPx()
                detectVerticalDragGestures(
                    onDragStart = { drag = 0f },
                    onDragCancel = { drag = 0f },
                    onDragEnd = {
                        if (drag < -threshold) onOpenDrawer()
                        else if (drag > threshold) SystemActions.expandShade(ctx)
                        drag = 0f
                    },
                ) { _, dy -> drag += dy }
            }
            // Long press anywhere = customise.
            .pointerInput(enabled) {
                if (!enabled) return@pointerInput
                detectTapGestures(onLongPress = {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    onOpenSettings()
                })
            }
            .systemBarsPadding()
            .padding(horizontal = 28.dp)
    ) {
        Spacer(Modifier.height(56.dp))

        Text(greeting(now.hour, s.name), fontSize = 17.sp, color = c.secondary)
        Spacer(Modifier.height(4.dp))

        Row(
            verticalAlignment = Alignment.Bottom,
            modifier = Modifier.clickable(
                indication = null, interactionSource = remember { MutableInteractionSource() }
            ) { SystemActions.openCalendar(ctx) }
        ) {
            val pattern = if (s.use24h) "HH:mm" else "h:mm"
            Text(
                now.format(DateTimeFormatter.ofPattern(pattern)),
                fontSize = 76.sp, fontWeight = FontWeight.Light, letterSpacing = (-2).sp,
            )
            if (!s.use24h) {
                Text(
                    now.format(DateTimeFormatter.ofPattern("a")),
                    fontSize = 20.sp, color = c.secondary,
                    modifier = Modifier.padding(start = 8.dp, bottom = 16.dp),
                )
            }
        }
        Text(
            now.format(DateTimeFormatter.ofPattern("EEEE, d MMMM")),
            fontSize = 17.sp, color = c.secondary,
        )
        if (s.showBattery) {
            Spacer(Modifier.height(10.dp))
            BatteryLine()
        }

        Spacer(Modifier.weight(1f))

        // Discoverability cue for the app drawer.
        Box(
            Modifier.fillMaxWidth().height(28.dp).clickable(
                indication = null, interactionSource = remember { MutableInteractionSource() }
            ) { onOpenDrawer() },
            contentAlignment = Alignment.Center,
        ) {
            Box(Modifier.width(36.dp).height(4.dp).clip(RoundedCornerShape(2.dp)).background(c.hairline))
        }

        if (state.dock.isEmpty()) {
            Text(
                "Long-press an app in the drawer to pin it here.",
                fontSize = 14.sp, color = c.secondary,
                modifier = Modifier.padding(vertical = 22.dp),
            )
        } else {
            Row(
                Modifier.fillMaxWidth().padding(bottom = 16.dp)
                    .clip(RoundedCornerShape(24.dp)).background(c.surface).padding(vertical = 14.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
            ) {
                state.dock.forEach { app ->
                    AppIcon(
                        app, repo, 52.dp, s.monoIcons,
                        Modifier.clip(RoundedCornerShape(14.dp)).combinedClickable(
                            onClick = { onLaunch(app) },
                            onLongClick = {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                onDockMenu(app)
                            },
                        ),
                    )
                }
            }
        }
    }
}

private fun greeting(hour: Int, name: String): String {
    val base = when (hour) {
        in 5..11 -> "Good morning"
        in 12..16 -> "Good afternoon"
        in 17..21 -> "Good evening"
        else -> "Good night"
    }
    return if (name.isBlank()) base else "$base, ${name.trim()}"
}

@Composable
private fun rememberNow(): State<LocalDateTime> = produceState(LocalDateTime.now()) {
    while (true) {
        value = LocalDateTime.now()
        delay(60_000L - (System.currentTimeMillis() % 60_000L) + 50L)
    }
}

@Composable
private fun BatteryLine() {
    val ctx = LocalContext.current
    var text by remember { mutableStateOf("") }
    DisposableEffect(Unit) {
        fun render(i: Intent?) {
            if (i == null) return
            val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL
            if (level >= 0) text = "${level * 100 / scale}%" + if (charging) " · Charging" else ""
        }
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) = render(i)
        }
        render(ContextCompat.registerReceiver(
            ctx, receiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED), ContextCompat.RECEIVER_NOT_EXPORTED))
        onDispose { ctx.unregisterReceiver(receiver) }
    }
    if (text.isNotEmpty()) Text(text, fontSize = 14.sp, color = M.colors.secondary)
}
