package com.margin.launcher.system

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.Process
import com.margin.launcher.core.TimeUtil
import com.margin.launcher.data.AppInfo
import java.time.LocalDate

data class Wellbeing(
    val todayMs: Long,
    val topToday: List<Pair<AppInfo, Long>>,
    val days: List<Pair<LocalDate, Long>>,   // last 7 days, oldest first
    val unlocks: Int,
)

object WellbeingRepo {
    fun hasAccess(ctx: Context): Boolean {
        val ops = ctx.getSystemService(AppOpsManager::class.java)
        return ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName) ==
            AppOpsManager.MODE_ALLOWED
    }

    /** Heavy-ish: call off the main thread. Only apps that appear in the launcher are counted. */
    fun load(ctx: Context, apps: List<AppInfo>): Wellbeing {
        val usm = ctx.getSystemService(UsageStatsManager::class.java)
        val byPkg = apps.groupBy { it.packageName }.mapValues { it.value.first() }
        val now = System.currentTimeMillis()
        val today = LocalDate.now()

        fun dayUsage(date: LocalDate): Map<String, Long> {
            val start = TimeUtil.millis(date, 0, 0)
            val end = if (date == today) now else TimeUtil.millis(date.plusDays(1), 0, 0)
            return usm.queryAndAggregateUsageStats(start, end)
                .filter { (pkg, _) -> pkg != ctx.packageName && pkg in byPkg }
                .mapValues { it.value.totalTimeInForeground }
        }

        val days = (6 downTo 0).map { off ->
            val d = today.minusDays(off.toLong())
            d to dayUsage(d).values.sum()
        }
        val todayUsage = dayUsage(today)
        val top = todayUsage.entries.sortedByDescending { it.value }.take(5)
            .mapNotNull { e -> byPkg[e.key]?.let { it to e.value } }

        var unlocks = 0
        val events = usm.queryEvents(TimeUtil.millis(today, 0, 0), now)
        val e = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            if (e.eventType == UsageEvents.Event.KEYGUARD_HIDDEN) unlocks++
        }
        return Wellbeing(todayUsage.values.sum(), top, days, unlocks)
    }
}
