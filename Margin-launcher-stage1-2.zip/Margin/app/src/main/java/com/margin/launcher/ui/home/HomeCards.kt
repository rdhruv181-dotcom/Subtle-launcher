package com.margin.launcher.ui.home

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.margin.launcher.core.*
import com.margin.launcher.system.FocusState
import com.margin.launcher.system.displayMs
import com.margin.launcher.ui.components.*
import com.margin.launcher.ui.screens.dueText
import com.margin.launcher.ui.screens.reminderWhen
import com.margin.launcher.ui.theme.M
import java.time.LocalDate

/** Shared frame for the swipeable cards: icon + small caption, then content. */
@Composable
private fun HomeCard(icon: GIcon, caption: String, onClick: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    val c = M.colors
    GlassCard(Modifier.fillMaxSize(), radius = 30.dp, onClick = onClick) {
        Column(Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                LineIcon(icon, tint = c.secondary, size = 18.dp)
                Spacer(Modifier.width(8.dp))
                Text(caption, fontSize = 13.sp, fontWeight = FontWeight.Medium, letterSpacing = 2.sp, color = c.secondary)
            }
            content()
        }
    }
}

@Composable
fun TaskCard(tasks: List<Task>, today: LocalDate, nowMs: Long, onClick: () -> Unit) {
    val c = M.colors
    val pending = tasks.filter { t -> !t.done && t.due != null && !TimeUtil.toDate(t.due).isAfter(today) }.sortedBy { it.due }
    val doneToday = tasks.count { t -> t.done && t.doneAt != null && TimeUtil.toDate(t.doneAt) == today }
    val upcoming = tasks.filter { t -> !t.done && t.due != null && TimeUtil.toDate(t.due).isAfter(today) }.minByOrNull { it.due ?: Long.MAX_VALUE }
    val first = pending.firstOrNull()
    HomeCard(GIcon.CHECK_CIRCLE, "DUE", onClick) {
        Text("${pending.size}", fontSize = 38.sp, fontWeight = FontWeight.Light)
        Text(
            when { first != null -> first.title; upcoming != null -> "Next: " + upcoming.title; else -> "All clear" },
            fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
        )
        val detail = listOfNotNull(
            first?.let { (if (TaskLogic.isOverdue(it, nowMs)) "Overdue · " else "") + dueText(it, today) },
            if (doneToday > 0) "$doneToday done today" else null,
        ).joinToString(" · ")
        if (detail.isNotEmpty()) Text(detail, fontSize = 13.sp, color = if (first != null && TaskLogic.isOverdue(first, nowMs)) c.alert else c.secondary, maxLines = 1)
    }
}

@Composable
fun FocusCard(
    todayMin: Int, goalMin: Int, focus: FocusState, nowMs: Long,
    onStart: () -> Unit, onOpen: () -> Unit,
) {
    val c = M.colors
    HomeCard(GIcon.TIMER, if (focus.active) "FOCUSING" else "FOCUS TODAY", onOpen) {
        if (focus.active) {
            val s = focus.displayMs(nowMs) / 1000
            Text("%02d:%02d".format(s / 60, s % 60), fontSize = 38.sp, fontWeight = FontWeight.Light, color = c.accent)
            Text(focus.subject.ifEmpty { if (focus.phase == 1) "Break" else "In session" }, fontSize = 17.sp, maxLines = 1)
            Text("Tap to open", fontSize = 13.sp, color = c.secondary)
        } else {
            Text(fmtDuration(todayMin), fontSize = 38.sp, fontWeight = FontWeight.Light)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("of ${fmtDuration(goalMin)} goal", fontSize = 17.sp, maxLines = 1)
                    ProgressBar(todayMin / goalMin.toFloat(), Modifier.padding(top = 6.dp, end = 16.dp))
                }
                GlassButton("Start", onStart, primary = true, icon = GIcon.PLAY)
            }
        }
    }
}

@Composable
fun ReminderCard(r: Reminder?, onClick: () -> Unit) {
    val c = M.colors
    HomeCard(GIcon.BELL, "REMINDER", onClick) {
        Spacer(Modifier.height(6.dp))
        if (r == null) {
            Text("No reminders", fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
            Text("Tap to add one", fontSize = 15.sp, color = c.secondary)
        } else {
            Text(r.title, fontSize = 24.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(reminderWhen(r.time, r.repeat), fontSize = 15.sp, color = if (r.time < System.currentTimeMillis()) c.alert else c.secondary)
        }
    }
}

@Composable
fun ExamCard(e: Event, today: LocalDate, onClick: () -> Unit) {
    val c = M.colors
    val days = maxOf(e.day, today.toEpochDay()) - today.toEpochDay()
    HomeCard(GIcon.CALENDAR, "EXAM", onClick) {
        Row(verticalAlignment = Alignment.Bottom) {
            Text("$days", fontSize = 38.sp, fontWeight = FontWeight.Light, color = if (days <= 3) c.alert else c.text)
            Text(if (days == 1L) " day" else " days", fontSize = 17.sp, color = c.secondary, modifier = Modifier.padding(start = 6.dp, bottom = 8.dp))
        }
        Text(e.title, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        if (e.subject.isNotEmpty()) Text(e.subject, fontSize = 13.sp, color = c.secondary, maxLines = 1)
    }
}

@Composable
fun QuickNoteCard(onSave: (String) -> Unit) {
    val c = M.colors
    var text by remember { mutableStateOf("") }
    HomeCard(GIcon.NOTE, "QUICK NOTE", {}) {
        Spacer(Modifier.height(8.dp))
        BasicTextField(
            value = text, onValueChange = { text = it },
            textStyle = TextStyle(fontSize = 17.sp, color = c.text), cursorBrush = SolidColor(c.accent),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
            keyboardActions = KeyboardActions(onDone = { if (text.isNotBlank()) { onSave(text); text = "" } }),
            modifier = Modifier.fillMaxWidth(),
            decorationBox = { inner ->
                Box { if (text.isEmpty()) Text("Jot something down…", fontSize = 17.sp, color = c.secondary); inner() }
            },
        )
    }
}
