package com.margin.launcher.ui.settings

import android.app.AlarmManager
import android.app.NotificationManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.margin.launcher.LauncherViewModel
import com.margin.launcher.Screen
import com.margin.launcher.UiState
import com.margin.launcher.core.fmtDuration
import com.margin.launcher.data.DrawerStyle
import com.margin.launcher.data.ThemeMode
import com.margin.launcher.system.Scheduling
import com.margin.launcher.system.WellbeingRepo
import com.margin.launcher.ui.SystemActions
import com.margin.launcher.ui.components.*
import com.margin.launcher.ui.home.ALL_TOOLS
import com.margin.launcher.ui.theme.Accents
import com.margin.launcher.ui.theme.M
import org.json.JSONObject

@Composable
fun SettingsScreen(state: UiState, vm: LauncherViewModel, onClose: () -> Unit) {
    val c = M.colors
    val s = state.settings
    val ctx = LocalContext.current
    var name by remember { mutableStateOf(s.name) }
    var picking by remember { mutableStateOf(false) }
    var refresh by remember { mutableIntStateOf(0) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { refresh++ }

    val backup = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(vm.store.exportJson().toString(2).toByteArray()) }
            }.onSuccess { vm.toast("Backup saved") }.onFailure { vm.toast("Couldn't save the backup") }
        }
    }
    val restore = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                val text = ctx.contentResolver.openInputStream(uri)?.use { String(it.readBytes()) } ?: error("empty")
                vm.store.importJson(JSONObject(text))
            }.onSuccess { vm.toast("Backup restored") }.onFailure { vm.toast("That file isn't a Margin backup") }
        }
    }
    val askNotif = rememberNotifPermission()

    // Permission status, re-read whenever the user returns from system settings.
    val notifOn = remember(refresh) { NotificationManagerCompat.from(ctx).areNotificationsEnabled() }
    val exactOn = remember(refresh) { Build.VERSION.SDK_INT < 31 || ctx.getSystemService(AlarmManager::class.java).canScheduleExactAlarms() }
    val dndOn = remember(refresh) { ctx.getSystemService(NotificationManager::class.java).isNotificationPolicyAccessGranted }
    val usageOn = remember(refresh) { WellbeingRepo.hasAccess(ctx) }

    Page("Settings", onClose) {
        LazyColumn(
            Modifier.weight(1f),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(22.dp),
        ) {
            // 1. Appearance
            item {
                GlassSettingsSection("Appearance", GIcon.SUN) {
                    Sub("Theme")
                    Segmented(listOf(ThemeMode.SYSTEM to "Auto", ThemeMode.LIGHT to "Light", ThemeMode.DARK to "Dark"), s.themeMode, vm::setTheme)
                    Sub("Accent")
                    Row(horizontalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.padding(bottom = 6.dp)) {
                        Accents.forEachIndexed { i, (label, color) ->
                            Box(
                                Modifier.size(40.dp).clip(CircleShape).background(color)
                                    .then(if (i == s.accent) Modifier.border(2.dp, c.text, CircleShape) else Modifier)
                                    .semantics { contentDescription = "Accent $label" }
                                    .clickable { vm.setAccent(i) }
                            )
                        }
                    }
                    GlassDivider()
                    ToggleRow("Monochrome icons", s.monoIcons, vm::setMonoIcons)
                    Sub("Icon size")
                    Segmented(listOf(0 to "Small", 1 to "Medium", 2 to "Large"), s.iconSize, vm::setIconSize)
                    Sub("Text size")
                    Segmented(listOf(0 to "Small", 1 to "Default", 2 to "Large"), s.textSize, vm::setTextSize)
                    Sub("Clock weight")
                    Segmented(listOf(0 to "Light", 1 to "Regular", 2 to "Medium"), s.clockWeight, vm::setClockWeight)
                    Spacer(Modifier.height(8.dp))
                }
            }

            // 2. Home screen
            item {
                GlassSettingsSection("Home screen", GIcon.HOME) {
                    Sub("Your name (used in the greeting)")
                    Field(name, { name = it.take(30); vm.setName(name) }, "Optional")
                    GlassDivider()
                    ToggleRow("24-hour clock", s.use24h, vm::set24h)
                    ToggleRow("Show battery", s.showBattery, vm::setShowBattery)
                    GlassDivider()
                    Sub("Show on home")
                    ToggleRow("Up next (class)", s.showSchedule, vm::setShowSchedule)
                    ToggleRow("Tasks card", s.showTasks, vm::setShowTasks)
                    ToggleRow("Reminder card", s.showReminder, vm::setShowReminder)
                    ToggleRow("Exam countdown card", s.showExam, vm::setShowExam)
                    ToggleRow("Quick note card", s.showQuickNote, vm::setShowQuickNote)
                    GlassDivider()
                    Sub("Shortcuts above the dock")
                    s.quickTools.forEachIndexed { slot, current ->
                        Text("Shortcut ${slot + 1}", fontSize = 13.sp, color = c.secondary, modifier = Modifier.padding(top = 8.dp, bottom = 6.dp))
                        Chips { ALL_TOOLS.forEach { t -> Chip(t.label, current == t.screen.name) { vm.setQuickTool(slot, t.screen.name) } } }
                    }
                    Spacer(Modifier.height(8.dp))
                }
            }

            // 3. App drawer
            item {
                GlassSettingsSection("App drawer", GIcon.GRID) {
                    Sub("Style")
                    Segmented(listOf(DrawerStyle.COMPACT to "List", DrawerStyle.GRID to "Grid", DrawerStyle.TEXT to "Text"), s.drawerStyle, vm::setDrawerStyle)
                    ToggleRow("A–Z index on the scrollbar", s.drawerIndex, vm::setDrawerIndex)
                    GlassDivider()
                    Sub("Hidden apps")
                    if (state.hiddenApps.isEmpty()) {
                        Text("Long-press an app in the drawer to hide it.", fontSize = 14.sp, color = c.secondary, modifier = Modifier.padding(bottom = 10.dp))
                    } else state.hiddenApps.forEach { app ->
                        Row(Modifier.fillMaxWidth().clickable { vm.unhide(app.key) }.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(app.label, fontSize = 16.sp, modifier = Modifier.weight(1f))
                            Text("Show", fontSize = 14.sp, color = c.accent)
                        }
                    }
                }
            }

            // 4. Gestures
            item {
                GlassSettingsSection("Gestures", GIcon.SWIPE) {
                    Sub("Swipe down on home")
                    Segmented(listOf(0 to "Quick panel", 1 to "Notifications"), s.swipeDown, vm::setSwipeDown)
                    Text("Swipe up opens the app drawer. Tap the greeting to open the quick panel any time. Long-press the home screen for these settings.",
                        fontSize = 13.sp, color = c.secondary, modifier = Modifier.padding(vertical = 10.dp))
                }
            }

            // 5. Focus mode
            item {
                GlassSettingsSection("Focus mode", GIcon.MOON) {
                    ToggleRow("Silence notifications during focus", s.focusDnd, vm::setFocusDnd)
                    if (s.focusDnd && !dndOn) LinkRow("Grant Do Not Disturb access") {
                        runCatching { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }
                    }
                    GlassDivider()
                    LinkRow("Distracting apps", "${s.distracting.size} selected") { picking = true }
                    Text("Margin asks before opening these from Margin during a session. Android doesn't let a launcher block apps opened from notifications or recents.",
                        fontSize = 13.sp, color = c.secondary, modifier = Modifier.padding(bottom = 10.dp))
                }
            }

            // 6. Notifications
            item {
                GlassSettingsSection("Notifications", GIcon.BELL) {
                    LinkRow("Reminder sound and options") { vm.go(Screen.REMINDERS) }
                    GlassDivider()
                    LinkRow("Battery optimisation", "Open if reminders arrive late") {
                        runCatching { ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
                    }
                    GlassDivider()
                    LinkRow("Re-schedule all reminders") { Scheduling.rescheduleAll(ctx, vm.store); vm.toast("Done") }
                }
            }

            // 7. Productivity
            item {
                GlassSettingsSection("Productivity", GIcon.CHART) {
                    Sub("Daily study goal")
                    Chips { listOf(30, 60, 90, 120, 180, 240).forEach { m -> Chip(fmtDuration(m), s.studyDailyMin == m) { vm.setStudyDaily(m) } } }
                    Sub("Weekly study goal")
                    Chips { listOf(180, 300, 600, 900, 1200).forEach { m -> Chip(fmtDuration(m), s.studyWeeklyMin == m) { vm.setStudyWeekly(m) } } }
                    Sub("Daily screen-time goal")
                    Chips { listOf(60, 120, 180, 240, 360, 480).forEach { m -> Chip(fmtDuration(m), s.screenGoalMin == m) { vm.setScreenGoal(m) } } }
                    Spacer(Modifier.height(8.dp))
                }
            }

            // 8. Permissions
            item {
                GlassSettingsSection("Permissions", GIcon.SHIELD) {
                    LinkRow("Notifications", if (notifOn) "Allowed" else "Off") {
                        askNotif()
                        runCatching { ctx.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)) }
                    }
                    GlassDivider()
                    LinkRow("Exact alarms", if (exactOn) "Allowed" else "Not allowed") {
                        runCatching { ctx.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + ctx.packageName))) }
                    }
                    GlassDivider()
                    LinkRow("Do Not Disturb access", if (dndOn) "Allowed" else "Off") {
                        runCatching { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }
                    }
                    GlassDivider()
                    LinkRow("Usage access (screen time)", if (usageOn) "Allowed" else "Off") {
                        runCatching { ctx.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
                    }
                }
            }

            // 9. Backup and restore
            item {
                GlassSettingsSection("Backup and restore", GIcon.ARCHIVE) {
                    LinkRow("Export data to a file") { backup.launch("margin-backup.json") }
                    GlassDivider()
                    LinkRow("Restore from a backup file") { restore.launch(arrayOf("application/json", "text/plain", "*/*")) }
                    Text("Backups contain tasks, notes, reminders, planner, focus history and journal. Restoring replaces current data.",
                        fontSize = 13.sp, color = c.secondary, modifier = Modifier.padding(bottom = 10.dp))
                }
            }

            // 10. About
            item {
                GlassSettingsSection("About", GIcon.INFO) {
                    LinkRow("Set Margin as default launcher") { SystemActions.defaultLauncherSettings(ctx) }
                    GlassDivider()
                    Text("Margin 0.3.0", fontSize = 15.sp, modifier = Modifier.padding(top = 12.dp))
                    Text("Everything you add stays on this device. No account, no ads, no tracking.",
                        fontSize = 13.sp, color = c.secondary, modifier = Modifier.padding(top = 4.dp, bottom = 12.dp))
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }

    if (picking) AppPickerDialog(state.visibleApps, vm.repo, s.distracting, s.monoIcons, vm::toggleDistracting) { picking = false }
}

@Composable
private fun Sub(text: String) {
    Text(text, fontSize = 14.sp, color = M.colors.secondary, modifier = Modifier.padding(top = 12.dp, bottom = 8.dp))
}
