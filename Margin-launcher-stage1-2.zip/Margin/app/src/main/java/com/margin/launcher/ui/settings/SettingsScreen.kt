package com.margin.launcher.ui.settings

import android.app.AlarmManager
import android.app.NotificationManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.margin.launcher.LauncherViewModel
import com.margin.launcher.Screen
import com.margin.launcher.UiState
import com.margin.launcher.core.fmtDuration
import com.margin.launcher.data.DrawerStyle
import com.margin.launcher.data.ThemeMode
import com.margin.launcher.system.Scheduling
import com.margin.launcher.system.WellbeingRepo
import com.margin.launcher.ui.SystemActions
import com.margin.launcher.ui.components.*
import com.margin.launcher.ui.home.ALL_TOOLS
import com.margin.launcher.ui.theme.Accents
import com.margin.launcher.ui.theme.IOS
import com.margin.launcher.ui.theme.M
import org.json.JSONObject

private const val APPEARANCE = "Appearance"
private const val HOME = "Home Screen"
private const val DRAWER = "App Drawer"
private const val GESTURES = "Gestures"
private const val FOCUS = "Focus Mode"
private const val NOTIFS = "Notifications"
private const val PRODUCTIVITY = "Productivity"
private const val PERMISSIONS = "Permissions"
private const val BACKUP = "Backup and Restore"
private const val ABOUT = "About"

/** Laid out like iPhone Settings: a list of coloured categories, each opening its own page. */
@Composable
fun SettingsScreen(state: UiState, vm: LauncherViewModel, onClose: () -> Unit) {
    val s = state.settings
    val ctx = LocalContext.current
    var section by remember { mutableStateOf<String?>(null) }
    var picking by remember { mutableStateOf(false) }
    var refresh by remember { mutableIntStateOf(0) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { refresh++ }
    BackHandler(enabled = section != null) { section = null }

    val backup = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(vm.store.exportJson().toString(2).toByteArray()) }
            }.onSuccess { vm.toast("Backup saved") }.onFailure { vm.toast("Couldn't save the backup") }
        }
    }
    val restore = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                val text = ctx.contentResolver.openInputStream(uri)?.use { String(it.readBytes()) } ?: error("empty")
                vm.store.importJson(JSONObject(text))
            }.onSuccess { vm.toast("Backup restored") }.onFailure { vm.toast("That file isn't a Margin backup") }
        }
    }
    val askNotif = rememberNotifPermission()

    // Permission status, re-read whenever the user returns from system settings.
    val notifOn = remember(refresh) { NotificationManagerCompat.from(ctx).areNotificationsEnabled() }
    val exactOn = remember(refresh) { Build.VERSION.SDK_INT < 31 || ctx.getSystemService(AlarmManager::class.java).canScheduleExactAlarms() }
    val dndOn = remember(refresh) { ctx.getSystemService(NotificationManager::class.java).isNotificationPolicyAccessGranted }
    val usageOn = remember(refresh) { WellbeingRepo.hasAccess(ctx) }

    AnimatedContent(
        targetState = section,
        transitionSpec = {
            if (targetState != null) {
                (slideInHorizontally(tween(260)) { it / 3 } + fadeIn(tween(200))) togetherWith (slideOutHorizontally(tween(220)) { -it / 5 } + fadeOut(tween(140)))
            } else {
                (slideInHorizontally(tween(260)) { -it / 5 } + fadeIn(tween(200))) togetherWith (slideOutHorizontally(tween(220)) { it / 3 } + fadeOut(tween(140)))
            }
        },
        label = "settings",
    ) { sec ->
        if (sec == null) {
            SettingsRoot(state, onClose) { section = it }
        } else {
            Page(sec, { section = null }, backLabel = "Settings") {
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(bottom = 32.dp)) {
                    when (sec) {
                        APPEARANCE -> AppearancePage(state, vm)
                        HOME -> HomePage(state, vm)
                        DRAWER -> DrawerPage(state, vm)
                        GESTURES -> GesturesPage(state, vm)
                        FOCUS -> FocusPage(state, vm, dndOn, ctx) { picking = true }
                        NOTIFS -> NotificationsPage(vm, ctx)
                        PRODUCTIVITY -> ProductivityPage(state, vm)
                        PERMISSIONS -> PermissionsPage(ctx, notifOn, exactOn, dndOn, usageOn, askNotif)
                        BACKUP -> BackupPage({ backup.launch("margin-backup.json") }, { restore.launch(arrayOf("application/json", "text/plain", "*/*")) })
                        else -> AboutPage(ctx)
                    }
                }
            }
        }
    }

    if (picking) AppPickerDialog(state.visibleApps, vm.repo, s.distracting, s.monoIcons, vm::toggleDistracting) { picking = false }
}

@Composable
private fun SettingsRoot(state: UiState, onClose: () -> Unit, openSection: (String) -> Unit) {
    val c = M.colors
    val name = state.settings.name
    Page("Settings", onClose, backLabel = "Home") {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(bottom = 32.dp)) {
            InsetGroup(Modifier.padding(top = 4.dp)) {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(56.dp).clip(CircleShape).background(c.accent), contentAlignment = Alignment.Center) {
                        Text((name.firstOrNull() ?: 'S').uppercase(), fontSize = 24.sp, fontWeight = FontWeight.SemiBold, color = c.onAccent)
                    }
                    Spacer(Modifier.width(16.dp))
                    Column {
                        Text(name.ifBlank { "Student" }, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                        Text("Margin · everything stays on this device", fontSize = 13.sp, color = c.secondary)
                    }
                }
            }
            Spacer(Modifier.height(20.dp))
            InsetGroup {
                ListRow(APPEARANCE, icon = GIcon.SUN, iconColor = IOS.Blue, onClick = { openSection(APPEARANCE) })
                RowDivider(60.dp)
                ListRow(HOME, icon = GIcon.HOME, iconColor = IOS.Indigo, onClick = { openSection(HOME) })
                RowDivider(60.dp)
                ListRow(DRAWER, icon = GIcon.GRID, iconColor = IOS.Purple, onClick = { openSection(DRAWER) })
                RowDivider(60.dp)
                ListRow(GESTURES, icon = GIcon.SWIPE, iconColor = IOS.Gray, onClick = { openSection(GESTURES) })
            }
            Spacer(Modifier.height(20.dp))
            InsetGroup {
                ListRow(FOCUS, icon = GIcon.MOON, iconColor = IOS.Indigo, onClick = { openSection(FOCUS) })
                RowDivider(60.dp)
                ListRow(NOTIFS, icon = GIcon.BELL, iconColor = IOS.Red, onClick = { openSection(NOTIFS) })
                RowDivider(60.dp)
                ListRow(PRODUCTIVITY, icon = GIcon.CHART, iconColor = IOS.Green, onClick = { openSection(PRODUCTIVITY) })
            }
            Spacer(Modifier.height(20.dp))
            InsetGroup {
                ListRow(PERMISSIONS, icon = GIcon.SHIELD, iconColor = IOS.Blue, onClick = { openSection(PERMISSIONS) })
                RowDivider(60.dp)
                ListRow(BACKUP, icon = GIcon.ARCHIVE, iconColor = IOS.Gray, onClick = { openSection(BACKUP) })
                RowDivider(60.dp)
                ListRow(ABOUT, icon = GIcon.INFO, iconColor = IOS.Gray, onClick = { openSection(ABOUT) })
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Category pages
// ---------------------------------------------------------------------------------------------

@Composable
private fun ColumnScope.AppearancePage(state: UiState, vm: LauncherViewModel) {
    val c = M.colors
    val s = state.settings
    GroupHeader("Theme")
    InsetGroup { GroupPad { Segmented(listOf(ThemeMode.SYSTEM to "Auto", ThemeMode.LIGHT to "Light", ThemeMode.DARK to "Dark"), s.themeMode, vm::setTheme) } }
    GroupHeader("Accent colour")
    InsetGroup {
        GroupPad {
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp), modifier = Modifier.padding(vertical = 4.dp)) {
                Accents.forEachIndexed { i, (label, color) ->
                    Box(
                        Modifier.size(40.dp).clip(CircleShape).background(color)
                            .then(if (i == s.accent) Modifier.border(3.dp, c.text, CircleShape) else Modifier)
                            .semantics { contentDescription = "Accent $label" }
                            .clickable { vm.setAccent(i) }
                    )
                }
            }
        }
    }
    GroupHeader("Icons")
    InsetGroup {
        GroupPad { ToggleRow("Monochrome icons", s.monoIcons, vm::setMonoIcons) }
        RowDivider()
        GroupPad { Segmented(listOf(0 to "Small", 1 to "Medium", 2 to "Large"), s.iconSize, vm::setIconSize) }
    }
    GroupHeader("Text size")
    InsetGroup { GroupPad { Segmented(listOf(0 to "Small", 1 to "Default", 2 to "Large"), s.textSize, vm::setTextSize) } }
    GroupHeader("Clock weight")
    InsetGroup { GroupPad { Segmented(listOf(0 to "Light", 1 to "Regular", 2 to "Medium"), s.clockWeight, vm::setClockWeight) } }
}

@Composable
private fun ColumnScope.HomePage(state: UiState, vm: LauncherViewModel) {
    val s = state.settings
    var name by remember { mutableStateOf(s.name) }
    GroupHeader("Your name")
    InsetGroup { GroupPad { Field(name, { name = it.take(30); vm.setName(name) }, "Used in the greeting") } }
    GroupHeader("Clock")
    InsetGroup {
        GroupPad { ToggleRow("24-hour clock", s.use24h, vm::set24h) }
        RowDivider()
        GroupPad { ToggleRow("Show battery", s.showBattery, vm::setShowBattery) }
    }
    GroupHeader("Cards")
    InsetGroup {
        GroupPad { ToggleRow("Tasks card", s.showTasks, vm::setShowTasks) }
        RowDivider()
        GroupPad { ToggleRow("Reminder card", s.showReminder, vm::setShowReminder) }
        RowDivider()
        GroupPad { ToggleRow("Exam countdown card", s.showExam, vm::setShowExam) }
        RowDivider()
        GroupPad { ToggleRow("Quick note card", s.showQuickNote, vm::setShowQuickNote) }
    }
    s.quickTools.forEachIndexed { slot, current ->
        GroupHeader("Shortcut ${slot + 1}")
        InsetGroup { GroupPad { Chips { ALL_TOOLS.forEach { t -> Chip(t.label, current == t.screen.name) { vm.setQuickTool(slot, t.screen.name) } } } } }
    }
    GroupFooter("The four coloured shortcuts sit above the dock on your home screen.")
}

@Composable
private fun ColumnScope.DrawerPage(state: UiState, vm: LauncherViewModel) {
    val s = state.settings
    GroupHeader("Style")
    InsetGroup {
        GroupPad { Segmented(listOf(DrawerStyle.COMPACT to "List", DrawerStyle.GRID to "Grid", DrawerStyle.TEXT to "Text"), s.drawerStyle, vm::setDrawerStyle) }
        RowDivider()
        GroupPad { ToggleRow("A–Z index on the scrollbar", s.drawerIndex, vm::setDrawerIndex) }
    }
    GroupHeader("Hidden apps")
    InsetGroup {
        if (state.hiddenApps.isEmpty()) {
            Text("Long-press an app in the drawer to hide it.", fontSize = 15.sp, color = M.colors.secondary, modifier = Modifier.padding(16.dp))
        }
        state.hiddenApps.forEachIndexed { i, app ->
            if (i > 0) RowDivider()
            ListRow(app.label, value = "Show", chevron = false, onClick = { vm.unhide(app.key) })
        }
    }
}

@Composable
private fun ColumnScope.GesturesPage(state: UiState, vm: LauncherViewModel) {
    GroupHeader("Swipe down on home")
    InsetGroup { GroupPad { Segmented(listOf(0 to "Quick panel", 1 to "Notifications"), state.settings.swipeDown, vm::setSwipeDown) } }
    GroupFooter("Swipe up opens the app drawer. Tap the greeting to openSection the quick panel at any time. Long-press the home screen for Settings.")
}

@Composable
private fun ColumnScope.FocusPage(state: UiState, vm: LauncherViewModel, dndOn: Boolean, ctx: android.content.Context, pickApps: () -> Unit) {
    val s = state.settings
    GroupHeader("Do Not Disturb")
    InsetGroup {
        GroupPad { ToggleRow("Silence notifications during focus", s.focusDnd, vm::setFocusDnd) }
        if (s.focusDnd && !dndOn) {
            RowDivider()
            ListRow("Grant Do Not Disturb access", onClick = { runCatching { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) } })
        }
    }
    GroupHeader("Distracting apps")
    InsetGroup { ListRow("Choose apps", value = "${s.distracting.size} selected", onClick = pickApps) }
    GroupFooter("Margin asks before opening these from Margin during a focus session. Android doesn't let a launcher block apps opened from notifications or the recents screen.")
}

@Composable
private fun ColumnScope.NotificationsPage(vm: LauncherViewModel, ctx: android.content.Context) {
    GroupHeader("Reminders")
    InsetGroup {
        ListRow("Sound and options", icon = GIcon.BELL, iconColor = IOS.Red, onClick = { vm.go(Screen.REMINDERS) })
        RowDivider(60.dp)
        ListRow("Battery optimisation", value = "If reminders arrive late", onClick = {
            runCatching { ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
        })
        RowDivider()
        ListRow("Re-schedule all reminders", chevron = false, onClick = { Scheduling.rescheduleAll(ctx, vm.store); vm.toast("Done") })
    }
}

@Composable
private fun ColumnScope.ProductivityPage(state: UiState, vm: LauncherViewModel) {
    val s = state.settings
    GroupHeader("Daily study goal")
    InsetGroup { GroupPad { Chips { listOf(30, 60, 90, 120, 180, 240).forEach { m -> Chip(fmtDuration(m), s.studyDailyMin == m) { vm.setStudyDaily(m) } } } } }
    GroupHeader("Weekly study goal")
    InsetGroup { GroupPad { Chips { listOf(180, 300, 600, 900, 1200).forEach { m -> Chip(fmtDuration(m), s.studyWeeklyMin == m) { vm.setStudyWeekly(m) } } } } }
    GroupHeader("Daily screen-time goal")
    InsetGroup { GroupPad { Chips { listOf(60, 120, 180, 240, 360, 480).forEach { m -> Chip(fmtDuration(m), s.screenGoalMin == m) { vm.setScreenGoal(m) } } } } }
}

@Composable
private fun ColumnScope.PermissionsPage(
    ctx: android.content.Context, notifOn: Boolean, exactOn: Boolean, dndOn: Boolean, usageOn: Boolean, askNotif: () -> Unit,
) {
    GroupHeader("Access")
    InsetGroup {
        ListRow("Notifications", value = if (notifOn) "Allowed" else "Off", onClick = {
            askNotif()
            runCatching { ctx.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)) }
        })
        RowDivider()
        ListRow("Exact alarms", value = if (exactOn) "Allowed" else "Not allowed", onClick = {
            runCatching { ctx.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + ctx.packageName))) }
        })
        RowDivider()
        ListRow("Do Not Disturb access", value = if (dndOn) "Allowed" else "Off", onClick = {
            runCatching { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }
        })
        RowDivider()
        ListRow("Usage access", value = if (usageOn) "Allowed" else "Off", onClick = {
            runCatching { ctx.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
        })
    }
    GroupFooter("Usage access powers Screen Time. Exact alarms make reminders arrive on the minute.")
}

@Composable
private fun ColumnScope.BackupPage(export: () -> Unit, restore: () -> Unit) {
    GroupHeader("Your data")
    InsetGroup {
        ListRow("Export to a file", icon = GIcon.ARCHIVE, iconColor = IOS.Blue, onClick = export)
        RowDivider(60.dp)
        ListRow("Restore from a backup", icon = GIcon.ARCHIVE, iconColor = IOS.Green, onClick = restore)
    }
    GroupFooter("Backups contain tasks, notes, reminders, calendar events, focus history and journal. Restoring replaces current data.")
}

@Composable
private fun ColumnScope.AboutPage(ctx: android.content.Context) {
    InsetGroup(Modifier.padding(top = 8.dp)) {
        ListRow("Version", value = "0.4.0", chevron = false)
        RowDivider()
        ListRow("Set Margin as default launcher", onClick = { SystemActions.defaultLauncherSettings(ctx) })
    }
    GroupFooter("Everything you add stays on this device. No account, no ads, no tracking. Typeface: Inter, licensed under the SIL Open Font License.")
}
