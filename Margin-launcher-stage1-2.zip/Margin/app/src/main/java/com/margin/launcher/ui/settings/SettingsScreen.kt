package com.margin.launcher.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.margin.launcher.LauncherViewModel
import com.margin.launcher.UiState
import com.margin.launcher.data.DrawerStyle
import com.margin.launcher.data.ThemeMode
import com.margin.launcher.ui.SystemActions
import com.margin.launcher.ui.theme.Accents
import com.margin.launcher.ui.theme.M

@Composable
fun SettingsScreen(state: UiState, vm: LauncherViewModel, onClose: () -> Unit) {
    val c = M.colors
    val s = state.settings
    val ctx = LocalContext.current
    var name by remember { mutableStateOf(s.name) }

    Column(
        Modifier.fillMaxSize().background(c.bg)
            .pointerInput(Unit) { detectVerticalDragGestures { _, _ -> } }
            .systemBarsPadding().imePadding()
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 18.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("Settings", fontSize = 28.sp, fontWeight = FontWeight.Light, modifier = Modifier.weight(1f))
            Text("Done", fontSize = 16.sp, color = c.accent, fontWeight = FontWeight.Medium,
                modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable(onClick = onClose).padding(8.dp))
        }

        LazyColumn(contentPadding = PaddingValues(horizontal = 24.dp, vertical = 8.dp)) {
            // ----- Appearance -----
            item { Section("Appearance") }
            item {
                Segmented(
                    listOf(ThemeMode.SYSTEM to "Auto", ThemeMode.LIGHT to "Light", ThemeMode.DARK to "Dark"),
                    s.themeMode, vm::setTheme,
                )
            }
            item {
                Spacer(Modifier.height(18.dp))
                Text("Accent", fontSize = 14.sp, color = c.secondary)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    Accents.forEachIndexed { i, (_, color) ->
                        val selected = i == s.accent
                        Box(
                            Modifier.size(36.dp).clip(CircleShape).background(color)
                                .then(if (selected) Modifier.border(2.dp, c.text, CircleShape) else Modifier)
                                .clickable { vm.setAccent(i) }
                        )
                    }
                }
            }
            item { ToggleRow("Monochrome icons", s.monoIcons, vm::setMonoIcons) }

            // ----- Home -----
            item { Section("Home") }
            item {
                Text("Your name (used in the greeting)", fontSize = 14.sp, color = c.secondary)
                Spacer(Modifier.height(8.dp))
                BasicTextField(
                    value = name,
                    onValueChange = { name = it.take(30); vm.setName(name) },
                    singleLine = true,
                    textStyle = TextStyle(fontSize = 17.sp, color = c.text),
                    cursorBrush = SolidColor(c.accent),
                    modifier = Modifier.fillMaxWidth(),
                    decorationBox = { inner ->
                        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(c.surface)
                            .padding(horizontal = 14.dp, vertical = 12.dp)) {
                            if (name.isEmpty()) Text("Optional", fontSize = 17.sp, color = c.secondary)
                            inner()
                        }
                    },
                )
            }
            item { ToggleRow("24-hour clock", s.use24h, vm::set24h) }
            item { ToggleRow("Show battery", s.showBattery, vm::setShowBattery) }

            // ----- Drawer -----
            item { Section("App drawer") }
            item {
                Segmented(
                    listOf(DrawerStyle.GRID to "Grid", DrawerStyle.COMPACT to "Compact", DrawerStyle.TEXT to "Text"),
                    s.drawerStyle, vm::setDrawerStyle,
                )
            }

            // ----- Hidden apps -----
            item { Section("Hidden apps") }
            if (state.hiddenApps.isEmpty()) {
                item { Text("Long-press an app in the drawer to hide it.", fontSize = 14.sp, color = c.secondary) }
            } else {
                items(state.hiddenApps.size) { i ->
                    val app = state.hiddenApps[i]
                    Row(
                        Modifier.fillMaxWidth().clickable { vm.unhide(app.key) }.padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(app.label, fontSize = 16.sp, modifier = Modifier.weight(1f))
                        Text("Show", fontSize = 14.sp, color = c.accent)
                    }
                }
            }

            // ----- System -----
            item { Section("System") }
            item {
                Text("Set Margin as default launcher", fontSize = 16.sp, color = c.accent,
                    modifier = Modifier.fillMaxWidth().clickable { SystemActions.defaultLauncherSettings(ctx) }
                        .padding(vertical = 12.dp))
            }
            item { Spacer(Modifier.height(32.dp)) }
        }
    }
}

@Composable
private fun Section(title: String) {
    Text(title.uppercase(), fontSize = 12.sp, fontWeight = FontWeight.Medium, letterSpacing = 1.sp,
        color = M.colors.secondary, modifier = Modifier.padding(top = 28.dp, bottom = 12.dp))
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val c = M.colors
    Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontSize = 16.sp, modifier = Modifier.weight(1f))
        Switch(
            checked = checked, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedTrackColor = c.accent, checkedThumbColor = c.onAccent,
                uncheckedTrackColor = c.surface, uncheckedThumbColor = c.secondary,
                uncheckedBorderColor = c.hairline,
            ),
        )
    }
}

@Composable
private fun <T> Segmented(options: List<Pair<T, String>>, selected: T, onSelect: (T) -> Unit) {
    val c = M.colors
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(c.surface).padding(3.dp)) {
        options.forEach { (value, label) ->
            val sel = value == selected
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(10.dp))
                    .background(if (sel) c.bg else Color.Transparent)
                    .clickable { onSelect(value) }.padding(vertical = 10.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(label, fontSize = 14.sp, fontWeight = if (sel) FontWeight.Medium else FontWeight.Normal,
                    color = if (sel) c.text else c.secondary)
            }
        }
    }
}
