package com.margin.launcher.ui.settings

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.margin.launcher.LauncherViewModel
import com.margin.launcher.UiState
import com.margin.launcher.data.DrawerStyle
import com.margin.launcher.data.ThemeMode
import com.margin.launcher.system.Scheduling
import com.margin.launcher.ui.SystemActions
import com.margin.launcher.ui.components.*
import com.margin.launcher.ui.theme.Accents
import com.margin.launcher.ui.theme.M
import org.json.JSONObject

@Composable
fun SettingsScreen(state: UiState, vm: LauncherViewModel, onClose: () -> Unit) {
    val c = M.colors
    val s = state.settings
    val ctx = LocalContext.current
    var name by remember { mutableStateOf(s.name) }
    var picking by remember { mutableStateOf(false) }

    val backup = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(vm.store.exportJson().toString(2).toByteArray()) }
            }.onSuccess { vm.toast("Backup saved") }.onFailure { vm.toast("Couldn't save the backup") }
        }
    }
    val restore = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                val text = ctx.contentResolver.openInputStream(uri)?.use { String(it.readBytes()) } ?: error("empty")
                vm.store.importJson(JSONObject(text))
            }.onSuccess { vm.toast("Backup restored") }.onFailure { vm.toast("That file isn't a Margin backup") }
        }
    }
    val notifPermission = rememberNotifPermission()

    Page("Settings", onClose) {
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 24.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            // ----- Appearance -----
            item { Section("Appearance") }
            item { Segmented(listOf(ThemeMode.SYSTEM to "Auto", ThemeMode.LIGHT to "Light", ThemeMode.DARK to "Dark"), s.themeMode, vm::setTheme) }
            item {
                Text("Accent", fontSize = 14.sp, color = c.secondary)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    Accents.forEachIndexed { i, (label, color) ->
                        Box(
                            Modifier.size(40.dp).clip(CircleShape).background(color)
                                .then(if (i == s.accent) Modifier.border(2.dp, c.text, CircleShape) else Modifier)
                                .semantics { contentDescription = "Accent $label" }
                                .clickable { vm.setAccent(i) }
                        )
                    }
                }
            }
            item { ToggleRow("Monochrome icons", s.monoIcons, vm::setMonoIcons) }
            item { Text("Icon size", fontSize = 14.sp, color = c.secondary); Spacer(Modifier.height(6.dp)); Segmented(listOf(0 to "Small", 1 to "Medium", 2 to "Large"), s.iconSize, vm::setIconSize) }
            item { Text("Text size", fontSize = 14.sp, color = c.secondary); Spacer(Modifier.height(6.dp)); Segmented(listOf(0 to "Small", 1 to "Default", 2 to "Large"), s.textSize, vm::setTextSize) }
            item { Text("Clock weight", fontSize = 14.sp, color = c.secondary); Spacer(Modifier.height(6.dp)); Segmented(listOf(0 to "Light", 1 to "Regular", 2 to "Medium"), s.clockWeight, vm::setClockWeight) }

            // ----- Home -----
            item { Section("Home") }
            item {
                Text("Your name (used in the greeting)", fontSize = 14.sp, color = c.secondary)
                Spacer(Modifier.height(8.dp))
                Field(name, { name = it.take(30); vm.setName(name) }, "Optional")
            }
            item { ToggleRow("24-hour clock", s.use24h, vm::set24h) }
            item { ToggleRow("Show battery", s.showBattery, vm::setShowBattery) }
            item { Text("Show on home", fontSize = 14.sp, color = c.secondary, modifier = Modifier.padding(top = 8.dp)) }
            item { ToggleRow("Next class", s.showSchedule, vm::setShowSchedule) }
            item { ToggleRow("Today's tasks", s.showTasks, vm::setShowTasks) }
            item { ToggleRow("Next reminder", s.showReminder, vm::setShowReminder) }
            item { ToggleRow("Exam countdown", s.showExam, vm::setShowExam) }
            item { ToggleRow("Quick note", s.showQuickNote, vm::setShowQuickNote) }

            // ----- Gestures -----
            item { Section("Gestures") }
            item {
                Text("Swipe down on home", fontSize = 14.sp, color = c.secondary)
                Spacer(Modifier.height(6.dp))
                Segmented(listOf(0 to "Quick panel", 1 to "Notifications"), s.swipeDown, vm::setSwipeDown)
                Text("Tap the greeting to open the quick panel any time. Long-press the home screen for these settings.",
                    fontSize = 13.sp, color = c.secondary, modifier = Modifier.padding(top = 8.dp))
            }

            // ----- Drawer -----
            item { Section("App drawer") }
            item { Segmented(listOf(DrawerStyle.GRID to "Grid", DrawerStyle.COMPACT to "Compact", DrawerStyle.TEXT to "Text"), s.drawerStyle, vm::setDrawerStyle) }

            item { Section("Hidden apps") }
            if (state.hiddenApps.isEmpty()) {
                item { Text("Long-press an app in the drawer to hide it.", fontSize = 14.sp, color = c.secondary) }
            } else {
                items(state.hiddenApps, key = { it.key }) { app ->
                    Row(Modifier.fillMaxWidth().clickable { vm.unhide(app.key) }.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(app.label, fontSize = 16.sp, modifier = Modifier.weight(1f))
                        Text("Show", fontSize = 14.sp, color = c.accent)
                    }
                }
            }

            // ----- Focus -----
            item { Section("Focus mode") }
            item {
                val dnd = ctx.getSystemService(NotificationManager::class.java).isNotificationPolicyAccessGranted
                ToggleRow("Silence notifications during focus", s.focusDnd, vm::setFocusDnd)
                if (s.focusDnd && !dnd) LinkRow("Grant Do Not Disturb access") {
                    runCatching { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }
                }
                LinkRow("Distracting apps", "${s.distracting.size} selected") { picking = true }
            }

            // ----- Notifications & alarms -----
            item { Section("Reminders & alarms") }
            item {
                LinkRow("Allow notifications") { notifPermission(); runCatching { ctx.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)) } }
                if (Build.VERSION.SDK_INT >= 31) {
                    val exact = ctx.getSystemService(AlarmManager::class.java).canScheduleExactAlarms()
                    LinkRow("Exact alarms", if (exact) "Allowed" else "Not allowed") {
                        runCatching { ctx.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + ctx.packageName))) }
                    }
                }
                LinkRow("Battery optimisation", "Open if reminders arrive late") {
                    runCatching { ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
                }
                LinkRow("Re-schedule all reminders") { Scheduling.rescheduleAll(ctx, vm.store); vm.toast("Done") }
            }

            // ----- Backup -----
            item { Section("Backup & restore") }
            item {
                LinkRow("Export data to a file") { backup.launch("margin-backup.json") }
                LinkRow("Restore from a backup file") { restore.launch(arrayOf("application/json", "text/plain", "*/*")) }
                Text("Backups contain tasks, notes, reminders, planner, focus history and journal. Restoring replaces current data.",
                    fontSize = 13.sp, color = c.secondary)
            }

            // ----- System -----
            item { Section("System") }
            item { LinkRow("Set Margin as default launcher") { SystemActions.defaultLauncherSettings(ctx) } }
            item { Text("Margin 0.2.0 · all data stays on this device", fontSize = 12.sp, color = c.secondary, modifier = Modifier.padding(vertical = 24.dp)) }
        }
    }

    if (picking) AppPickerDialog(state.visibleApps, vm.repo, s.distracting, s.monoIcons, vm::toggleDistracting) { picking = false }
}

@Composable
private fun Section(title: String) {
    Text(title.uppercase(), fontSize = 12.sp, fontWeight = FontWeight.Medium, letterSpacing = 1.sp,
        color = M.colors.secondary, modifier = Modifier.padding(top = 26.dp, bottom = 4.dp))
}
