package com.margin.launcher.system

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.net.Uri
import androidx.core.app.NotificationCompat
import com.margin.launcher.MainActivity
import com.margin.launcher.R

object Notifs {
    private const val CH_FOCUS = "focus"
    private const val CH_TIMER = "timer"

    private fun sp(ctx: Context) = ctx.getSharedPreferences("margin_sys", Context.MODE_PRIVATE)

    /** "" = system default, "silent", or a ringtone URI. */
    fun reminderSound(ctx: Context): String = sp(ctx).getString("reminder_sound", "") ?: ""

    /** Channel sounds can't change after creation, so each sound gets its own channel. */
    private fun reminderChannel(ctx: Context): String {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        val sound = reminderSound(ctx)
        val id = "reminders_" + sound.hashCode()
        if (nm.getNotificationChannel(id) == null) {
            val ch = NotificationChannel(id, "Reminders", NotificationManager.IMPORTANCE_HIGH)
            when (sound) {
                "" -> Unit
                "silent" -> ch.setSound(null, null)
                else -> ch.setSound(
                    Uri.parse(sound),
                    AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).build(),
                )
            }
            nm.createNotificationChannel(ch)
        }
        return id
    }

    private fun simpleChannel(ctx: Context, id: String, name: String): String {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(id) == null) {
            nm.createNotificationChannel(NotificationChannel(id, name, NotificationManager.IMPORTANCE_DEFAULT))
        }
        return id
    }

    private fun openApp(ctx: Context): PendingIntent = PendingIntent.getActivity(
        ctx, 0,
        Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    private fun action(ctx: Context, act: String, type: String, id: Long, title: String, text: String): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, Alarms.key(type, id) * 31 + act.hashCode(), Alarms.intent(ctx, type, id, title, text, act),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

    fun postItem(ctx: Context, type: String, id: Long, title: String, text: String, ongoing: Boolean, canDone: Boolean) {
        val channel = if (type == "timer") simpleChannel(ctx, CH_TIMER, "Timers") else reminderChannel(ctx)
        val b = NotificationCompat.Builder(ctx, channel)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(title).setContentText(text)
            .setContentIntent(openApp(ctx))
            .setAutoCancel(!ongoing).setOngoing(ongoing)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
        if (type != "timer") b.addAction(0, "Snooze 10 min", action(ctx, Alarms.ACTION_SNOOZE, type, id, title, text))
        if (canDone) b.addAction(0, "Done", action(ctx, Alarms.ACTION_DONE, type, id, title, text))
        notify(ctx, Alarms.key(type, id), b.build())
    }

    fun postFocus(ctx: Context, title: String, text: String) {
        val b = NotificationCompat.Builder(ctx, simpleChannel(ctx, CH_FOCUS, "Focus sessions"))
            .setSmallIcon(R.drawable.ic_notif).setContentTitle(title).setContentText(text)
            .setContentIntent(openApp(ctx)).setAutoCancel(true)
        notify(ctx, Alarms.key("focus", 0), b.build())
    }

    fun cancel(ctx: Context, type: String, id: Long) =
        ctx.getSystemService(NotificationManager::class.java).cancel(Alarms.key(type, id))

    private fun notify(ctx: Context, id: Int, n: android.app.Notification) {
        // Silently ignored if the user hasn't granted notification permission.
        try { ctx.getSystemService(NotificationManager::class.java).notify(id, n) } catch (_: SecurityException) { }
    }
}
