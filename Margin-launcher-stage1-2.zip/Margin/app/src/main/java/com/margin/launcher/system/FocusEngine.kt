package com.margin.launcher.system

import android.app.NotificationManager
import android.content.Context
import android.content.SharedPreferences
import com.margin.launcher.core.FocusSession
import com.margin.launcher.core.Ids
import com.margin.launcher.data.Graph
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class FocusState(
    val active: Boolean = false,
    val phase: Int = 0,               // 0 focus, 1 break
    val phaseEnd: Long = 0,
    val paused: Boolean = false,
    val pausedLeft: Long = 0,
    val focusMin: Int = 25,
    val breakMin: Int = 5,
    val subject: String = "",
    val taskTitle: String = "",
    val startedAt: Long = 0,
    val interruptions: Int = 0,
    val noise: Int = 0,
    val prevFilter: Int = -1,
    val stopwatch: Boolean = false,   // count-up session with no preset length
    val runStart: Long = 0,           // reference point for stopwatch elapsed time
)

/** Milliseconds to show: time left (timer) or elapsed (stopwatch). */
fun FocusState.displayMs(now: Long): Long = when {
    stopwatch -> if (paused) pausedLeft else (now - runStart).coerceAtLeast(0)
    paused -> pausedLeft
    else -> (phaseEnd - now).coerceAtLeast(0)
}

/**
 * The session lives in SharedPreferences plus an alarm, so it survives the app being killed.
 * Whichever of the UI ticker or the alarm notices a phase ending first advances the state.
 */
object FocusEngine {
    private lateinit var sp: SharedPreferences
    private val _state = MutableStateFlow(FocusState())
    val state: StateFlow<FocusState> = _state.asStateFlow()

    @Synchronized fun init(ctx: Context) {
        if (::sp.isInitialized) return
        sp = ctx.applicationContext.getSharedPreferences("focus", Context.MODE_PRIVATE)
        _state.value = FocusState(
            sp.getBoolean("active", false), sp.getInt("phase", 0), sp.getLong("phaseEnd", 0),
            sp.getBoolean("paused", false), sp.getLong("pausedLeft", 0), sp.getInt("focusMin", 25),
            sp.getInt("breakMin", 5), sp.getString("subject", "") ?: "", sp.getString("taskTitle", "") ?: "",
            sp.getLong("startedAt", 0), sp.getInt("interruptions", 0), sp.getInt("noise", 0), sp.getInt("prevFilter", -1),
            sp.getBoolean("stopwatch", false), sp.getLong("runStart", 0),
        )
    }

    private fun commit(s: FocusState) {
        _state.value = s
        sp.edit().putBoolean("active", s.active).putInt("phase", s.phase).putLong("phaseEnd", s.phaseEnd)
            .putBoolean("paused", s.paused).putLong("pausedLeft", s.pausedLeft).putInt("focusMin", s.focusMin)
            .putInt("breakMin", s.breakMin).putString("subject", s.subject).putString("taskTitle", s.taskTitle)
            .putLong("startedAt", s.startedAt).putInt("interruptions", s.interruptions).putInt("noise", s.noise)
            .putInt("prevFilter", s.prevFilter).putBoolean("stopwatch", s.stopwatch).putLong("runStart", s.runStart).apply()
    }

    @Synchronized fun start(ctx: Context, focusMin: Int, breakMin: Int, subject: String, taskTitle: String, noise: Int, dnd: Boolean, stopwatch: Boolean = false) {
        init(ctx)
        val now = System.currentTimeMillis()
        var prev = -1
        if (dnd) {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            if (nm.isNotificationPolicyAccessGranted) {
                prev = nm.currentInterruptionFilter
                nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
            }
        }
        val end = if (stopwatch) 0L else now + focusMin * 60_000L
        commit(FocusState(
            active = true, phase = 0, phaseEnd = end, paused = false, pausedLeft = 0, focusMin = focusMin,
            breakMin = breakMin, subject = subject, taskTitle = taskTitle, startedAt = now, interruptions = 0,
            noise = noise, prevFilter = prev, stopwatch = stopwatch, runStart = now,
        ))
        if (!stopwatch) Alarms.schedule(ctx, "focus", 0, end, "Focus complete", "Time for a break")
    }

    @Synchronized fun pause(ctx: Context) {
        val s = _state.value
        if (!s.active || s.paused) return
        Alarms.cancel(ctx, "focus", 0)
        commit(s.copy(paused = true, pausedLeft = s.displayMs(System.currentTimeMillis())))
    }

    @Synchronized fun resume(ctx: Context) {
        val s = _state.value
        if (!s.active || !s.paused) return
        val now = System.currentTimeMillis()
        val end = now + s.pausedLeft
        commit(s.copy(paused = false, phaseEnd = end, runStart = now - s.pausedLeft))
        if (!s.stopwatch) Alarms.schedule(ctx, "focus", 0, end, if (s.phase == 0) "Focus complete" else "Break over", "")
    }

    /** Ends the session now. Time already studied is saved (if at least a minute). */
    @Synchronized fun stop(ctx: Context) {
        val s = _state.value
        if (!s.active) return
        if (s.stopwatch) {
            val studied = (s.displayMs(System.currentTimeMillis()) / 60_000L).toInt()
            if (studied >= 1) record(ctx, s, studied, completed = true)
        } else if (s.phase == 0) {
            val left = if (s.paused) s.pausedLeft else s.phaseEnd - System.currentTimeMillis()
            val studied = ((s.focusMin * 60_000L - left) / 60_000L).toInt()
            if (studied >= 1) record(ctx, s, studied, completed = false)
        }
        finish(ctx, s, null)
    }

    @Synchronized fun noteInterruption() {
        val s = _state.value
        if (s.active) commit(s.copy(interruptions = s.interruptions + 1))
    }

    @Synchronized fun tick(ctx: Context) {
        init(ctx)
        val s = _state.value
        if (!s.active || s.paused || s.stopwatch) return
        val now = System.currentTimeMillis()
        if (now < s.phaseEnd) return
        if (s.phase == 0) {
            record(ctx, s, s.focusMin, completed = true)
            if (s.breakMin > 0) {
                val end = now + s.breakMin * 60_000L
                commit(s.copy(phase = 1, phaseEnd = end))
                Alarms.schedule(ctx, "focus", 0, end, "Break over", "")
                Notifs.postFocus(ctx, "Focus complete", "Take a ${s.breakMin}-minute break.")
            } else {
                finish(ctx, s, "Focus complete. Nice work.")
            }
        } else {
            finish(ctx, s, "Break over. Ready for another round?")
        }
    }

    private fun record(ctx: Context, s: FocusState, minutes: Int, completed: Boolean) {
        Graph.store(ctx).sessions.upsert(
            FocusSession(Ids.next(), s.startedAt, minutes, s.subject, completed, s.interruptions)
        )
    }

    private fun finish(ctx: Context, s: FocusState, message: String?) {
        Alarms.cancel(ctx, "focus", 0)
        if (s.prevFilter != -1) {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            if (nm.isNotificationPolicyAccessGranted) nm.setInterruptionFilter(s.prevFilter)
        }
        commit(FocusState(focusMin = maxOf(s.focusMin, 1), breakMin = s.breakMin))
        if (message != null) Notifs.postFocus(ctx, "Margin", message)
    }
}
