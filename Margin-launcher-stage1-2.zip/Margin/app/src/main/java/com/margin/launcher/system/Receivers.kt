package com.margin.launcher.system

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.margin.launcher.core.*
import com.margin.launcher.data.Graph

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        val type = i.getStringExtra(Alarms.X_TYPE) ?: return
        val id = i.getLongExtra(Alarms.X_ID, 0)
        val title = i.getStringExtra(Alarms.X_TITLE) ?: ""
        val text = i.getStringExtra(Alarms.X_TEXT) ?: ""
        val store = Graph.store(ctx)

        when (i.action) {
            Alarms.ACTION_SNOOZE -> {
                Notifs.cancel(ctx, type, id)
                Alarms.schedule(ctx, type, id, System.currentTimeMillis() + 10 * 60_000L, title, text)
            }
            Alarms.ACTION_DONE -> {
                Notifs.cancel(ctx, type, id)
                when (type) {
                    "reminder" -> store.reminders.get(id)?.let { store.saveReminder(it.copy(done = true)) }
                    "task" -> store.tasks.get(id)?.let { if (!it.done) store.toggleTask(it) }
                }
            }
            else -> fire(ctx, store, type, id, title, text)
        }
    }

    private fun fire(ctx: Context, store: com.margin.launcher.data.StudyStore, type: String, id: Long, title: String, text: String) {
        when (type) {
            "focus" -> { FocusEngine.init(ctx); FocusEngine.tick(ctx) }
            "reminder" -> {
                val r = store.reminders.get(id) ?: return          // deleted since it was scheduled
                if (r.done) return
                Notifs.postItem(ctx, type, id, r.title, text, ongoing = r.persistent, canDone = true)
                if (r.repeat != Repeat.NONE) {
                    store.saveReminder(r.copy(time = TimeUtil.nextAfter(r.time, r.repeat, System.currentTimeMillis())))
                }
            }
            "task" -> {
                val t = store.tasks.get(id) ?: return
                if (t.done) return
                Notifs.postItem(ctx, type, id, title, t.title, ongoing = false, canDone = true)
            }
            "event" -> {
                if (store.events.get(id) == null) return
                Notifs.postItem(ctx, type, id, title, text, ongoing = false, canDone = false)
            }
            else -> Notifs.postItem(ctx, type, id, title, text, ongoing = false, canDone = false)
        }
    }
}

/** Alarms are cleared on reboot or app update, so schedule everything again. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        Scheduling.rescheduleAll(ctx, Graph.store(ctx))
        FocusEngine.init(ctx)
        FocusEngine.tick(ctx)
    }
}
