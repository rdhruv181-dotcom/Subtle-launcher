package com.margin.launcher.ui.components

import android.Manifest
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.text.format.DateFormat
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import com.margin.launcher.core.Ids
import com.margin.launcher.core.Subject
import com.margin.launcher.data.AppInfo
import com.margin.launcher.data.AppRepository
import com.margin.launcher.data.StudyStore
import com.margin.launcher.ui.theme.M
import java.time.LocalDate
import java.time.format.DateTimeFormatter

val DAY_FMT: DateTimeFormatter = DateTimeFormatter.ofPattern("EEE d MMM")
val MONTH_FMT: DateTimeFormatter = DateTimeFormatter.ofPattern("MMMM yyyy")

/** Full-screen page with a back arrow and title. Content sits in a Column. */
@Composable
fun Page(
    title: String,
    onBack: () -> Unit,
    action: (@Composable () -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    val c = M.colors
    Column(
        Modifier.fillMaxSize().background(c.bg)
            .pointerInput(Unit) { detectTapGestures { } }
            .systemBarsPadding().imePadding()
    ) {
        Row(
            Modifier.fillMaxWidth().padding(start = 8.dp, end = 16.dp, top = 8.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier.size(48.dp).clip(CircleShape)
                    .semantics { contentDescription = "Back" }
                    .clickable(role = Role.Button, onClick = onBack),
                contentAlignment = Alignment.Center,
            ) { Text("‹", fontSize = 30.sp, color = c.text) }
            Text(
                title, fontSize = 26.sp, fontWeight = FontWeight.Light,
                modifier = Modifier.weight(1f).semantics { heading() },
            )
            action?.invoke()
        }
        content()
    }
}

@Composable
fun Label(text: String, modifier: Modifier = Modifier) {
    Text(
        text.uppercase(), fontSize = 12.sp, fontWeight = FontWeight.Medium, letterSpacing = 1.sp,
        color = M.colors.secondary, modifier = modifier.padding(top = 6.dp),
    )
}

@Composable
fun Chip(label: String, selected: Boolean, onClick: () -> Unit) {
    val c = M.colors
    Box(
        Modifier.defaultMinSize(minHeight = 40.dp).clip(RoundedCornerShape(10.dp))
            .background(if (selected) c.accent else c.surface)
            .clickable(role = Role.Button, onClick = onClick).padding(horizontal = 14.dp),
        contentAlignment = Alignment.Center,
    ) { Text(label, fontSize = 14.sp, color = if (selected) c.onAccent else c.text) }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun Chips(content: @Composable FlowRowScope.() -> Unit) {
    FlowRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        content = content,
    )
}

@Composable
fun Field(
    value: String,
    onChange: (String) -> Unit,
    hint: String,
    modifier: Modifier = Modifier,
    singleLine: Boolean = true,
    minLines: Int = 1,
    imeAction: ImeAction = ImeAction.Default,
    keyboardType: KeyboardType = KeyboardType.Text,
    focusRequester: FocusRequester? = null,
    onDone: (() -> Unit)? = null,
) {
    val c = M.colors
    val act = { onDone?.invoke(); Unit }
    BasicTextField(
        value = value, onValueChange = onChange,
        singleLine = singleLine, minLines = minLines,
        textStyle = TextStyle(fontSize = 17.sp, color = c.text),
        cursorBrush = SolidColor(c.accent),
        keyboardOptions = KeyboardOptions(imeAction = imeAction, keyboardType = keyboardType),
        keyboardActions = KeyboardActions(onDone = { act() }, onGo = { act() }, onSearch = { act() }, onSend = { act() }),
        modifier = modifier.fillMaxWidth().then(if (focusRequester != null) Modifier.focusRequester(focusRequester) else Modifier),
        decorationBox = { inner ->
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(c.surface)
                    .padding(horizontal = 14.dp, vertical = 13.dp)
            ) {
                if (value.isEmpty()) Text(hint, fontSize = 17.sp, color = c.secondary)
                inner()
            }
        },
    )
}

@Composable
fun Btn(label: String, onClick: () -> Unit, modifier: Modifier = Modifier, primary: Boolean = true, danger: Boolean = false) {
    val c = M.colors
    val bg = if (primary) c.accent else c.surface
    val fg = when { primary -> c.onAccent; danger -> c.alert; else -> c.text }
    Box(
        modifier.defaultMinSize(minHeight = 48.dp).clip(RoundedCornerShape(12.dp)).background(bg)
            .clickable(role = Role.Button, onClick = onClick).padding(horizontal = 18.dp),
        contentAlignment = Alignment.Center,
    ) { Text(label, fontSize = 16.sp, fontWeight = FontWeight.Medium, color = fg) }
}

@Composable
fun CheckCircle(checked: Boolean, onToggle: () -> Unit, label: String) {
    val c = M.colors
    val fill by animateColorAsState(if (checked) c.accent else Color.Transparent, label = "fill")
    val scale by animateFloatAsState(if (checked) 1f else 0.9f, label = "scale")
    Box(
        Modifier.size(48.dp).semantics { contentDescription = label }
            .toggleable(value = checked, role = Role.Checkbox, onValueChange = { onToggle() }),
        contentAlignment = Alignment.Center,
    ) {
        Box(
            Modifier.size(24.dp).scale(scale).clip(CircleShape).background(fill)
                .border(1.5.dp, if (checked) c.accent else c.secondary, CircleShape),
            contentAlignment = Alignment.Center,
        ) { if (checked) Text("✓", fontSize = 14.sp, color = c.onAccent) }
    }
}

@Composable
fun <T> Segmented(options: List<Pair<T, String>>, selected: T, onSelect: (T) -> Unit) {
    val c = M.colors
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(c.surface).padding(3.dp)) {
        options.forEach { (value, label) ->
            val sel = value == selected
            Box(
                Modifier.weight(1f).defaultMinSize(minHeight = 40.dp).clip(RoundedCornerShape(10.dp))
                    .background(if (sel) c.bg else Color.Transparent)
                    .clickable(role = Role.RadioButton) { onSelect(value) },
                contentAlignment = Alignment.Center,
            ) {
                Text(label, fontSize = 14.sp, fontWeight = if (sel) FontWeight.Medium else FontWeight.Normal,
                    color = if (sel) c.text else c.secondary)
            }
        }
    }
}

@Composable
fun ToggleRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val c = M.colors
    Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontSize = 16.sp, modifier = Modifier.weight(1f))
        Switch(
            checked = checked, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedTrackColor = c.accent, checkedThumbColor = c.onAccent,
                uncheckedTrackColor = c.surface, uncheckedThumbColor = c.secondary,
                uncheckedBorderColor = c.hairline,
            ),
        )
    }
}

@Composable
fun LinkRow(label: String, detail: String = "", onClick: () -> Unit) {
    val c = M.colors
    Row(
        Modifier.fillMaxWidth().clickable(role = Role.Button, onClick = onClick).padding(vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, fontSize = 16.sp, color = c.accent, modifier = Modifier.weight(1f))
        if (detail.isNotEmpty()) Text(detail, fontSize = 14.sp, color = c.secondary)
    }
}

/** A centred card over a dimmed screen, for quick editors and confirmations. */
@Composable
fun Sheet(onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier.fillMaxWidth().padding(16.dp).clip(RoundedCornerShape(20.dp)).background(M.colors.bg)
                .verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            content = content,
        )
    }
}

@Composable
fun ProgressBar(fraction: Float, modifier: Modifier = Modifier, color: Color = M.colors.accent) {
    Box(modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)).background(M.colors.surface)) {
        Box(Modifier.fillMaxWidth(fraction.coerceIn(0f, 1f)).fillMaxHeight().clip(RoundedCornerShape(3.dp)).background(color))
    }
}

/** Subject chips with an inline "+ New". Subjects are shared by tasks, notes, planner, focus and study. */
@Composable
fun SubjectPicker(store: StudyStore, selected: String, onSelect: (String) -> Unit, allowNone: Boolean = true) {
    val subjects by store.subjects.items.collectAsState()
    var adding by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }
    Chips {
        if (allowNone) Chip("None", selected.isEmpty()) { onSelect("") }
        subjects.forEach { s -> Chip(s.name, selected == s.name) { onSelect(s.name) } }
        Chip("+ New", false) { adding = true }
    }
    if (adding) {
        val add = {
            val n = newName.trim()
            if (n.isNotEmpty()) {
                if (subjects.none { it.name.equals(n, ignoreCase = true) }) store.subjects.upsert(Subject(Ids.next(), n))
                onSelect(n); newName = ""; adding = false
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Field(newName, { newName = it }, "New subject", Modifier.weight(1f), imeAction = ImeAction.Done, onDone = { add() })
            Btn("Add", { add() })
        }
    }
}

/** Checklist of apps, used to pick distracting apps for Focus mode. */
@Composable
fun AppPickerDialog(
    apps: List<AppInfo>, repo: AppRepository, selected: Set<String>, mono: Boolean,
    onToggle: (String) -> Unit, onClose: () -> Unit,
) {
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.fillMaxSize().padding(16.dp).clip(RoundedCornerShape(20.dp)).background(M.colors.bg).padding(16.dp)) {
            Text("Distracting apps", fontSize = 20.sp, fontWeight = FontWeight.Medium)
            Text("Margin will ask before opening these during a focus session.", fontSize = 14.sp,
                color = M.colors.secondary, modifier = Modifier.padding(vertical = 6.dp))
            LazyColumn(Modifier.weight(1f)) {
                items(apps, key = { it.key }) { app ->
                    Row(
                        Modifier.fillMaxWidth().toggleable(app.key in selected, role = Role.Checkbox) { onToggle(app.key) }
                            .padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        AppIcon(app, repo, 34.dp, mono)
                        Text(app.label, fontSize = 16.sp, modifier = Modifier.weight(1f).padding(start = 14.dp))
                        if (app.key in selected) Text("✓", color = M.colors.accent, fontSize = 18.sp)
                    }
                }
            }
            Btn("Done", onClose, Modifier.fillMaxWidth().padding(top = 8.dp))
        }
    }
}

fun pickDate(ctx: Context, initial: LocalDate, onPicked: (LocalDate) -> Unit) {
    DatePickerDialog(ctx, { _, y, m, d -> onPicked(LocalDate.of(y, m + 1, d)) },
        initial.year, initial.monthValue - 1, initial.dayOfMonth).show()
}

fun pickTime(ctx: Context, hour: Int, minute: Int, onPicked: (Int, Int) -> Unit) {
    TimePickerDialog(ctx, { _, h, m -> onPicked(h, m) }, hour, minute, DateFormat.is24HourFormat(ctx)).show()
}

/** Returns a function that asks for notification permission (Android 13+) if it hasn't been granted. */
@Composable
fun rememberNotifPermission(): () -> Unit {
    val ctx = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    return remember {
        {
            if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) launcher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
}
