package com.margin.launcher.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast

object SystemActions {
    /**
     * Pulls down the notification shade. Uses a non-SDK method guarded by the EXPAND_STATUS_BAR
     * permission; it works on most devices but Android doesn't guarantee it, so failure is silent.
     */
    fun expandShade(ctx: Context) {
        runCatching {
            val sbm = ctx.getSystemService("statusbar")
            Class.forName("android.app.StatusBarManager").getMethod("expandNotificationsPanel").invoke(sbm)
        }
    }

    fun openCalendar(ctx: Context) {
        val i = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALENDAR)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { ctx.startActivity(i) }
            .onFailure { Toast.makeText(ctx, "No calendar app found", Toast.LENGTH_SHORT).show() }
    }

    fun appInfo(ctx: Context, pkg: String) {
        val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { ctx.startActivity(i) }
    }

    fun uninstall(ctx: Context, pkg: String) {
        val i = Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { ctx.startActivity(i) }
            .onFailure { Toast.makeText(ctx, "This app can't be uninstalled", Toast.LENGTH_SHORT).show() }
    }

    fun defaultLauncherSettings(ctx: Context) {
        val i = Intent(Settings.ACTION_HOME_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { ctx.startActivity(i) }
    }
}
