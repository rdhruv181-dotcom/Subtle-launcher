package com.margin.launcher.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.margin.launcher.LauncherViewModel
import com.margin.launcher.UiState
import com.margin.launcher.core.*
import com.margin.launcher.ui.components.*
import com.margin.launcher.ui.theme.M
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.TextStyle as DowStyle
import java.util.Locale

private data class AgItem(val sort: Int, val label: String, val title: String, val sub: String, val event: Event? = null, val alert: Boolean = false)

private fun agendaFor(
    date: LocalDate, classes: List<ClassEntry>, events: List<Event>, tasks: List<Task>, sessions: List<FocusSession>,
): List<AgItem> {
    val out = mutableListOf<AgItem>()
    classes.filter { it.dow == date.dayOfWeek.value }.forEach {
        out += AgItem(it.startMin, "${fmtMin(it.startMin)}–${fmtMin(it.endMin)}", it.subject, if (it.room.isNotEmpty()) "Class · ${it.room}" else "Class")
    }
    events.filter { date.toEpochDay() in it.day..it.endDay }.forEach {
        val kind = when (it.kind) { 1 -> "Exam"; 2 -> "Holiday"; else -> "Event" }
        out += AgItem(if (it.startMin >= 0) it.startMin else -1, if (it.startMin >= 0) fmtMin(it.startMin) else "All day",
            it.title, listOf(kind, it.subject.ifEmpty { null }).filterNotNull().joinToString(" · "), it, it.kind == 1)
    }
    tasks.filter { !it.done && it.due != null && TimeUtil.toDate(it.due) == date }.forEach {
        out += AgItem(if (it.hasTime) { val t = TimeUtil.toTime(it.due!!); t.hour * 60 + t.minute } else 1439,
            if (it.hasTime) fmtMin(TimeUtil.toTime(it.due!!).let { t -> t.hour * 60 + t.minute }) else "Due",
            it.title, "Task · ${it.category}", alert = it.category == "Assignment" || it.category == "Exams")
    }
    val studied = sessions.filter { TimeUtil.toDate(it.start) == date }.sumOf { it.minutes }
    if (studied > 0) out += AgItem(2000, "Study", "Focused for ${fmtDuration(studied)}", "From Focus mode")
    return out.sortedBy { it.sort }
}

@Composable
fun PlannerScreen(vm: LauncherViewModel, state: UiState, onBack: () -> Unit) {
    val store = vm.store
    val c = M.colors
    val ctx = LocalContext.current
    val classes by store.classes.items.collectAsState()
    val events by store.events.items.collectAsState()
    val tasks by store.tasks.items.collectAsState()
    val sessions by store.sessions.items.collectAsState()
    val today = LocalDate.now()
    var mode by remember { mutableIntStateOf(0) }       // 0 month, 1 week, 2 day, 3 timetable
    var selected by remember { mutableStateOf(today) }
    var eventDialog by remember { mutableStateOf<Event?>(null) }
    var classDialog by remember { mutableStateOf<ClassEntry?>(null) }
    val askNotif = rememberNotifPermission()

    fun marks(d: LocalDate): Int {
        val ev = events.filter { d.toEpochDay() in it.day..it.endDay }
        return when {
            ev.any { it.kind == 1 } -> 2
            ev.isNotEmpty() || tasks.any { !it.done && it.due != null && TimeUtil.toDate(it.due) == d } -> 1
            else -> 0
        }
    }

    // Countdowns: next exams and nearest assignment deadlines.
    val countdowns = (events.filter { it.kind == 1 && it.endDay >= today.toEpochDay() }.map { it.title to LocalDate.ofEpochDay(maxOf(it.day, today.toEpochDay())) } +
        tasks.filter { !it.done && it.category == "Assignment" && it.due != null && !TimeUtil.toDate(it.due).isBefore(today) }.map { it.title to TimeUtil.toDate(it.due!!) })
        .sortedBy { it.second }.take(3)

    Page("Planner", onBack, action = {
        Btn("+ Event", {
            eventDialog = Event(Ids.next(), "", selected.toEpochDay())
        }, primary = false)
    }) {
        Column(Modifier.padding(horizontal = 24.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (countdowns.isNotEmpty()) {
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(c.surface).padding(14.dp)) {
                    countdowns.forEach { (name, d) ->
                        val days = d.toEpochDay() - today.toEpochDay()
                        Row(Modifier.padding(vertical = 2.dp)) {
                            Text(name, fontSize = 15.sp, modifier = Modifier.weight(1f))
                            Text(when (days) { 0L -> "Today"; 1L -> "Tomorrow"; else -> "$days days" }, fontSize = 15.sp,
                                color = if (days <= 3) c.alert else c.secondary, fontWeight = FontWeight.Medium)
                        }
                    }
                }
            }
            Segmented(listOf(0 to "Month", 1 to "Week", 2 to "Day", 3 to "Timetable"), mode) { mode = it }
        }

        if (mode == 3) {
            Timetable(classes, onAdd = { dow -> classDialog = ClassEntry(Ids.next(), "", dow, 9 * 60, 10 * 60) }, onEdit = { classDialog = it })
        } else {
            val step: (Int) -> Unit = { dir ->
                selected = when (mode) {
                    0 -> selected.plusMonths(dir.toLong())
                    1 -> selected.plusWeeks(dir.toLong())
                    else -> selected.plusDays(dir.toLong())
                }
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("‹", fontSize = 28.sp, modifier = Modifier.clickable { step(-1) }.padding(horizontal = 14.dp, vertical = 6.dp))
                Text(
                    when (mode) { 0 -> selected.format(MONTH_FMT); 1 -> "Week of " + selected.with(DayOfWeek.MONDAY).format(DAY_FMT); else -> selected.format(DAY_FMT) },
                    fontSize = 17.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center, modifier = Modifier.weight(1f),
                )
                Text("›", fontSize = 28.sp, modifier = Modifier.clickable { step(1) }.padding(horizontal = 14.dp, vertical = 6.dp))
            }

            LazyColumn(Modifier.weight(1f).padding(horizontal = 24.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
                if (mode == 0) item {
                    MonthGrid(YearMonth.from(selected), selected, today, { marks(it) }) { selected = it }
                }
                val days = if (mode == 1) (0..6).map { selected.with(DayOfWeek.MONDAY).plusDays(it.toLong()) } else listOf(selected)
                days.forEach { d ->
                    val items = agendaFor(d, classes, events, tasks, sessions)
                    item(key = "day" + d.toEpochDay()) {
                        Column(Modifier.fillMaxWidth().padding(top = 16.dp)) {
                            if (mode != 2) Label(d.format(DAY_FMT) + if (d == today) " · today" else "")
                            if (items.isEmpty()) Text("Nothing planned.", fontSize = 14.sp, color = c.secondary, modifier = Modifier.padding(vertical = 8.dp))
                            items.forEach { a ->
                                Row(Modifier.fillMaxWidth().then(if (a.event != null) Modifier.clickable { eventDialog = a.event } else Modifier).padding(vertical = 8.dp)) {
                                    Text(a.label, fontSize = 13.sp, color = c.secondary, modifier = Modifier.width(92.dp).padding(top = 3.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(a.title, fontSize = 16.sp, color = if (a.alert) c.alert else c.text)
                                        if (a.sub.isNotEmpty()) Text(a.sub, fontSize = 13.sp, color = c.secondary)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    eventDialog?.let { ev -> EventDialog(ev, vm, askNotif) { eventDialog = null } }
    classDialog?.let { cl -> ClassDialog(cl, vm) { classDialog = null } }
}

@Composable
private fun MonthGrid(ym: YearMonth, selected: LocalDate, today: LocalDate, marks: (LocalDate) -> Int, onPick: (LocalDate) -> Unit) {
    val c = M.colors
    val first = ym.atDay(1)
    val offset = first.dayOfWeek.value - 1
    val rows = (offset + ym.lengthOfMonth() + 6) / 7
    Column(Modifier.padding(top = 8.dp)) {
        Row(Modifier.fillMaxWidth()) {
            (1..7).forEach { i ->
                Text(DayOfWeek.of(i).getDisplayName(DowStyle.NARROW, Locale.getDefault()), fontSize = 12.sp, color = c.secondary,
                    textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
            }
        }
        for (r in 0 until rows) {
            Row(Modifier.fillMaxWidth()) {
                for (col in 0..6) {
                    val dayNum = r * 7 + col - offset + 1
                    if (dayNum < 1 || dayNum > ym.lengthOfMonth()) {
                        Spacer(Modifier.weight(1f).height(48.dp))
                    } else {
                        val d = ym.atDay(dayNum)
                        val m = marks(d)
                        Column(
                            Modifier.weight(1f).height(48.dp).padding(2.dp).clip(RoundedCornerShape(10.dp))
                                .background(if (d == selected) c.surface else androidx.compose.ui.graphics.Color.Transparent)
                                .then(if (d == today) Modifier.border(1.dp, c.accent, RoundedCornerShape(10.dp)) else Modifier)
                                .clickable { onPick(d) },
                            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center,
                        ) {
                            Text("$dayNum", fontSize = 15.sp, color = if (d == today) c.accent else c.text)
                            Box(Modifier.padding(top = 3.dp).size(5.dp).clip(CircleShape)
                                .background(when (m) { 2 -> c.alert; 1 -> c.accent; else -> androidx.compose.ui.graphics.Color.Transparent }))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ColumnScope.Timetable(classes: List<ClassEntry>, onAdd: (Int) -> Unit, onEdit: (ClassEntry) -> Unit) {
    val c = M.colors
    LazyColumn(Modifier.weight(1f).padding(horizontal = 24.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
        for (dow in 1..7) {
            item(key = "dow$dow") {
                Column(Modifier.fillMaxWidth().padding(top = 16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Label(DayOfWeek.of(dow).getDisplayName(DowStyle.FULL, Locale.getDefault()), Modifier.weight(1f))
                        Text("+ Add", fontSize = 14.sp, color = c.accent, modifier = Modifier.clickable { onAdd(dow) }.padding(8.dp))
                    }
                    val list = classes.filter { it.dow == dow }.sortedBy { it.startMin }
                    if (list.isEmpty()) Text("No classes.", fontSize = 14.sp, color = c.secondary)
                    list.forEach { k ->
                        Row(Modifier.fillMaxWidth().clickable { onEdit(k) }.padding(vertical = 8.dp)) {
                            Text("${fmtMin(k.startMin)}–${fmtMin(k.endMin)}", fontSize = 13.sp, color = c.secondary, modifier = Modifier.width(92.dp).padding(top = 3.dp))
                            Column {
                                Text(k.subject, fontSize = 16.sp)
                                if (k.room.isNotEmpty()) Text(k.room, fontSize = 13.sp, color = c.secondary)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EventDialog(original: Event, vm: LauncherViewModel, askNotif: () -> Unit, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val store = vm.store
    var title by remember { mutableStateOf(original.title) }
    var kind by remember { mutableIntStateOf(original.kind) }
    var day by remember { mutableLongStateOf(original.day) }
    var endDay by remember { mutableLongStateOf(original.endDay) }
    var startMin by remember { mutableIntStateOf(original.startMin) }
    var subject by remember { mutableStateOf(original.subject) }
    var remind by remember { mutableIntStateOf(original.remindBefore) }
    val isNew = store.events.get(original.id) == null

    Sheet(onClose) {
        Text(if (isNew) "New event" else "Edit event", fontSize = 20.sp, fontWeight = FontWeight.Medium)
        Field(title, { title = it }, "Title")
        Segmented(listOf(0 to "Event", 1 to "Exam", 2 to "Holiday"), kind) { kind = it }
        Label("Date")
        Chips {
            Chip(LocalDate.ofEpochDay(day).format(DAY_FMT), true) {
                pickDate(ctx, LocalDate.ofEpochDay(day)) { d -> day = d.toEpochDay(); if (endDay < day) endDay = day }
            }
            Chip(if (endDay > day) "Until " + LocalDate.ofEpochDay(endDay).format(DAY_FMT) else "Add end date", endDay > day) {
                pickDate(ctx, LocalDate.ofEpochDay(maxOf(day, endDay))) { d -> endDay = maxOf(d.toEpochDay(), day) }
            }
            Chip(if (startMin >= 0) fmtMin(startMin) else "All day", startMin >= 0) {
                val cur = if (startMin >= 0) startMin else 9 * 60
                pickTime(ctx, cur / 60, cur % 60) { h, m -> startMin = h * 60 + m }
            }
            if (startMin >= 0) Chip("Clear time", false) { startMin = -1 }
        }
        if (kind != 2) {
            Label("Subject")
            SubjectPicker(store, subject) { subject = it }
            Label("Remind me")
            Segmented(listOf(-1 to "Off", 60 to "1 hour", 1440 to "1 day", 10080 to "1 week"), remind) { remind = it }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Btn("Save", {
                if (title.isNotBlank()) {
                    if (remind >= 0) askNotif()
                    store.saveEvent(original.copy(title = title.trim(), kind = kind, day = day, endDay = maxOf(day, endDay),
                        startMin = startMin, subject = subject, remindBefore = if (kind == 2) -1 else remind))
                    onClose()
                }
            }, Modifier.weight(1f))
            if (!isNew) Btn("Delete", { store.deleteEvent(original.id); onClose() }, primary = false, danger = true)
        }
    }
}

@Composable
private fun ClassDialog(original: ClassEntry, vm: LauncherViewModel, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val store = vm.store
    var subject by remember { mutableStateOf(original.subject) }
    var dow by remember { mutableIntStateOf(original.dow) }
    var start by remember { mutableIntStateOf(original.startMin) }
    var end by remember { mutableIntStateOf(original.endMin) }
    var room by remember { mutableStateOf(original.room) }
    val isNew = store.classes.get(original.id) == null

    Sheet(onClose) {
        Text(if (isNew) "New class" else "Edit class", fontSize = 20.sp, fontWeight = FontWeight.Medium)
        Label("Subject")
        SubjectPicker(store, subject, { subject = it }, allowNone = false)
        Label("Day")
        Chips { (1..7).forEach { i -> Chip(DayOfWeek.of(i).getDisplayName(DowStyle.SHORT, Locale.getDefault()), dow == i) { dow = i } } }
        Label("Time")
        Chips {
            Chip("From " + fmtMin(start), true) { pickTime(ctx, start / 60, start % 60) { h, m -> start = h * 60 + m; if (end <= start) end = minOf(start + 60, 1439) } }
            Chip("To " + fmtMin(end), true) { pickTime(ctx, end / 60, end % 60) { h, m -> end = h * 60 + m } }
        }
        Field(room, { room = it }, "Room (optional)")
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Btn("Save", {
                if (subject.isNotBlank() && end > start) {
                    store.classes.upsert(original.copy(subject = subject, dow = dow, startMin = start, endMin = end, room = room.trim()))
                    onClose()
                } else vm.toast("Pick a subject and make sure the class ends after it starts")
            }, Modifier.weight(1f))
            if (!isNew) Btn("Delete", { store.classes.remove(original.id); onClose() }, primary = false, danger = true)
        }
    }
}
