package com.margin.launcher.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.margin.launcher.LauncherViewModel
import com.margin.launcher.UiState
import com.margin.launcher.core.*
import com.margin.launcher.ui.components.*
import com.margin.launcher.ui.theme.IOS
import com.margin.launcher.ui.theme.M
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.TextStyle as DowStyle
import java.util.Locale

private data class AgItem(val sort: Int, val label: String, val title: String, val sub: String, val color: Color, val event: Event? = null)

private fun agendaFor(date: LocalDate, events: List<Event>, tasks: List<Task>, sessions: List<FocusSession>): List<AgItem> {
    val out = mutableListOf<AgItem>()
    events.filter { date.toEpochDay() in it.day..it.endDay }.forEach {
        val kind = when (it.kind) { 1 -> "Exam"; 2 -> "Holiday"; else -> "Event" }
        val color = when (it.kind) { 1 -> IOS.Red; 2 -> IOS.Green; else -> IOS.Blue }
        out += AgItem(if (it.startMin >= 0) it.startMin else -1, if (it.startMin >= 0) fmtMin(it.startMin) else "all-day",
            it.title, listOf(kind, it.subject.ifEmpty { null }).filterNotNull().joinToString(" · "), color, it)
    }
    tasks.filter { !it.done && it.due != null && TimeUtil.toDate(it.due) == date }.forEach {
        val minutes = it.due?.let { d -> TimeUtil.toTime(d).let { t -> t.hour * 60 + t.minute } } ?: 1439
        out += AgItem(if (it.hasTime) minutes else 1439, if (it.hasTime) fmtMin(minutes) else "due", it.title, "Task · " + it.category, IOS.Orange)
    }
    val studied = sessions.filter { TimeUtil.toDate(it.start) == date }.sumOf { it.minutes }
    if (studied > 0) out += AgItem(2000, "study", "Focused for " + fmtDuration(studied), "From Focus", IOS.Purple)
    return out.sortedBy { it.sort }
}

/** Laid out like Apple Calendar: red month title, month grid, day agenda, floating tab bar. */
@Composable
fun PlannerScreen(vm: LauncherViewModel, state: UiState, onBack: () -> Unit) {
    val store = vm.store
    val c = M.colors
    val events by store.events.items.collectAsState()
    val tasks by store.tasks.items.collectAsState()
    val sessions by store.sessions.items.collectAsState()
    val today = LocalDate.now()
    var mode by remember { mutableIntStateOf(0) }       // 0 month, 1 week, 2 day
    var selected by remember { mutableStateOf(today) }
    var eventDialog by remember { mutableStateOf<Event?>(null) }
    val askNotif = rememberNotifPermission()

    fun marks(d: LocalDate): Int {
        val ev = events.filter { d.toEpochDay() in it.day..it.endDay }
        return when {
            ev.any { it.kind == 1 } -> 2
            ev.isNotEmpty() || tasks.any { !it.done && it.due != null && TimeUtil.toDate(it.due) == d } -> 1
            else -> 0
        }
    }

    // Exams and assignment deadlines coming up.
    val countdowns = (events.filter { it.kind == 1 && it.endDay >= today.toEpochDay() }.map { it.title to LocalDate.ofEpochDay(maxOf(it.day, today.toEpochDay())) } +
        tasks.filter { !it.done && it.category == "Assignment" && it.due != null && !TimeUtil.toDate(it.due).isBefore(today) }.map { it.title to TimeUtil.toDate(it.due!!) })
        .sortedBy { it.second }.take(4)

    val title = when (mode) {
        0 -> selected.month.getDisplayName(DowStyle.FULL, Locale.getDefault()) + " " + selected.year
        1 -> "Week of " + selected.with(DayOfWeek.MONDAY).format(DAY_FMT)
        else -> selected.format(DAY_FMT)
    }
    val step: (Int) -> Unit = { dir ->
        selected = when (mode) {
            0 -> selected.plusMonths(dir.toLong())
            1 -> selected.plusWeeks(dir.toLong())
            else -> selected.plusDays(dir.toLong())
        }
    }

    Page(title, onBack, titleColor = IOS.Red, action = {
        Chip("Today", selected == today) { selected = today }
        Spacer(Modifier.width(8.dp))
        GlassIconButton(GIcon.PLUS, "New event", { eventDialog = Event(Ids.next(), "", selected.toEpochDay()) }, size = 40.dp)
    }) {
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 16.dp)) {
            item {
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
                    GlassIconButton(GIcon.BACK, "Previous", { step(-1) }, size = 36.dp)
                    Spacer(Modifier.width(8.dp))
                    GlassIconButton(GIcon.CHEVRON_RIGHT, "Next", { step(1) }, size = 36.dp)
                }
            }
            if (mode == 0) item { MonthGrid(YearMonth.from(selected), selected, today, { marks(it) }) { selected = it } }
            val days = if (mode == 1) (0..6).map { selected.with(DayOfWeek.MONDAY).plusDays(it.toLong()) } else listOf(selected)
            days.forEach { d ->
                val list = agendaFor(d, events, tasks, sessions)
                item(key = "day" + d.toEpochDay()) {
                    Column(Modifier.fillMaxWidth()) {
                        GroupHeader(d.format(DAY_FMT) + if (d == today) " · Today" else "")
                        InsetGroup {
                            if (list.isEmpty()) Text("No events", fontSize = 16.sp, color = c.secondary, modifier = Modifier.padding(16.dp))
                            list.forEachIndexed { i, a ->
                                if (i > 0) RowDivider(34.dp)
                                Row(
                                    Modifier.fillMaxWidth().then(if (a.event != null) Modifier.clickable { eventDialog = a.event } else Modifier)
                                        .padding(horizontal = 16.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Box(Modifier.width(4.dp).height(38.dp).clip(RoundedCornerShape(2.dp)).background(a.color))
                                    Spacer(Modifier.width(12.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(a.title, fontSize = 17.sp, fontWeight = FontWeight.Medium, maxLines = 1)
                                        if (a.sub.isNotEmpty()) Text(a.sub, fontSize = 13.sp, color = c.secondary, maxLines = 1)
                                    }
                                    Text(a.label, fontSize = 15.sp, color = c.secondary)
                                }
                            }
                        }
                    }
                }
            }
            if (countdowns.isNotEmpty()) item {
                Column(Modifier.fillMaxWidth()) {
                    GroupHeader("Exams and deadlines")
                    InsetGroup {
                        countdowns.forEachIndexed { i, (name, d) ->
                            if (i > 0) RowDivider()
                            val days = d.toEpochDay() - today.toEpochDay()
                            ListRow(name, value = when (days) { 0L -> "Today"; 1L -> "Tomorrow"; else -> "$days days" }, chevron = false)
                        }
                    }
                }
            }
        }

        GlassTabBar(
            listOf(Triple(0, GIcon.CALENDAR, "Month"), Triple(1, GIcon.LIST, "Week"), Triple(2, GIcon.NOTE, "Day")),
            mode, { mode = it }, Modifier.padding(horizontal = 40.dp, vertical = 10.dp),
        )
    }

    eventDialog?.let { ev -> EventDialog(ev, vm, askNotif) { eventDialog = null } }
}

@Composable
private fun MonthGrid(ym: YearMonth, selected: LocalDate, today: LocalDate, marks: (LocalDate) -> Int, onPick: (LocalDate) -> Unit) {
    val c = M.colors
    val offset = ym.atDay(1).dayOfWeek.value - 1
    val rows = (offset + ym.lengthOfMonth() + 6) / 7
    Column(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
        Row(Modifier.fillMaxWidth()) {
            (1..7).forEach { i ->
                Text(DayOfWeek.of(i).getDisplayName(DowStyle.NARROW, Locale.getDefault()), fontSize = 12.sp, fontWeight = FontWeight.Medium,
                    color = c.secondary, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
            }
        }
        for (r in 0 until rows) {
            Row(Modifier.fillMaxWidth()) {
                for (col in 0..6) {
                    val dayNum = r * 7 + col - offset + 1
                    if (dayNum < 1 || dayNum > ym.lengthOfMonth()) {
                        Spacer(Modifier.weight(1f).height(52.dp))
                    } else {
                        val d = ym.atDay(dayNum)
                        val isToday = d == today
                        val isSel = d == selected
                        Column(
                            Modifier.weight(1f).height(52.dp).clickable { onPick(d) },
                            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center,
                        ) {
                            Box(
                                Modifier.size(34.dp).clip(CircleShape)
                                    .background(when { isToday -> IOS.Red; isSel -> c.text.copy(alpha = 0.18f); else -> Color.Transparent }),
                                contentAlignment = Alignment.Center,
                            ) {
                                Text("$dayNum", fontSize = 18.sp, fontWeight = if (isToday) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isToday) Color.White else c.text)
                            }
                            Box(Modifier.padding(top = 2.dp).size(5.dp).clip(CircleShape)
                                .background(when (marks(d)) { 2 -> IOS.Red; 1 -> c.secondary; else -> Color.Transparent }))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EventDialog(original: Event, vm: LauncherViewModel, askNotif: () -> Unit, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val store = vm.store
    var title by remember { mutableStateOf(original.title) }
    var kind by remember { mutableIntStateOf(original.kind) }
    var day by remember { mutableLongStateOf(original.day) }
    var endDay by remember { mutableLongStateOf(original.endDay) }
    var startMin by remember { mutableIntStateOf(original.startMin) }
    var subject by remember { mutableStateOf(original.subject) }
    var remind by remember { mutableIntStateOf(original.remindBefore) }
    val isNew = store.events.get(original.id) == null
    var pick by remember { mutableStateOf<String?>(null) }

    when (pick) {
        "start" -> GlassDateTimePicker(PickMode.DATE, "Start date", LocalDate.ofEpochDay(day), null, false, { pick = null }) { d, _ ->
            if (d != null) { day = d.toEpochDay(); if (endDay < day) endDay = day }
            pick = null
        }
        "end" -> GlassDateTimePicker(PickMode.DATE, "End date", LocalDate.ofEpochDay(maxOf(day, endDay)), null, endDay > day, { pick = null }) { d, _ ->
            endDay = if (d == null) day else maxOf(d.toEpochDay(), day)
            pick = null
        }
        "time" -> GlassDateTimePicker(PickMode.TIME, "Start time", null, if (startMin >= 0) startMin else 9 * 60, false, { pick = null }) { _, m ->
            if (m != null) startMin = m
            pick = null
        }
        else -> Unit
    }

    Sheet(onClose) {
        Text(if (isNew) "New event" else "Edit event", fontSize = 20.sp, fontWeight = FontWeight.Medium)
        Field(title, { title = it }, "Title")
        Segmented(listOf(0 to "Event", 1 to "Exam", 2 to "Holiday"), kind) { kind = it }
        Label("Date")
        Chips {
            Chip(LocalDate.ofEpochDay(day).format(DAY_FMT), true) { pick = "start" }
            Chip(if (endDay > day) "Until " + LocalDate.ofEpochDay(endDay).format(DAY_FMT) else "Add end date", endDay > day) { pick = "end" }
            Chip(if (startMin >= 0) fmtMin(startMin) else "All day", startMin >= 0) { pick = "time" }
            if (startMin >= 0) Chip("Clear time", false) { startMin = -1 }
        }
        if (kind != 2) {
            Label("Subject")
            SubjectPicker(store, subject) { subject = it }
            Label("Remind me")
            Segmented(listOf(-1 to "Off", 60 to "1 hour", 1440 to "1 day", 10080 to "1 week"), remind) { remind = it }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Btn("Save", {
                if (title.isNotBlank()) {
                    if (remind >= 0) askNotif()
                    store.saveEvent(original.copy(title = title.trim(), kind = kind, day = day, endDay = maxOf(day, endDay),
                        startMin = startMin, subject = subject, remindBefore = if (kind == 2) -1 else remind))
                    onClose()
                }
            }, Modifier.weight(1f))
            if (!isNew) Btn("Delete", { store.deleteEvent(original.id); onClose() }, primary = false, danger = true)
        }
    }
}
