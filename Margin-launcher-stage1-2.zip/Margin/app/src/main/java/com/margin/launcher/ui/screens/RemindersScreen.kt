package com.margin.launcher.ui.screens

import android.app.Activity
import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.IntentCompat
import com.margin.launcher.LauncherViewModel
import com.margin.launcher.UiState
import com.margin.launcher.core.*
import com.margin.launcher.data.StudyStore
import com.margin.launcher.system.Scheduling
import com.margin.launcher.ui.components.*
import com.margin.launcher.ui.theme.M
import java.time.LocalDate
import java.time.format.DateTimeFormatter

private val HM = DateTimeFormatter.ofPattern("HH:mm")

fun reminderWhen(ms: Long, repeat: Repeat): String {
    val today = LocalDate.now()
    val d = TimeUtil.toDate(ms)
    val day = when (d) { today -> "Today"; today.plusDays(1) -> "Tomorrow"; today.minusDays(1) -> "Yesterday"; else -> d.format(DAY_FMT) }
    val rep = when (repeat) { Repeat.NONE -> ""; Repeat.DAILY -> " · Daily"; Repeat.WEEKLY -> " · Weekly"; Repeat.MONTHLY -> " · Monthly" }
    return "$day ${TimeUtil.toTime(ms).format(HM)}$rep"
}

@Composable
fun RemindersScreen(vm: LauncherViewModel, state: UiState, onBack: () -> Unit) {
    val store = vm.store
    val ctx = LocalContext.current
    val c = M.colors
    val reminders by store.reminders.items.collectAsState()
    var editing by remember { mutableStateOf<Reminder?>(null) }
    var isNew by remember { mutableStateOf(false) }
    var showDone by remember { mutableStateOf(false) }
    val askNotif = rememberNotifPermission()

    val sp = remember { ctx.getSharedPreferences("margin_sys", Context.MODE_PRIVATE) }
    var sound by remember { mutableStateOf(sp.getString("reminder_sound", "") ?: "") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) {
            val uri = r.data?.let { IntentCompat.getParcelableExtra(it, RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java) }
            sound = uri?.toString() ?: "silent"
            sp.edit().putString("reminder_sound", sound).apply()
        }
    }
    val soundName = when (sound) {
        "" -> "Default"
        "silent" -> "Silent"
        else -> runCatching { RingtoneManager.getRingtone(ctx, Uri.parse(sound)).getTitle(ctx) }.getOrDefault("Custom")
    }
    val needsExact = Build.VERSION.SDK_INT >= 31 && !ctx.getSystemService(AlarmManager::class.java).canScheduleExactAlarms()

    val e = editing
    if (e != null) {
        ReminderEditor(e, isNew, askNotif, store, vm::toast) { editing = null }
        return
    }

    val active = reminders.filter { !it.done }.sortedBy { it.time }
    val finished = reminders.filter { it.done }.sortedByDescending { it.time }
    val now = System.currentTimeMillis()

    Page("Reminders", onBack, action = {
        GlassIconButton(GIcon.PLUS, "New reminder", {
            isNew = true
            editing = Reminder(id = Ids.next(), title = "", time = now + 60 * 60_000L)
        }, size = 40.dp)
    }) {
        LazyColumn(Modifier.weight(1f).padding(horizontal = 20.dp), contentPadding = PaddingValues(bottom = 24.dp, top = 4.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (needsExact) item {
                GlassCard(Modifier.fillMaxWidth(), radius = 22.dp) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Allow exact alarms so reminders arrive on time.", fontSize = 14.sp)
                        LinkRow("Open alarm settings") {
                            runCatching {
                                ctx.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + ctx.packageName)))
                            }
                        }
                    }
                }
            }
            if (active.isEmpty()) item { Text("No reminders. Tap + to add one.", color = c.secondary, modifier = Modifier.padding(vertical = 20.dp)) }
            items(active, key = { it.id }) { r ->
                val overdue = r.time < now
                GlassCard(Modifier.fillMaxWidth(), radius = 22.dp, onClick = { isNew = false; editing = r }) {
                    Row(Modifier.padding(end = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                        CheckCircle(false, { store.saveReminder(r.copy(done = true)) }, "Mark done: ${r.title}")
                        Column(Modifier.weight(1f).padding(vertical = 10.dp)) {
                            Text(r.title, fontSize = 17.sp, fontWeight = FontWeight.Medium)
                            Text(Scheduling.kindLabel(r.kind) + " · " + reminderWhen(r.time, r.repeat) + if (r.persistent) " · Persistent" else "",
                                fontSize = 13.sp, color = if (overdue) c.alert else c.secondary)
                        }
                    }
                }
            }
            if (finished.isNotEmpty()) item {
                LinkRow(if (showDone) "Hide completed" else "Show completed (${finished.size})") { showDone = !showDone }
            }
            if (showDone) items(finished, key = { "d" + it.id }) { r ->
                GlassCard(Modifier.fillMaxWidth(), radius = 22.dp, onClick = { isNew = false; editing = r }) {
                    Row(Modifier.padding(end = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                        CheckCircle(true, { store.saveReminder(r.copy(done = false)) }, "Mark not done: ${r.title}")
                        Text(r.title, fontSize = 16.sp, color = c.secondary, textDecoration = TextDecoration.LineThrough)
                    }
                }
            }
            item {
                Label("Notification preferences", Modifier.padding(top = 18.dp))
                GlassCard(Modifier.fillMaxWidth().padding(top = 8.dp), radius = 22.dp) {
                    Column(Modifier.padding(horizontal = 16.dp)) {
                        LinkRow("Sound", soundName) {
                            val i = Intent(RingtoneManager.ACTION_RINGTONE_PICKER)
                                .putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_NOTIFICATION)
                                .putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, true)
                                .putExtra(
                                    RingtoneManager.EXTRA_RINGTONE_EXISTING_URI,
                                    (if (sound.isEmpty() || sound == "silent") null else Uri.parse(sound)) as android.os.Parcelable?,
                                )
                            picker.launch(i)
                        }
                        GlassDivider()
                        LinkRow("Battery settings", "If reminders arrive late") {
                            runCatching { ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ReminderEditor(
    original: Reminder, isNew: Boolean, askNotif: () -> Unit,
    store: StudyStore, warn: (String) -> Unit, onClose: () -> Unit,
) {
    val c = M.colors
    var title by remember { mutableStateOf(original.title) }
    var description by remember { mutableStateOf(original.description) }
    var time by remember { mutableLongStateOf(original.time) }
    var repeat by remember { mutableStateOf(original.repeat) }
    var kind by remember { mutableIntStateOf(original.kind) }
    var persistent by remember { mutableStateOf(original.persistent) }
    var picker by remember { mutableStateOf(false) }
    BackHandler(onBack = onClose)

    val date = TimeUtil.toDate(time)
    val tm = TimeUtil.toTime(time)

    Page(if (isNew) "New reminder" else "Edit reminder", onClose) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Field(title, { title = it }, "Remind me to…")
            Field(description, { description = it }, "Description (optional)", singleLine = false, minLines = 3)

            Label("Date and time")
            GlassCard(Modifier.fillMaxWidth(), radius = 22.dp, onClick = { picker = true }) {
                Row(Modifier.padding(horizontal = 18.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    LineIcon(GIcon.CALENDAR, tint = c.accent, size = 24.dp)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(date.format(DAY_FMT) + " " + date.year, fontSize = 17.sp, fontWeight = FontWeight.Medium)
                        Text(fmtClock(tm.hour * 60 + tm.minute, false), fontSize = 14.sp, color = c.secondary)
                    }
                    Text("Change", fontSize = 14.sp, color = c.accent)
                }
            }

            Label("Repeat")
            Segmented(listOf(Repeat.NONE to "Never", Repeat.DAILY to "Daily", Repeat.WEEKLY to "Weekly", Repeat.MONTHLY to "Monthly"), repeat) { repeat = it }
            Label("Type")
            Segmented(listOf(0 to "General", 1 to "Assignment", 2 to "Exam"), kind) { kind = it }
            ToggleRow("Persistent (stays until marked done)", persistent) { persistent = it }
            Text("The notification includes Snooze (10 minutes) and Done.", fontSize = 13.sp, color = c.secondary)

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(vertical = 12.dp)) {
                Btn("Save", {
                    when {
                        title.isBlank() -> warn("Add a title first")
                        repeat == Repeat.NONE && time <= System.currentTimeMillis() -> warn("Choose a time in the future")
                        else -> {
                            askNotif()
                            store.saveReminder(original.copy(title = title.trim(), description = description.trim(), time = time,
                                repeat = repeat, kind = kind, persistent = persistent, done = false))
                            onClose()
                        }
                    }
                }, Modifier.weight(1f))
                if (!isNew) Btn("Delete", { store.deleteReminder(original.id); onClose() }, primary = false, danger = true)
            }
        }
    }

    if (picker) {
        GlassDateTimePicker(
            PickMode.DATE_TIME, "Reminder date and time",
            initialDate = date, initialMinute = tm.hour * 60 + tm.minute, allowClear = false,
            onDismiss = { picker = false },
        ) { d, minute ->
            if (d != null) {
                val m = minute ?: (tm.hour * 60 + tm.minute)
                time = TimeUtil.millis(d, m / 60, m % 60)
            }
            picker = false
        }
    }
}
