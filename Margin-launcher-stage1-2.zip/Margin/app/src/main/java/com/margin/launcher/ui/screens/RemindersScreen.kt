package com.margin.launcher.ui.screens

import android.app.Activity
import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.IntentCompat
import com.margin.launcher.LauncherViewModel
import com.margin.launcher.UiState
import com.margin.launcher.core.*
import com.margin.launcher.system.Scheduling
import com.margin.launcher.ui.components.*
import com.margin.launcher.ui.theme.M
import java.time.LocalDate
import java.time.format.DateTimeFormatter

private val HM = DateTimeFormatter.ofPattern("HH:mm")

fun reminderWhen(ms: Long, repeat: Repeat): String {
    val today = LocalDate.now()
    val d = TimeUtil.toDate(ms)
    val day = when (d) { today -> "Today"; today.plusDays(1) -> "Tomorrow"; today.minusDays(1) -> "Yesterday"; else -> d.format(DAY_FMT) }
    val rep = when (repeat) { Repeat.NONE -> ""; Repeat.DAILY -> " · Daily"; Repeat.WEEKLY -> " · Weekly"; Repeat.MONTHLY -> " · Monthly" }
    return "$day ${TimeUtil.toTime(ms).format(HM)}$rep"
}

@Composable
fun RemindersScreen(vm: LauncherViewModel, state: UiState, onBack: () -> Unit) {
    val store = vm.store
    val ctx = LocalContext.current
    val c = M.colors
    val reminders by store.reminders.items.collectAsState()
    var editing by remember { mutableStateOf<Reminder?>(null) }
    var isNew by remember { mutableStateOf(false) }
    var showDone by remember { mutableStateOf(false) }
    val askNotif = rememberNotifPermission()

    val sp = remember { ctx.getSharedPreferences("margin_sys", Context.MODE_PRIVATE) }
    var sound by remember { mutableStateOf(sp.getString("reminder_sound", "") ?: "") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) {
            val uri = r.data?.let { IntentCompat.getParcelableExtra(it, RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java) }
            sound = uri?.toString() ?: "silent"
            sp.edit().putString("reminder_sound", sound).apply()
        }
    }
    val soundName = when (sound) {
        "" -> "Default"
        "silent" -> "Silent"
        else -> runCatching { RingtoneManager.getRingtone(ctx, Uri.parse(sound)).getTitle(ctx) }.getOrDefault("Custom")
    }
    val needsExact = Build.VERSION.SDK_INT >= 31 && !ctx.getSystemService(AlarmManager::class.java).canScheduleExactAlarms()

    val e = editing
    if (e != null) {
        ReminderEditor(e, isNew, askNotif, store = vm.store) { editing = null }
        return
    }

    val active = reminders.filter { !it.done }.sortedBy { it.time }
    val finished = reminders.filter { it.done }.sortedByDescending { it.time }
    val now = System.currentTimeMillis()

    Page("Reminders", onBack, action = {
        Btn("+ New", {
            isNew = true
            editing = Reminder(Ids.next(), "", now + 60 * 60_000L)
        }, primary = false)
    }) {
        LazyColumn(Modifier.weight(1f).padding(horizontal = 24.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
            if (needsExact) item {
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(c.surface).padding(16.dp)) {
                    Text("Allow exact alarms so reminders arrive on time.", fontSize = 14.sp)
                    LinkRow("Open alarm settings") {
                        runCatching {
                            ctx.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + ctx.packageName)))
                        }
                    }
                }
            }
            if (active.isEmpty()) item { Text("No reminders. Tap + New.", color = c.secondary, modifier = Modifier.padding(vertical = 20.dp)) }
            items(active, key = { it.id }) { r ->
                val overdue = r.time < now
                Row(Modifier.fillMaxWidth().clickable { isNew = false; editing = r }, verticalAlignment = Alignment.CenterVertically) {
                    CheckCircle(false, { store.saveReminder(r.copy(done = true)) }, "Mark done: ${r.title}")
                    Column(Modifier.weight(1f).padding(vertical = 6.dp)) {
                        Text(r.title, fontSize = 17.sp)
                        Text(Scheduling.kindLabel(r.kind) + " · " + reminderWhen(r.time, r.repeat) + if (r.persistent) " · Persistent" else "",
                            fontSize = 13.sp, color = if (overdue) c.alert else c.secondary)
                    }
                }
            }
            if (finished.isNotEmpty()) item {
                LinkRow(if (showDone) "Hide completed" else "Show completed (${finished.size})") { showDone = !showDone }
            }
            if (showDone) items(finished, key = { "d" + it.id }) { r ->
                Row(Modifier.fillMaxWidth().clickable { isNew = false; editing = r }, verticalAlignment = Alignment.CenterVertically) {
                    CheckCircle(true, { store.saveReminder(r.copy(done = false)) }, "Mark not done: ${r.title}")
                    Text(r.title, fontSize = 16.sp, color = c.secondary, textDecoration = TextDecoration.LineThrough)
                }
            }
            item {
                Label("Notifications", Modifier.padding(top = 24.dp))
                LinkRow("Sound", soundName) {
                    val i = Intent(RingtoneManager.ACTION_RINGTONE_PICKER)
                        .putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_NOTIFICATION)
                        .putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, true)
                        .putExtra(
                            RingtoneManager.EXTRA_RINGTONE_EXISTING_URI,
                            (if (sound.isEmpty() || sound == "silent") null else Uri.parse(sound)) as android.os.Parcelable?,
                        )
                    picker.launch(i)
                }
                LinkRow("Battery settings", "If reminders arrive late") {
                    runCatching { ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
                }
            }
        }
    }
}

@Composable
private fun ReminderEditor(
    original: Reminder, isNew: Boolean, askNotif: () -> Unit,
    store: com.margin.launcher.data.StudyStore, onClose: () -> Unit,
) {
    val ctx = LocalContext.current
    var title by remember { mutableStateOf(original.title) }
    var time by remember { mutableLongStateOf(original.time) }
    var repeat by remember { mutableStateOf(original.repeat) }
    var kind by remember { mutableIntStateOf(original.kind) }
    var persistent by remember { mutableStateOf(original.persistent) }
    BackHandler(onBack = onClose)

    Page(if (isNew) "New reminder" else "Edit reminder", onClose) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Field(title, { title = it }, "Remind me to…")
            Label("When")
            val date = TimeUtil.toDate(time)
            val tm = TimeUtil.toTime(time)
            Chips {
                Chip(date.format(DAY_FMT), true) { pickDate(ctx, date) { nd -> time = TimeUtil.millis(nd, tm.hour, tm.minute) } }
                Chip(tm.format(HM), true) { pickTime(ctx, tm.hour, tm.minute) { h, m -> time = TimeUtil.millis(date, h, m) } }
            }
            Label("Repeat")
            Segmented(listOf(Repeat.NONE to "Never", Repeat.DAILY to "Daily", Repeat.WEEKLY to "Weekly", Repeat.MONTHLY to "Monthly"), repeat) { repeat = it }
            Label("Type")
            Segmented(listOf(0 to "General", 1 to "Assignment", 2 to "Exam"), kind) { kind = it }
            ToggleRow("Persistent (stays until marked done)", persistent) { persistent = it }

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(vertical = 12.dp)) {
                Btn("Save", {
                    if (title.isNotBlank()) {
                        askNotif()
                        store.saveReminder(original.copy(title = title.trim(), time = time, repeat = repeat, kind = kind,
                            persistent = persistent, done = false))
                        onClose()
                    }
                }, Modifier.weight(1f))
                if (!isNew) Btn("Delete", { store.deleteReminder(original.id); onClose() }, primary = false, danger = true)
            }
        }
    }
}
