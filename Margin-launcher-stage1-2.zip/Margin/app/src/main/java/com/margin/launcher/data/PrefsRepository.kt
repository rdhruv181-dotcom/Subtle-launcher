package com.margin.launcher.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

enum class ThemeMode { SYSTEM, LIGHT, DARK }
enum class DrawerStyle { GRID, TEXT, COMPACT }

data class UserSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val accent: Int = 0,
    val drawerStyle: DrawerStyle = DrawerStyle.GRID,
    val use24h: Boolean = false,
    val showBattery: Boolean = true,
    val monoIcons: Boolean = false,
    val name: String = "",
    /** null = never customised, so defaults are resolved from the device. */
    val dock: List<String>? = null,
    val hidden: Set<String> = emptySet(),
    val recents: List<String> = emptyList(),
)

object PrefKeys {
    val theme = stringPreferencesKey("theme")
    val accent = intPreferencesKey("accent")
    val drawerStyle = stringPreferencesKey("drawer_style")
    val use24h = booleanPreferencesKey("use_24h")
    val showBattery = booleanPreferencesKey("show_battery")
    val monoIcons = booleanPreferencesKey("mono_icons")
    val name = stringPreferencesKey("name")
    val dock = stringPreferencesKey("dock")
    val hidden = stringSetPreferencesKey("hidden")
    val recents = stringPreferencesKey("recents")
}

private val Context.dataStore by preferencesDataStore(name = "margin_prefs")

class PrefsRepository(private val context: Context) {

    val flow: Flow<UserSettings> = context.dataStore.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { p ->
            UserSettings(
                themeMode = runCatching { ThemeMode.valueOf(p[PrefKeys.theme] ?: "") }.getOrDefault(ThemeMode.SYSTEM),
                accent = p[PrefKeys.accent] ?: 0,
                drawerStyle = runCatching { DrawerStyle.valueOf(p[PrefKeys.drawerStyle] ?: "") }.getOrDefault(DrawerStyle.GRID),
                use24h = p[PrefKeys.use24h] ?: false,
                showBattery = p[PrefKeys.showBattery] ?: true,
                monoIcons = p[PrefKeys.monoIcons] ?: false,
                name = p[PrefKeys.name] ?: "",
                dock = p[PrefKeys.dock]?.split("|")?.filter { it.isNotEmpty() },
                hidden = p[PrefKeys.hidden] ?: emptySet(),
                recents = p[PrefKeys.recents]?.split("|")?.filter { it.isNotEmpty() } ?: emptyList(),
            )
        }

    suspend fun edit(block: MutablePreferences.() -> Unit) {
        context.dataStore.edit { it.block() }
    }
}
