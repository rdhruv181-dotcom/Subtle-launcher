package com.margin.launcher.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

enum class ThemeMode { SYSTEM, LIGHT, DARK }
enum class DrawerStyle { GRID, TEXT, COMPACT }

data class UserSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val accent: Int = 0,
    val drawerStyle: DrawerStyle = DrawerStyle.COMPACT,
    val use24h: Boolean = false,
    val showBattery: Boolean = false,
    val monoIcons: Boolean = false,
    val name: String = "",
    /** null = never customised, so defaults are resolved from the device. */
    val dock: List<String>? = null,
    val hidden: Set<String> = emptySet(),
    val drawerIndex: Boolean = true,
    /** Screen names for the four home shortcuts. */
    val quickTools: List<String> = listOf("TASKS", "PLANNER", "FOCUS", "NOTES"),
    // appearance
    val iconSize: Int = 1,            // 0 small, 1 medium, 2 large
    val textSize: Int = 1,            // 0 small, 1 default, 2 large
    val clockWeight: Int = 0,         // 0 light, 1 regular, 2 medium
    // home sections
    val showSchedule: Boolean = true,
    val showTasks: Boolean = true,
    val showReminder: Boolean = true,
    val showExam: Boolean = true,
    val showQuickNote: Boolean = false,
    // gestures
    val swipeDown: Int = 0,           // 0 quick panel, 1 notification shade
    // goals
    val studyDailyMin: Int = 120,
    val studyWeeklyMin: Int = 600,
    val screenGoalMin: Int = 240,
    // focus
    val focusDnd: Boolean = false,
    val distracting: Set<String> = emptySet(),
) {
    val iconDp: Int get() = when (iconSize) { 0 -> 44; 2 -> 60; else -> 52 }
    val fontScale: Float get() = when (textSize) { 0 -> 0.9f; 2 -> 1.15f; else -> 1f }
}

object PrefKeys {
    val theme = stringPreferencesKey("theme")
    val accent = intPreferencesKey("accent")
    val drawerStyle = stringPreferencesKey("drawer_style")
    val use24h = booleanPreferencesKey("use_24h")
    val showBattery = booleanPreferencesKey("show_battery")
    val monoIcons = booleanPreferencesKey("mono_icons")
    val name = stringPreferencesKey("name")
    val dock = stringPreferencesKey("dock")
    val hidden = stringSetPreferencesKey("hidden")
    val drawerIndex = booleanPreferencesKey("drawer_index")
    val quickTools = stringPreferencesKey("quick_tools")
    val iconSize = intPreferencesKey("icon_size")
    val textSize = intPreferencesKey("text_size")
    val clockWeight = intPreferencesKey("clock_weight")
    val showSchedule = booleanPreferencesKey("show_schedule")
    val showTasks = booleanPreferencesKey("show_tasks")
    val showReminder = booleanPreferencesKey("show_reminder")
    val showExam = booleanPreferencesKey("show_exam")
    val showQuickNote = booleanPreferencesKey("show_quick_note")
    val swipeDown = intPreferencesKey("swipe_down")
    val studyDaily = intPreferencesKey("study_daily")
    val studyWeekly = intPreferencesKey("study_weekly")
    val screenGoal = intPreferencesKey("screen_goal")
    val focusDnd = booleanPreferencesKey("focus_dnd")
    val distracting = stringSetPreferencesKey("distracting")
}

private val Context.dataStore by preferencesDataStore(name = "margin_prefs")

class PrefsRepository(private val context: Context) {

    val flow: Flow<UserSettings> = context.dataStore.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { p ->
            UserSettings(
                themeMode = runCatching { ThemeMode.valueOf(p[PrefKeys.theme] ?: "") }.getOrDefault(ThemeMode.SYSTEM),
                accent = p[PrefKeys.accent] ?: 0,
                drawerStyle = runCatching { DrawerStyle.valueOf(p[PrefKeys.drawerStyle] ?: "") }.getOrDefault(DrawerStyle.COMPACT),
                use24h = p[PrefKeys.use24h] ?: false,
                showBattery = p[PrefKeys.showBattery] ?: false,
                monoIcons = p[PrefKeys.monoIcons] ?: false,
                name = p[PrefKeys.name] ?: "",
                dock = p[PrefKeys.dock]?.split("|")?.filter { it.isNotEmpty() },
                hidden = p[PrefKeys.hidden] ?: emptySet(),
                drawerIndex = p[PrefKeys.drawerIndex] ?: true,
                quickTools = p[PrefKeys.quickTools]?.split(",")?.filter { it.isNotEmpty() }?.takeIf { it.size == 4 } ?: listOf("TASKS", "PLANNER", "FOCUS", "NOTES"),
                iconSize = p[PrefKeys.iconSize] ?: 1,
                textSize = p[PrefKeys.textSize] ?: 1,
                clockWeight = p[PrefKeys.clockWeight] ?: 0,
                showSchedule = p[PrefKeys.showSchedule] ?: true,
                showTasks = p[PrefKeys.showTasks] ?: true,
                showReminder = p[PrefKeys.showReminder] ?: true,
                showExam = p[PrefKeys.showExam] ?: true,
                showQuickNote = p[PrefKeys.showQuickNote] ?: false,
                swipeDown = p[PrefKeys.swipeDown] ?: 0,
                studyDailyMin = p[PrefKeys.studyDaily] ?: 120,
                studyWeeklyMin = p[PrefKeys.studyWeekly] ?: 600,
                screenGoalMin = p[PrefKeys.screenGoal] ?: 240,
                focusDnd = p[PrefKeys.focusDnd] ?: false,
                distracting = p[PrefKeys.distracting] ?: emptySet(),
            )
        }

    suspend fun edit(block: MutablePreferences.() -> Unit) {
        context.dataStore.edit { it.block() }
    }
}
