package com.margin.launcher.core

import java.util.concurrent.atomic.AtomicLong

interface HasId { val id: Long }

enum class Repeat { NONE, DAILY, WEEKLY, MONTHLY }

data class SubTask(val title: String, val done: Boolean = false)

data class Task(
    override val id: Long,
    val title: String,
    val description: String = "",
    val due: Long? = null,
    val hasTime: Boolean = false,
    val priority: Int = 1,            // 0 low, 1 normal, 2 high
    val category: String = "College",
    val subject: String = "",
    val subtasks: List<SubTask> = emptyList(),
    val repeat: Repeat = Repeat.NONE,
    val remindBefore: Int = -1,       // minutes before due, -1 = no reminder
    val done: Boolean = false,
    val doneAt: Long? = null,
    val created: Long = System.currentTimeMillis(),
) : HasId

data class Note(
    override val id: Long,
    val title: String = "",
    val body: String = "",
    val checks: List<SubTask> = emptyList(),
    val folder: String = "Inbox",
    val subject: String = "",
    val pinned: Boolean = false,
    val created: Long = System.currentTimeMillis(),
    val updated: Long = created,
) : HasId

data class Reminder(
    override val id: Long,
    val title: String,
    val description: String = "",
    val time: Long,
    val repeat: Repeat = Repeat.NONE,
    val kind: Int = 0,                // 0 general, 1 assignment, 2 exam
    val persistent: Boolean = false,
    val done: Boolean = false,
) : HasId

data class Event(
    override val id: Long,
    val title: String,
    val day: Long,                    // epoch day
    val endDay: Long = day,
    val startMin: Int = -1,           // minutes after midnight, -1 = all day
    val kind: Int = 0,                // 0 event, 1 exam, 2 holiday
    val subject: String = "",
    val remindBefore: Int = -1,
) : HasId

data class FocusSession(
    override val id: Long,
    val start: Long,
    val minutes: Int,
    val subject: String = "",
    val completed: Boolean = true,
    val interruptions: Int = 0,
    val taskId: Long = -1,
) : HasId

data class JournalEntry(
    override val id: Long,            // epoch day
    val good: String = "",
    val done: String = "",
    val improve: String = "",
    val tomorrow: String = "",
) : HasId

data class Subject(override val id: Long, val name: String) : HasId

val TASK_CATEGORIES = listOf("College", "Assignment", "Exams", "Projects", "Personal")

object Ids {
    private val last = AtomicLong()
    fun next(): Long {
        val n = System.currentTimeMillis()
        return last.updateAndGet { if (n > it) n else it + 1 }
    }
}
