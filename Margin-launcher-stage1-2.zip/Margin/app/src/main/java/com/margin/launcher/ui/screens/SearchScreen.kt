package com.margin.launcher.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.margin.launcher.LauncherViewModel
import com.margin.launcher.Screen
import com.margin.launcher.UiState
import com.margin.launcher.data.AppInfo
import com.margin.launcher.ui.components.*
import com.margin.launcher.ui.theme.M

private data class Hit(val icon: GIcon, val title: String, val subtitle: String, val onClick: () -> Unit)

private val SETTINGS_INDEX = listOf(
    "Appearance" to "theme dark light accent colour icons text size clock",
    "Home screen" to "greeting name 24 hour battery cards shortcuts quick tools",
    "App drawer" to "drawer list grid text scrollbar index hidden apps",
    "Gestures" to "swipe down notifications quick panel",
    "Focus mode" to "do not disturb distracting apps pomodoro",
    "Notifications" to "reminders sound alarms battery permission",
    "Productivity" to "study goal screen time goal",
    "Permissions" to "usage access notifications exact alarms do not disturb",
    "Backup and restore" to "export import backup data",
    "About" to "version privacy",
)

private val TOOLS_INDEX = listOf(
    Triple("Calculator", 0, "calc math"),
    Triple("Stopwatch", 1, "timer lap"),
    Triple("Timer", 2, "countdown"),
    Triple("Unit converter", 3, "convert length mass temperature volume"),
    Triple("QR scanner", 4, "scan camera"),
    Triple("Clipboard shortcuts", 4, "paste copy"),
    Triple("Files and downloads", 4, "files downloads browse"),
)

/** One search across apps, tasks, notes, reminders, settings and student tools. */
@Composable
fun SearchScreen(vm: LauncherViewModel, state: UiState, onBack: () -> Unit, onLaunch: (AppInfo) -> Unit) {
    val c = M.colors
    val store = vm.store
    val tasks by store.tasks.items.collectAsState()
    val notes by store.notes.items.collectAsState()
    val reminders by store.reminders.items.collectAsState()
    var query by remember { mutableStateOf("") }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }
    val q = query.trim()

    val groups: List<Pair<String, List<Hit>>> = remember(q, state.visibleApps, tasks, notes, reminders) {
        if (q.isEmpty()) {
            listOf("Student tools" to TOOLS_INDEX.take(4).map { (n, tab, _) -> Hit(GIcon.TOOLS, n, "Tool") { vm.openTools(tab) } })
        } else {
            val has = { s: String -> s.contains(q, ignoreCase = true) }
            listOf(
                "Apps" to state.visibleApps.filter { has(it.label) }
                    .sortedWith(compareBy({ !it.label.startsWith(q, true) }, { it.label.lowercase() })).take(6)
                    .map { a -> Hit(GIcon.GRID, a.label, "App") { onLaunch(a) } },
                "Tasks" to tasks.filter { has(it.title) || has(it.description) || has(it.subject) }.take(5)
                    .map { t -> Hit(GIcon.CHECK_CIRCLE, t.title, if (t.done) "Completed task" else "Task") { vm.go(Screen.TASKS) } },
                "Notes" to notes.filter { has(it.title) || has(it.body) || has(it.subject) }.take(5)
                    .map { n -> Hit(GIcon.NOTE, n.title.ifBlank { n.body.lineSequence().firstOrNull().orEmpty() }.ifBlank { "Untitled" }, "Note · " + n.folder) { vm.go(Screen.NOTES) } },
                "Reminders" to reminders.filter { has(it.title) || has(it.description) }.take(5)
                    .map { r -> Hit(GIcon.BELL, r.title, reminderWhen(r.time, r.repeat)) { vm.go(Screen.REMINDERS) } },
                "Settings" to SETTINGS_INDEX.filter { (n, k) -> has(n) || has(k) }.take(4)
                    .map { (n, _) -> Hit(GIcon.SLIDERS, n, "Settings") { vm.openSettings() } },
                "Student tools" to TOOLS_INDEX.filter { (n, _, k) -> has(n) || has(k) }.take(4)
                    .map { (n, tab, _) -> Hit(GIcon.TOOLS, n, "Tool") { vm.openTools(tab) } },
            ).filter { it.second.isNotEmpty() }
        }
    }

    Page("Search", onBack) {
        GlassSearchBar(query, { query = it }, "Search apps, tasks, notes", Modifier.padding(horizontal = 20.dp),
            focusRequester = focus, onSearch = { groups.firstOrNull { it.first == "Apps" }?.second?.firstOrNull()?.onClick?.invoke() })
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (q.isNotEmpty() && groups.isEmpty()) item { Text("No results for “$q”", color = c.secondary, modifier = Modifier.padding(top = 16.dp)) }
            groups.forEach { (title, hits) ->
                item(key = "t_$title") { Label(title, Modifier.padding(top = 8.dp)) }
                hits.forEachIndexed { i, hit ->
                    item(key = "$title$i") {
                        GlassCard(Modifier.fillMaxWidth(), radius = 20.dp, onClick = hit.onClick) {
                            Row(Modifier.padding(horizontal = 16.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                                LineIcon(hit.icon, tint = c.accent, size = 22.dp)
                                Spacer(Modifier.width(14.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(hit.title, fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(hit.subtitle, fontSize = 13.sp, color = c.secondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
