package com.margin.launcher.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.clickable
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.margin.launcher.LauncherViewModel
import com.margin.launcher.Screen
import com.margin.launcher.UiState
import com.margin.launcher.data.AppInfo
import com.margin.launcher.ui.components.*
import com.margin.launcher.ui.theme.IOS
import com.margin.launcher.ui.theme.M

private data class Hit(val icon: GIcon, val color: Color, val title: String, val subtitle: String, val onClick: () -> Unit)

private val SETTINGS_INDEX = listOf(
    "Appearance" to "theme dark light accent colour icons text size clock",
    "Home Screen" to "greeting name 24 hour battery cards shortcuts quick tools",
    "App Drawer" to "drawer list grid text scrollbar index hidden apps",
    "Gestures" to "swipe down notifications quick panel",
    "Focus Mode" to "do not disturb distracting apps pomodoro",
    "Notifications" to "reminders sound alarms battery permission",
    "Productivity" to "study goal screen time goal",
    "Permissions" to "usage access notifications exact alarms do not disturb",
    "Backup and Restore" to "export import backup data",
    "About" to "version privacy",
)

private val TOOLS_INDEX = listOf(
    Triple("Calculator", 0, "calc math"),
    Triple("Stopwatch", 1, "timer lap"),
    Triple("Timer", 2, "countdown"),
    Triple("Unit converter", 3, "convert length mass temperature volume"),
    Triple("QR scanner", 4, "scan camera"),
    Triple("Clipboard shortcuts", 4, "paste copy"),
    Triple("Files and downloads", 4, "files downloads browse"),
)

/** Laid out like Spotlight: a field at the top, a Top Hit, then results grouped by kind. */
@Composable
fun SearchScreen(vm: LauncherViewModel, state: UiState, onBack: () -> Unit, onLaunch: (AppInfo) -> Unit) {
    val c = M.colors
    val store = vm.store
    val tasks by store.tasks.items.collectAsState()
    val notes by store.notes.items.collectAsState()
    val reminders by store.reminders.items.collectAsState()
    var query by remember { mutableStateOf("") }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }
    val q = query.trim()

    val groups: List<Pair<String, List<Hit>>> = remember(q, state.visibleApps, tasks, notes, reminders) {
        if (q.isEmpty()) {
            listOf("Student tools" to TOOLS_INDEX.take(4).map { (n, tab, _) -> Hit(GIcon.TOOLS, IOS.Gray, n, "Tool") { vm.openTools(tab) } })
        } else {
            val has = { s: String -> s.contains(q, ignoreCase = true) }
            listOf(
                "Applications" to state.visibleApps.filter { has(it.label) }
                    .sortedWith(compareBy({ !it.label.startsWith(q, true) }, { it.label.lowercase() })).take(6)
                    .map { a -> Hit(GIcon.GRID, IOS.Indigo, a.label, "Application") { onLaunch(a) } },
                "Tasks" to tasks.filter { has(it.title) || has(it.description) || has(it.subject) }.take(5)
                    .map { t -> Hit(GIcon.CHECK_CIRCLE, IOS.Blue, t.title, if (t.done) "Completed task" else "Task") { vm.go(Screen.TASKS) } },
                "Notes" to notes.filter { has(it.title) || has(it.body) || has(it.subject) }.take(5)
                    .map { n -> Hit(GIcon.NOTE, IOS.Yellow, n.title.ifBlank { n.body.lineSequence().firstOrNull().orEmpty() }.ifBlank { "New Note" }, "Note · " + n.folder) { vm.go(Screen.NOTES) } },
                "Reminders" to reminders.filter { has(it.title) || has(it.description) }.take(5)
                    .map { r -> Hit(GIcon.BELL, IOS.Red, r.title, reminderWhen(r.time, r.repeat)) { vm.go(Screen.REMINDERS) } },
                "Settings" to SETTINGS_INDEX.filter { (n, k) -> has(n) || has(k) }.take(4)
                    .map { (n, _) -> Hit(GIcon.SLIDERS, IOS.Gray, n, "Settings") { vm.openSettings() } },
                "Student tools" to TOOLS_INDEX.filter { (n, _, k) -> has(n) || has(k) }.take(4)
                    .map { (n, tab, _) -> Hit(GIcon.TOOLS, IOS.Teal, n, "Tool") { vm.openTools(tab) } },
            ).filter { it.second.isNotEmpty() }
        }
    }
    val top = if (q.isEmpty()) null else groups.firstOrNull()?.second?.firstOrNull()

    Page("Search", onBack, backLabel = "Cancel", largeTitle = false) {
        GlassSearchBar(query, { query = it }, "Search", Modifier.padding(horizontal = 16.dp),
            focusRequester = focus, onSearch = { top?.onClick?.invoke() })
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 24.dp)) {
            if (q.isNotEmpty() && groups.isEmpty()) item { Text("No results for “$q”", color = c.secondary, fontSize = 17.sp, modifier = Modifier.padding(24.dp)) }
            if (top != null) {
                item(key = "top") {
                    Column { GroupHeader("Top hit"); InsetGroup { HitRow(top, big = true) } }
                }
            }
            groups.forEach { (title, hits) ->
                item(key = "g_$title") {
                    Column {
                        GroupHeader(title)
                        InsetGroup {
                            hits.forEachIndexed { i, hit ->
                                if (i > 0) RowDivider(66.dp)
                                HitRow(hit, big = false)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HitRow(hit: Hit, big: Boolean) {
    val c = M.colors
    Row(
        Modifier.fillMaxWidth().clickable { hit.onClick() }.padding(horizontal = 16.dp, vertical = if (big) 14.dp else 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconTile(hit.icon, hit.color, if (big) 48.dp else 36.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(hit.title, fontSize = if (big) 19.sp else 17.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(hit.subtitle, fontSize = 13.sp, color = c.secondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        LineIcon(GIcon.CHEVRON_RIGHT, tint = c.secondary.copy(alpha = 0.7f), size = 16.dp)
    }
}
