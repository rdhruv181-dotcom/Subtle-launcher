package com.margin.launcher.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import java.io.File

/** Keeps the user's chosen wallpaper as one downscaled JPEG in app-private storage. */
object WallpaperStore {
    private const val MAX_SIDE = 2400
    private fun file(ctx: Context) = File(ctx.filesDir, "wallpaper.jpg")

    /** Decodes (with EXIF rotation applied), downsizes and saves the image. Returns false if it can't be read. */
    fun save(ctx: Context, uri: Uri): Boolean = try {
        val src = ImageDecoder.createSource(ctx.contentResolver, uri)
        val bmp = ImageDecoder.decodeBitmap(src) { decoder, info, _ ->
            val w = info.size.width
            val h = info.size.height
            val scale = minOf(1f, MAX_SIDE.toFloat() / maxOf(w, h))
            decoder.setTargetSize(maxOf(1, (w * scale).toInt()), maxOf(1, (h * scale).toInt()))
            decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        }
        file(ctx).outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
        true
    } catch (e: Exception) {
        false
    }

    /** blur = shrink then let the GPU scale it back up, a cheap soft-focus that works on every Android version. */
    fun load(ctx: Context, blur: Boolean): ImageBitmap? {
        val f = file(ctx)
        if (!f.exists()) return null
        val bmp = BitmapFactory.decodeFile(f.path) ?: return null
        val out = if (blur) Bitmap.createScaledBitmap(bmp, maxOf(1, bmp.width / 24), maxOf(1, bmp.height / 24), true) else bmp
        return out.asImageBitmap()
    }

    fun delete(ctx: Context) { runCatching { file(ctx).delete() } }
}
