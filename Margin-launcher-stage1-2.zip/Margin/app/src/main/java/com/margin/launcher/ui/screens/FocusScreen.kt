package com.margin.launcher.ui.screens

import android.content.Intent
import android.provider.Settings
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.margin.launcher.LauncherViewModel
import com.margin.launcher.UiState
import com.margin.launcher.core.*
import com.margin.launcher.system.FocusEngine
import com.margin.launcher.system.FocusState
import com.margin.launcher.system.NoisePlayer
import com.margin.launcher.system.displayMs
import com.margin.launcher.ui.components.*
import com.margin.launcher.ui.theme.M
import kotlinx.coroutines.delay
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter

private val SESSION_FMT = DateTimeFormatter.ofPattern("EEE d MMM, HH:mm")

@Composable
fun FocusScreen(vm: LauncherViewModel, state: UiState, onBack: () -> Unit) {
    val focus by FocusEngine.state.collectAsState()

    // Ambient sound plays only while a focus phase is running.
    LaunchedEffect(focus.active, focus.phase, focus.paused, focus.noise) {
        if (focus.active && focus.phase == 0 && !focus.paused && focus.noise > 0) NoisePlayer.start(focus.noise) else NoisePlayer.stop()
    }
    DisposableEffect(Unit) { onDispose { if (!FocusEngine.state.value.active) NoisePlayer.stop() } }

    if (focus.active) Running(focus, onBack) else Setup(vm, state, onBack)
}

/** Immersive timer: a glass progress ring, the current task, and just two controls. */
@Composable
private fun Running(f: FocusState, onBack: () -> Unit) {
    val c = M.colors
    val ctx = LocalContext.current
    val now by produceState(System.currentTimeMillis()) { while (true) { value = System.currentTimeMillis(); delay(250) } }
    val ms = f.displayMs(now)
    val secs = if (f.stopwatch) ms / 1000 else (ms + 999) / 1000
    val total = (if (f.phase == 0) f.focusMin else f.breakMin) * 60_000f
    val progress = if (f.stopwatch) ((ms / 1000) % 60) / 60f else if (total > 0f) 1f - ms / total else 0f
    val sweep by animateFloatAsState(progress.coerceIn(0f, 1f), label = "sweep")
    val track = c.text.copy(alpha = 0.12f)
    val ring = c.accent

    Page("Focus", onBack) {
        Column(
            Modifier.weight(1f).fillMaxWidth().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center,
        ) {
            Text(
                when { f.stopwatch -> "Stopwatch"; f.phase == 0 -> "Focus"; else -> "Break" },
                fontSize = 17.sp, color = c.secondary, letterSpacing = 2.sp,
            )
            Spacer(Modifier.height(16.dp))
            Box(Modifier.size(280.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    val stroke = 14.dp.toPx()
                    val tl = Offset(stroke / 2, stroke / 2)
                    val sz = Size(size.width - stroke, size.height - stroke)
                    drawArc(track, -90f, 360f, false, tl, sz, style = Stroke(stroke, cap = StrokeCap.Round))
                    if (sweep > 0.002f) drawArc(ring, -90f, sweep * 360f, false, tl, sz, style = Stroke(stroke, cap = StrokeCap.Round))
                }
                val shown = if (f.stopwatch && secs >= 3600) "%d:%02d:%02d".format(secs / 3600, secs / 60 % 60, secs % 60) else "%02d:%02d".format(secs / 60, secs % 60)
                Text(shown, fontSize = 60.sp, fontWeight = FontWeight.Light)
            }
            Spacer(Modifier.height(20.dp))
            val what = listOf(f.taskTitle.ifEmpty { null }, f.subject.ifEmpty { null }).filterNotNull().joinToString(" · ")
            if (what.isNotEmpty() && f.phase == 0) Text(what, fontSize = 19.sp, textAlign = TextAlign.Center)
            if (f.phase == 1) Text("Step away from the screen.", fontSize = 16.sp, color = c.secondary)
            if (f.interruptions > 0) Text("${f.interruptions} interruption${if (f.interruptions > 1) "s" else ""}", fontSize = 13.sp, color = c.secondary, modifier = Modifier.padding(top = 8.dp))
            Spacer(Modifier.height(32.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                GlassButton(if (f.paused) "Resume" else "Pause", { if (f.paused) FocusEngine.resume(ctx) else FocusEngine.pause(ctx) },
                    primary = false, icon = if (f.paused) GIcon.PLAY else GIcon.PAUSE)
                GlassButton(if (f.phase == 1) "Skip break" else "End session", { FocusEngine.stop(ctx) }, primary = false, danger = f.phase == 0, icon = GIcon.STOP)
            }
        }
    }
}

@Composable
private fun Setup(vm: LauncherViewModel, state: UiState, onBack: () -> Unit) {
    val c = M.colors
    val store = vm.store
    val s = state.settings
    val sessions by store.sessions.items.collectAsState()
    val today = LocalDate.now()
    val perDay = minutesPerDay(sessions)
    val streakDays = streak(perDay.filter { it.value >= 10 }.keys, today)
    val todayMin = perDay[today] ?: 0

    Page("Focus", onBack) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Stat("Today", fmtDuration(todayMin), Modifier.weight(1f))
                Stat("Streak", "$streakDays day${if (streakDays == 1) "" else "s"}", Modifier.weight(1f))
                Stat("Sessions", "${sessions.count { TimeUtil.toDate(it.start) == today }}", Modifier.weight(1f))
            }
            Text("Daily goal ${fmtDuration(s.studyDailyMin)}", fontSize = 13.sp, color = c.secondary)
            ProgressBar(todayMin / s.studyDailyMin.toFloat())

            GlassCard(Modifier.fillMaxWidth(), radius = 26.dp) {
                Column(Modifier.padding(18.dp)) { FocusStarter(vm, state, compact = false, onStarted = {}) }
            }

            Label("History", Modifier.padding(top = 8.dp))
            val recent = sessions.sortedByDescending { it.start }.take(12)
            if (recent.isEmpty()) Text("No sessions yet.", color = c.secondary)
            recent.forEach { r ->
                GlassCard(Modifier.fillMaxWidth(), radius = 20.dp) {
                    Row(Modifier.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(r.subject.ifEmpty { "Focus session" }, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                            Text(Instant.ofEpochMilli(r.start).atZone(ZoneId.systemDefault()).format(SESSION_FMT) +
                                if (r.interruptions > 0) " · ${r.interruptions} interruptions" else "", fontSize = 13.sp, color = c.secondary)
                        }
                        Text(fmtDuration(r.minutes) + if (!r.completed) " · early" else "", fontSize = 14.sp, color = c.secondary)
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

/**
 * Everything needed to begin a session. Used by the Focus page and, in compact form, by the
 * bottom sheet that opens from the Focus button on the home screen.
 */
@Composable
fun FocusStarter(vm: LauncherViewModel, state: UiState, compact: Boolean, onStarted: () -> Unit) {
    val c = M.colors
    val ctx = LocalContext.current
    val store = vm.store
    val s = state.settings
    val tasks by store.tasks.items.collectAsState()

    var preset by remember { mutableIntStateOf(0) }          // 0 = 25/5, 1 = 50/10, 2 = custom, 3 = stopwatch
    var customFocus by remember { mutableStateOf("40") }
    var customBreak by remember { mutableStateOf("10") }
    var subject by remember { mutableStateOf("") }
    var taskId by remember { mutableLongStateOf(-1L) }
    var noise by remember { mutableIntStateOf(0) }
    var picking by remember { mutableStateOf(false) }
    val openTasks = tasks.filter { !it.done }.sortedBy { it.due ?: Long.MAX_VALUE }.take(6)

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Label("Session")
        Chips {
            listOf("25 / 5", "50 / 10", "Custom", "Stopwatch").forEachIndexed { i, l -> Chip(l, preset == i) { preset = i } }
        }
        if (preset == 2) Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Field(customFocus, { customFocus = it.filter(Char::isDigit).take(3) }, "Focus min", Modifier.weight(1f), keyboardType = KeyboardType.Number)
            Field(customBreak, { customBreak = it.filter(Char::isDigit).take(3) }, "Break min", Modifier.weight(1f), keyboardType = KeyboardType.Number)
        }

        Label("Studying")
        SubjectPicker(store, subject) { subject = it }
        if (openTasks.isNotEmpty()) {
            Label("Working on")
            Chips {
                Chip("Nothing specific", taskId == -1L) { taskId = -1L }
                openTasks.forEach { t -> Chip(t.title.take(24), taskId == t.id) { taskId = t.id } }
            }
        }

        if (!compact) {
            Label("Ambient sound")
            Chips { listOf("Off", "White", "Brown", "Rain-like").forEachIndexed { i, l -> Chip(l, noise == i) { noise = i } } }

            Label("Distractions")
            ToggleRow("Silence notifications (Do Not Disturb)", s.focusDnd, vm::setFocusDnd)
            val dndGranted = ctx.getSystemService(android.app.NotificationManager::class.java).isNotificationPolicyAccessGranted
            if (s.focusDnd && !dndGranted) {
                Text("Android needs your permission for this. Tap below, then allow Margin.", fontSize = 13.sp, color = c.secondary)
                LinkRow("Grant Do Not Disturb access") { runCatching { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) } }
            }
            LinkRow("Distracting apps", "${s.distracting.size} selected") { picking = true }
            Text("Margin can't block apps opened from a notification or the recents screen. It asks before opening your chosen apps from Margin during a session.",
                fontSize = 13.sp, color = c.secondary)
        }

        GlassButton("Start focus", {
            val tTitle = tasks.firstOrNull { it.id == taskId }?.title ?: ""
            if (preset == 3) {
                FocusEngine.start(ctx, 0, 0, subject, tTitle, noise, s.focusDnd, stopwatch = true)
            } else {
                val (fm, bm) = when (preset) {
                    0 -> 25 to 5
                    1 -> 50 to 10
                    else -> (customFocus.toIntOrNull() ?: 25).coerceIn(1, 240) to (customBreak.toIntOrNull() ?: 5).coerceIn(0, 60)
                }
                FocusEngine.start(ctx, fm, bm, subject, tTitle, noise, s.focusDnd)
            }
            onStarted()
        }, Modifier.fillMaxWidth().padding(top = 4.dp), icon = GIcon.PLAY, color = com.margin.launcher.ui.theme.IOS.Green)
    }

    if (picking) AppPickerDialog(state.visibleApps, vm.repo, s.distracting, s.monoIcons, vm::toggleDistracting) { picking = false }
}

@Composable
private fun Stat(label: String, value: String, modifier: Modifier) {
    GlassCard(modifier, radius = 22.dp) {
        Column(Modifier.padding(horizontal = 14.dp, vertical = 12.dp)) {
            Text(value, fontSize = 22.sp, fontWeight = FontWeight.Light, maxLines = 1)
            Text(label, fontSize = 13.sp, color = M.colors.secondary)
        }
    }
}
