package com.margin.launcher.ui.screens

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.margin.launcher.LauncherViewModel
import com.margin.launcher.UiState
import com.margin.launcher.core.*
import com.margin.launcher.system.FocusEngine
import com.margin.launcher.system.NoisePlayer
import com.margin.launcher.ui.components.*
import com.margin.launcher.ui.theme.M
import kotlinx.coroutines.delay
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter

private val SESSION_FMT = DateTimeFormatter.ofPattern("EEE d MMM, HH:mm")

@Composable
fun FocusScreen(vm: LauncherViewModel, state: UiState, onBack: () -> Unit) {
    val focus by FocusEngine.state.collectAsState()

    // Ambient sound plays only while a focus phase is running on screen.
    LaunchedEffect(focus.active, focus.phase, focus.paused, focus.noise) {
        if (focus.active && focus.phase == 0 && !focus.paused && focus.noise > 0) NoisePlayer.start(focus.noise) else NoisePlayer.stop()
    }
    DisposableEffect(Unit) { onDispose { if (!FocusEngine.state.value.active) NoisePlayer.stop() } }

    if (focus.active) Running(focus, onBack) else Setup(vm, state, onBack)
}

@Composable
private fun Running(f: FocusState, onBack: () -> Unit) {
    val c = M.colors
    val ctx = LocalContext.current
    val now by produceState(System.currentTimeMillis()) { while (true) { value = System.currentTimeMillis(); delay(250) } }
    val left = if (f.paused) f.pausedLeft else (f.phaseEnd - now).coerceAtLeast(0)
    val secs = (left + 999) / 1000
    val total = (if (f.phase == 0) f.focusMin else f.breakMin) * 60_000f

    Page("Focus", onBack) {
        Column(Modifier.weight(1f).fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text(if (f.phase == 0) "Focus" else "Break", fontSize = 17.sp, color = c.secondary)
            Text("%02d:%02d".format(secs / 60, secs % 60), fontSize = 88.sp, fontWeight = FontWeight.Light, letterSpacing = (-2).sp)
            ProgressBar(1f - left / total, Modifier.padding(vertical = 20.dp))
            val what = listOf(f.taskTitle.ifEmpty { null }, f.subject.ifEmpty { null }).filterNotNull().joinToString(" · ")
            if (what.isNotEmpty() && f.phase == 0) Text(what, fontSize = 18.sp, textAlign = TextAlign.Center)
            if (f.phase == 1) Text("Step away from the screen.", fontSize = 16.sp, color = c.secondary)
            if (f.interruptions > 0) Text("${f.interruptions} interruption${if (f.interruptions > 1) "s" else ""}", fontSize = 13.sp, color = c.secondary, modifier = Modifier.padding(top = 8.dp))
            Spacer(Modifier.height(36.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Btn(if (f.paused) "Resume" else "Pause", { if (f.paused) FocusEngine.resume(ctx) else FocusEngine.pause(ctx) }, primary = false)
                Btn(if (f.phase == 1) "Skip break" else "End session", { FocusEngine.stop(ctx) }, primary = false, danger = f.phase == 0)
            }
        }
    }
}

@Composable
private fun Setup(vm: LauncherViewModel, state: UiState, onBack: () -> Unit) {
    val c = M.colors
    val ctx = LocalContext.current
    val store = vm.store
    val s = state.settings
    val sessions by store.sessions.items.collectAsState()
    val tasks by store.tasks.items.collectAsState()
    val today = LocalDate.now()

    var preset by remember { mutableIntStateOf(0) }          // 0 = 25/5, 1 = 50/10, 2 = custom
    var customFocus by remember { mutableStateOf("40") }
    var customBreak by remember { mutableStateOf("10") }
    var subject by remember { mutableStateOf("") }
    var taskId by remember { mutableLongStateOf(-1L) }
    var noise by remember { mutableIntStateOf(0) }
    var picking by remember { mutableStateOf(false) }

    val perDay = minutesPerDay(sessions)
    val streakDays = streak(perDay.filter { it.value >= 10 }.keys, today)
    val todayMin = perDay[today] ?: 0
    val dndGranted = ctx.getSystemService(android.app.NotificationManager::class.java).isNotificationPolicyAccessGranted
    val openTasks = tasks.filter { !it.done }.sortedBy { it.due ?: Long.MAX_VALUE }.take(6)

    Page("Focus", onBack) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Stat("Today", fmtDuration(todayMin))
                Stat("Streak", "$streakDays day${if (streakDays == 1) "" else "s"}")
                Stat("Sessions", "${sessions.count { TimeUtil.toDate(it.start) == today }}")
            }

            Label("Session")
            Segmented(listOf(0 to "25 / 5", 1 to "50 / 10", 2 to "Custom"), preset) { preset = it }
            if (preset == 2) Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Field(customFocus, { customFocus = it.filter(Char::isDigit).take(3) }, "Focus min", Modifier.weight(1f), keyboardType = KeyboardType.Number)
                Field(customBreak, { customBreak = it.filter(Char::isDigit).take(3) }, "Break min", Modifier.weight(1f), keyboardType = KeyboardType.Number)
            }

            Label("Studying")
            SubjectPicker(store, subject) { subject = it }
            if (openTasks.isNotEmpty()) {
                Label("Working on")
                Chips {
                    Chip("Nothing specific", taskId == -1L) { taskId = -1L }
                    openTasks.forEach { t -> Chip(t.title.take(24), taskId == t.id) { taskId = t.id } }
                }
            }

            Label("Ambient sound")
            Chips { listOf("Off", "White", "Brown", "Rain-like").forEachIndexed { i, l -> Chip(l, noise == i) { noise = i } } }

            Label("Distractions")
            ToggleRow("Silence notifications (Do Not Disturb)", s.focusDnd, vm::setFocusDnd)
            if (s.focusDnd && !dndGranted) {
                Text("Android needs your permission for this. Tap below, then allow Margin.", fontSize = 13.sp, color = c.secondary)
                LinkRow("Grant Do Not Disturb access") { runCatching { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) } }
            }
            LinkRow("Distracting apps", "${s.distracting.size} selected") { picking = true }
            Text("Margin can't block apps opened from elsewhere (notifications, recents). It asks before opening these from Margin during a session.",
                fontSize = 13.sp, color = c.secondary)

            Btn("Start focus", {
                val (fm, bm) = when (preset) {
                    0 -> 25 to 5
                    1 -> 50 to 10
                    else -> (customFocus.toIntOrNull() ?: 25).coerceIn(1, 240) to (customBreak.toIntOrNull() ?: 5).coerceIn(0, 60)
                }
                val tTitle = tasks.firstOrNull { it.id == taskId }?.title ?: ""
                FocusEngine.start(ctx, fm, bm, subject, tTitle, noise, s.focusDnd)
            }, Modifier.fillMaxWidth().padding(top = 8.dp))

            Label("History", Modifier.padding(top = 12.dp))
            val recent = sessions.sortedByDescending { it.start }.take(12)
            if (recent.isEmpty()) Text("No sessions yet.", color = c.secondary)
            recent.forEach { r ->
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                    Column(Modifier.weight(1f)) {
                        Text(r.subject.ifEmpty { "Focus session" }, fontSize = 16.sp)
                        Text(Instant.ofEpochMilli(r.start).atZone(ZoneId.systemDefault()).format(SESSION_FMT) +
                            if (r.interruptions > 0) " · ${r.interruptions} interruptions" else "", fontSize = 13.sp, color = c.secondary)
                    }
                    Text(fmtDuration(r.minutes) + if (!r.completed) " (ended early)" else "", fontSize = 14.sp, color = c.secondary)
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    if (picking) AppPickerDialog(state.visibleApps, vm.repo, s.distracting, s.monoIcons, vm::toggleDistracting) { picking = false }
}

@Composable
private fun Stat(label: String, value: String) {
    Column {
        Text(value, fontSize = 24.sp, fontWeight = FontWeight.Light)
        Text(label, fontSize = 13.sp, color = M.colors.secondary)
    }
}
