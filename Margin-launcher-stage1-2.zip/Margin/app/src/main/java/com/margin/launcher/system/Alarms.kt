package com.margin.launcher.system

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.margin.launcher.core.*
import com.margin.launcher.data.StudyStore

object Alarms {
    const val ACTION_FIRE = "com.margin.launcher.ALARM"
    const val ACTION_SNOOZE = "com.margin.launcher.SNOOZE"
    const val ACTION_DONE = "com.margin.launcher.DONE"
    const val X_TYPE = "type"
    const val X_ID = "id"
    const val X_TITLE = "title"
    const val X_TEXT = "text"

    fun key(type: String, id: Long) = "$type:$id".hashCode()

    fun intent(ctx: Context, type: String, id: Long, title: String, text: String, action: String = ACTION_FIRE) =
        Intent(ctx, AlarmReceiver::class.java).setAction(action)
            .putExtra(X_TYPE, type).putExtra(X_ID, id).putExtra(X_TITLE, title).putExtra(X_TEXT, text)

    fun schedule(ctx: Context, type: String, id: Long, at: Long, title: String, text: String) {
        if (at <= System.currentTimeMillis()) return
        val pi = PendingIntent.getBroadcast(
            ctx, key(type, id), intent(ctx, type, id, title, text),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val am = ctx.getSystemService(AlarmManager::class.java)
        try {
            // Without the exact-alarm permission, fall back to a (slightly imprecise) doze-safe alarm.
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            }
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    fun cancel(ctx: Context, type: String, id: Long) {
        val pi = PendingIntent.getBroadcast(
            ctx, key(type, id), intent(ctx, type, id, "", ""),
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE,
        ) ?: return
        ctx.getSystemService(AlarmManager::class.java).cancel(pi)
        pi.cancel()
    }
}

/** Keeps alarms in step with the data. */
object Scheduling {
    private fun eventStart(e: Event): Long =
        TimeUtil.millis(java.time.LocalDate.ofEpochDay(e.day), if (e.startMin >= 0) e.startMin / 60 else 9, if (e.startMin >= 0) e.startMin % 60 else 0)

    fun syncTask(ctx: Context, t: Task) {
        Alarms.cancel(ctx, "task", t.id)
        val due = t.due ?: return
        if (t.done || t.remindBefore < 0) return
        Alarms.schedule(ctx, "task", t.id, due - t.remindBefore * 60_000L, "Task due", t.title)
    }

    fun syncReminder(ctx: Context, r: Reminder) {
        Alarms.cancel(ctx, "reminder", r.id)
        if (r.done) return
        Alarms.schedule(ctx, "reminder", r.id, r.time, r.title, kindLabel(r.kind))
    }

    fun syncEvent(ctx: Context, e: Event) {
        Alarms.cancel(ctx, "event", e.id)
        if (e.remindBefore < 0) return
        Alarms.schedule(ctx, "event", e.id, eventStart(e) - e.remindBefore * 60_000L, if (e.kind == 1) "Exam coming up" else "Upcoming", e.title)
    }

    fun cancel(ctx: Context, type: String, id: Long) = Alarms.cancel(ctx, type, id)

    fun rescheduleAll(ctx: Context, store: StudyStore) {
        store.tasks.items.value.forEach { syncTask(ctx, it) }
        store.reminders.items.value.forEach { syncReminder(ctx, it) }
        store.events.items.value.forEach { syncEvent(ctx, it) }
    }

    fun kindLabel(kind: Int) = when (kind) { 1 -> "Assignment deadline"; 2 -> "Exam"; else -> "Reminder" }
}
