package com.margin.launcher.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.margin.launcher.LauncherViewModel
import com.margin.launcher.UiState
import com.margin.launcher.core.*
import com.margin.launcher.ui.components.*
import com.margin.launcher.ui.theme.M
import java.time.LocalDate
import java.time.format.TextStyle as DowStyle
import java.util.Locale

@Composable
fun StudyScreen(vm: LauncherViewModel, state: UiState, onBack: () -> Unit) {
    val c = M.colors
    val store = vm.store
    val s = state.settings
    val sessions by store.sessions.items.collectAsState()
    val today = LocalDate.now()
    val perDay = minutesPerDay(sessions)
    val week = (6 downTo 0).map { today.minusDays(it.toLong()) }
    val weekTotal = week.sumOf { perDay[it] ?: 0 }
    val todayMin = perDay[today] ?: 0
    val maxBar = maxOf(s.studyDailyMin, week.maxOf { perDay[it] ?: 0 }, 1)
    var logging by remember { mutableStateOf(false) }

    val bySubject = sessions.filter { val d = TimeUtil.toDate(it.start); !d.isBefore(week.first()) && !d.isAfter(today) }
        .groupBy { it.subject.ifEmpty { "Unassigned" } }.mapValues { e -> e.value.sumOf { it.minutes } }
        .entries.sortedByDescending { it.value }

    Page("Study", onBack, action = { Btn("+ Log time", { logging = true }, primary = false) }) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Today", fontSize = 14.sp, color = c.secondary)
            Text(fmtDuration(todayMin), fontSize = 44.sp, fontWeight = FontWeight.Light)
            ProgressBar(todayMin / s.studyDailyMin.toFloat())
            Text("Goal ${fmtDuration(s.studyDailyMin)} a day", fontSize = 13.sp, color = c.secondary)

            Label("This week", Modifier.padding(top = 12.dp))
            Text("${fmtDuration(weekTotal)} of ${fmtDuration(s.studyWeeklyMin)}", fontSize = 20.sp)
            ProgressBar(weekTotal / s.studyWeeklyMin.toFloat())

            Row(Modifier.fillMaxWidth().height(130.dp).padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Bottom) {
                week.forEach { d ->
                    val m = perDay[d] ?: 0
                    Column(Modifier.weight(1f).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                        Box(Modifier.fillMaxWidth(0.6f).fillMaxHeight((m / maxBar.toFloat()).coerceIn(0.02f, 0.85f))
                            .clip(RoundedCornerShape(5.dp)).background(if (d == today) c.accent else c.surface))
                        Text(d.dayOfWeek.getDisplayName(DowStyle.NARROW, Locale.getDefault()), fontSize = 12.sp, color = c.secondary, modifier = Modifier.padding(top = 4.dp))
                    }
                }
            }

            Label("By subject", Modifier.padding(top = 12.dp))
            if (bySubject.isEmpty()) Text("Start a focus session or log time to see this.", color = c.secondary)
            bySubject.forEach { (name, m) ->
                Row { Text(name, fontSize = 16.sp, modifier = Modifier.weight(1f)); Text(fmtDuration(m), fontSize = 14.sp, color = c.secondary) }
                ProgressBar(m / maxOf(bySubject.first().value, 1).toFloat())
            }

            Label("Goals", Modifier.padding(top = 12.dp))
            Text("Daily", fontSize = 14.sp, color = c.secondary)
            Chips { listOf(30, 60, 90, 120, 180, 240).forEach { m -> Chip(fmtDuration(m), s.studyDailyMin == m) { vm.setStudyDaily(m) } } }
            Text("Weekly", fontSize = 14.sp, color = c.secondary)
            Chips { listOf(180, 300, 600, 900, 1200).forEach { m -> Chip(fmtDuration(m), s.studyWeeklyMin == m) { vm.setStudyWeekly(m) } } }
            Spacer(Modifier.height(24.dp))
        }
    }

    if (logging) {
        var subject by remember { mutableStateOf("") }
        var minutes by remember { mutableStateOf("30") }
        Sheet({ logging = false }) {
            Text("Log study time", fontSize = 20.sp, fontWeight = FontWeight.Medium)
            Label("Subject")
            SubjectPicker(store, subject) { subject = it }
            Field(minutes, { minutes = it.filter(Char::isDigit).take(3) }, "Minutes", keyboardType = KeyboardType.Number)
            Btn("Save", {
                val m = minutes.toIntOrNull() ?: 0
                if (m > 0) {
                    store.sessions.upsert(FocusSession(Ids.next(), System.currentTimeMillis() - m * 60_000L, m, subject))
                    logging = false
                }
            }, Modifier.fillMaxWidth())
        }
    }
}
