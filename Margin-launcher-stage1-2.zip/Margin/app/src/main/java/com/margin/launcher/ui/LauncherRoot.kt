package com.margin.launcher.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.margin.launcher.LauncherViewModel
import com.margin.launcher.Screen
import com.margin.launcher.data.AppInfo
import com.margin.launcher.system.FocusEngine
import com.margin.launcher.ui.components.AppMenu
import com.margin.launcher.ui.components.Btn
import com.margin.launcher.ui.components.Sheet
import com.margin.launcher.ui.drawer.DrawerScreen
import com.margin.launcher.ui.home.HomeScreen
import com.margin.launcher.ui.screens.*
import com.margin.launcher.ui.settings.SettingsScreen
import com.margin.launcher.ui.theme.M
import com.margin.launcher.ui.theme.MarginTheme

@Composable
fun LauncherRoot(vm: LauncherViewModel) {
    val state by vm.state.collectAsStateWithLifecycle()
    val screen by vm.screen.collectAsStateWithLifecycle()
    val query by vm.query.collectAsStateWithLifecycle()
    val focus by FocusEngine.state.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    val kb = LocalSoftwareKeyboardController.current
    var menuApp by remember { mutableStateOf<AppInfo?>(null) }
    var pending by remember { mutableStateOf<AppInfo?>(null) }

    // During a focus phase, ask before opening apps the user marked as distracting.
    val launch: (AppInfo) -> Unit = { app ->
        kb?.hide()
        if (focus.active && focus.phase == 0 && !focus.paused && app.key in state.settings.distracting) pending = app
        else vm.launch(app)
    }
    val close: () -> Unit = { kb?.hide(); vm.goHome() }
    val s = state.settings

    MarginTheme(s.themeMode, s.accent, s.fontScale) {
        // On the home screen Back does nothing: a launcher must never exit.
        BackHandler { close() }

        Box(Modifier.fillMaxSize().background(M.colors.bg)) {
            HomeScreen(
                state = state, repo = vm.repo, store = vm.store, enabled = screen == Screen.HOME,
                onOpenDrawer = vm::openDrawer, onOpenSettings = vm::openSettings,
                onSwipeDown = { if (s.swipeDown == 0) vm.go(Screen.QUICK) else SystemActions.expandShade(ctx) },
                onNavigate = vm::go, onLaunch = launch, onDockMenu = { menuApp = it },
            )
            AnimatedVisibility(
                visible = screen == Screen.DRAWER,
                enter = slideInVertically { it / 3 } + fadeIn(),
                exit = slideOutVertically { it / 3 } + fadeOut(),
            ) {
                DrawerScreen(state, vm.repo, query, vm::setQuery, close, launch) { menuApp = it }
            }
            AnimatedVisibility(
                visible = screen == Screen.SETTINGS,
                enter = slideInHorizontally { it / 4 } + fadeIn(),
                exit = slideOutHorizontally { it / 4 } + fadeOut(),
            ) {
                SettingsScreen(state = state, vm = vm, onClose = close)
            }
            AnimatedContent(
                targetState = screen,
                transitionSpec = { fadeIn(tween(160)) togetherWith fadeOut(tween(120)) },
                label = "pages",
            ) { target ->
                when (target) {
                    Screen.QUICK -> QuickPanel(vm, state, close)
                    Screen.TASKS -> TasksScreen(vm, state, close)
                    Screen.NOTES -> NotesScreen(vm, state, close)
                    Screen.REMINDERS -> RemindersScreen(vm, state, close)
                    Screen.PLANNER -> PlannerScreen(vm, state, close)
                    Screen.FOCUS -> FocusScreen(vm, state, close)
                    Screen.STUDY -> StudyScreen(vm, state, close)
                    Screen.JOURNAL -> JournalScreen(vm, state, close)
                    Screen.WELLBEING -> WellbeingScreen(vm, state, close)
                    Screen.TOOLS -> ToolsScreen(vm, state, close)
                    else -> Spacer(Modifier.size(0.dp))
                }
            }
        }

        menuApp?.let { app ->
            AppMenu(
                app = app,
                inDock = state.dock.any { it.key == app.key },
                onDismiss = { menuApp = null },
                onToggleDock = { vm.toggleDock(app.key) },
                onHide = { vm.hide(app.key) },
                onInfo = { SystemActions.appInfo(ctx, app.packageName) },
                onUninstall = { SystemActions.uninstall(ctx, app.packageName) },
            )
        }

        pending?.let { app ->
            Sheet(onDismiss = { pending = null }) {
                Text("You're in a focus session", fontSize = 20.sp, fontWeight = FontWeight.Medium)
                Text("Open ${app.label} anyway? It will be noted as an interruption.", fontSize = 16.sp, color = M.colors.secondary)
                Btn("Stay focused", { pending = null }, Modifier.fillMaxWidth())
                Btn("Open anyway", { FocusEngine.noteInterruption(); vm.launch(app); pending = null }, Modifier.fillMaxWidth(), primary = false)
            }
        }
    }
}
