package com.margin.launcher.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.margin.launcher.LauncherViewModel
import com.margin.launcher.Screen
import com.margin.launcher.data.AppInfo
import com.margin.launcher.system.FocusEngine
import com.margin.launcher.ui.components.*
import com.margin.launcher.ui.drawer.DrawerScreen
import com.margin.launcher.ui.home.HomeScreen
import com.margin.launcher.ui.screens.*
import com.margin.launcher.ui.settings.SettingsScreen
import com.margin.launcher.ui.theme.M
import com.margin.launcher.ui.theme.MarginTheme

@Composable
fun LauncherRoot(vm: LauncherViewModel) {
    val state by vm.state.collectAsStateWithLifecycle()
    val screen by vm.screen.collectAsStateWithLifecycle()
    val query by vm.query.collectAsStateWithLifecycle()
    val focus by FocusEngine.state.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    val kb = LocalSoftwareKeyboardController.current
    var menuApp by remember { mutableStateOf<AppInfo?>(null) }
    var pending by remember { mutableStateOf<AppInfo?>(null) }
    var focusSheet by remember { mutableStateOf(false) }

    // During a focus phase, ask before opening apps the user marked as distracting.
    val launch: (AppInfo) -> Unit = { app ->
        kb?.hide()
        if (focus.active && focus.phase == 0 && !focus.paused && app.key in state.settings.distracting) pending = app
        else vm.launch(app)
    }
    val close: () -> Unit = { kb?.hide(); focusSheet = false; vm.goHome() }
    val s = state.settings

    MarginTheme(s.themeMode, s.accent, s.fontScale) {
        // On the home screen Back does nothing: a launcher must never exit.
        BackHandler { if (focusSheet) focusSheet = false else close() }

        Box(Modifier.fillMaxSize().glassBackground()) {
            HomeScreen(
                state = state, repo = vm.repo, store = vm.store, enabled = screen == Screen.HOME && !focusSheet,
                onOpenDrawer = vm::openDrawer, onOpenSettings = vm::openSettings,
                onSwipeDown = { if (s.swipeDown == 0) vm.go(Screen.QUICK) else SystemActions.expandShade(ctx) },
                onNavigate = vm::go,
                onOpenFocus = { if (focus.active) vm.go(Screen.FOCUS) else focusSheet = true },
                onOpenSearch = { vm.go(Screen.SEARCH) },
                onLaunch = launch, onDockMenu = { menuApp = it },
            )
            AnimatedVisibility(
                visible = screen == Screen.DRAWER,
                enter = slideInVertically(spring(dampingRatio = 0.9f, stiffness = 400f)) { it / 4 } + fadeIn(tween(180)),
                exit = slideOutVertically(tween(160)) { it / 4 } + fadeOut(tween(140)),
            ) {
                DrawerScreen(state, vm.repo, query, vm::setQuery, close, launch) { menuApp = it }
            }
            AnimatedVisibility(
                visible = screen == Screen.SETTINGS,
                enter = slideInHorizontally(tween(220)) { it / 5 } + fadeIn(tween(200)),
                exit = slideOutHorizontally(tween(160)) { it / 5 } + fadeOut(tween(140)),
            ) {
                SettingsScreen(state = state, vm = vm, onClose = close)
            }
            AnimatedContent(
                targetState = screen,
                transitionSpec = {
                    (fadeIn(tween(200)) + scaleIn(tween(220), initialScale = 0.97f)) togetherWith fadeOut(tween(120))
                },
                label = "pages",
            ) { target ->
                when (target) {
                    Screen.SEARCH -> SearchScreen(vm, state, close, launch)
                    Screen.QUICK -> QuickPanel(vm, state, close)
                    Screen.TASKS -> TasksScreen(vm, state, close)
                    Screen.NOTES -> NotesScreen(vm, state, close)
                    Screen.REMINDERS -> RemindersScreen(vm, state, close)
                    Screen.PLANNER -> PlannerScreen(vm, state, close)
                    Screen.FOCUS -> FocusScreen(vm, state, close)
                    Screen.STUDY -> StudyScreen(vm, state, close)
                    Screen.JOURNAL -> JournalScreen(vm, state, close)
                    Screen.WELLBEING -> WellbeingScreen(vm, state, close)
                    Screen.TOOLS -> ToolsScreen(vm, state, close)
                    else -> Spacer(Modifier.size(0.dp))
                }
            }

            // Quick Focus: opens over the home screen from the Focus button.
            GlassBottomSheet(visible = focusSheet && screen == Screen.HOME, onDismiss = { focusSheet = false }) {
                Text("Start focusing", fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                FocusStarter(vm, state, compact = true) { focusSheet = false; vm.go(Screen.FOCUS) }
            }
        }

        menuApp?.let { app ->
            AppMenu(
                app = app,
                inDock = state.dock.any { it.key == app.key },
                onDismiss = { menuApp = null },
                onToggleDock = { vm.toggleDock(app.key) },
                onHide = { vm.hide(app.key) },
                onInfo = { SystemActions.appInfo(ctx, app.packageName) },
                onUninstall = { SystemActions.uninstall(ctx, app.packageName) },
            )
        }

        pending?.let { app ->
            Sheet(onDismiss = { pending = null }) {
                Text("You're in a focus session", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                Text("Open ${app.label} anyway? It will be noted as an interruption.", fontSize = 16.sp, color = M.colors.secondary)
                Btn("Stay focused", { pending = null }, Modifier.fillMaxWidth())
                Btn("Open anyway", { FocusEngine.noteInterruption(); vm.launch(app); pending = null }, Modifier.fillMaxWidth(), primary = false)
            }
        }
    }
}
