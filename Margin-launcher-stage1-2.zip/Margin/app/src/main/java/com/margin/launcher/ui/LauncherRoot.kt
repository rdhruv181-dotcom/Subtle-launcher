package com.margin.launcher.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.margin.launcher.LauncherViewModel
import com.margin.launcher.Screen
import com.margin.launcher.data.AppInfo
import com.margin.launcher.ui.components.AppMenu
import com.margin.launcher.ui.drawer.DrawerScreen
import com.margin.launcher.ui.home.HomeScreen
import com.margin.launcher.ui.settings.SettingsScreen
import com.margin.launcher.ui.theme.M
import com.margin.launcher.ui.theme.MarginTheme

@Composable
fun LauncherRoot(vm: LauncherViewModel) {
    val state by vm.state.collectAsStateWithLifecycle()
    val screen by vm.screen.collectAsStateWithLifecycle()
    val query by vm.query.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    val kb = LocalSoftwareKeyboardController.current
    var menuApp by remember { mutableStateOf<AppInfo?>(null) }

    val launch: (AppInfo) -> Unit = { kb?.hide(); vm.launch(it) }
    val close: () -> Unit = { kb?.hide(); vm.goHome() }

    MarginTheme(state.settings.themeMode, state.settings.accent) {
        // On the home screen Back does nothing: a launcher must never exit.
        BackHandler { close() }

        Box(Modifier.fillMaxSize().background(M.colors.bg)) {
            HomeScreen(
                state = state, repo = vm.repo, enabled = screen == Screen.HOME,
                onOpenDrawer = vm::openDrawer, onOpenSettings = vm::openSettings,
                onLaunch = launch, onDockMenu = { menuApp = it },
            )
            AnimatedVisibility(
                visible = screen == Screen.DRAWER,
                enter = slideInVertically { it / 3 } + fadeIn(),
                exit = slideOutVertically { it / 3 } + fadeOut(),
            ) {
                DrawerScreen(
                    state = state, repo = vm.repo, query = query, onQuery = vm::setQuery,
                    onClose = close, onLaunch = launch, onMenu = { menuApp = it },
                )
            }
            AnimatedVisibility(
                visible = screen == Screen.SETTINGS,
                enter = slideInHorizontally { it / 4 } + fadeIn(),
                exit = slideOutHorizontally { it / 4 } + fadeOut(),
            ) {
                SettingsScreen(state = state, vm = vm, onClose = close)
            }
        }

        menuApp?.let { app ->
            AppMenu(
                app = app,
                inDock = state.dock.any { it.key == app.key },
                onDismiss = { menuApp = null },
                onToggleDock = { vm.toggleDock(app.key) },
                onHide = { vm.hide(app.key) },
                onInfo = { SystemActions.appInfo(ctx, app.packageName) },
                onUninstall = { SystemActions.uninstall(ctx, app.packageName) },
            )
        }
    }
}
