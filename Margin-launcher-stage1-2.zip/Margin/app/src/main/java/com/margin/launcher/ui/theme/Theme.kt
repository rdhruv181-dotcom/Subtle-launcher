package com.margin.launcher.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import com.margin.launcher.data.ThemeMode

/** Swap for Inter by adding res/font/inter_*.ttf and building a FontFamily(Font(R.font...)). */
val AppFont: FontFamily = FontFamily.Default

@Immutable
data class MColors(
    val bg: Color,
    val surface: Color,
    val text: Color,
    val secondary: Color,
    val hairline: Color,
    val accent: Color,
    val onAccent: Color,
    val dark: Boolean,
)

val Accents: List<Pair<String, Color>> = listOf(
    "Clay" to Color(0xFFB5603A),
    "Moss" to Color(0xFF5E7A52),
    "Ink" to Color(0xFF3E5C8A),
    "Plum" to Color(0xFF7B5A86),
    "Graphite" to Color(0xFF5A5A5A),
)

private fun lightColors(a: Color) = MColors(
    bg = Color(0xFFF6F3EE), surface = Color(0xFFECE8E1), text = Color(0xFF1C1C1E),
    secondary = Color(0xFF8A857E), hairline = Color(0x1A000000), accent = a,
    onAccent = Color.White, dark = false,
)

// True black background for OLED.
private fun darkColors(a: Color) = MColors(
    bg = Color.Black, surface = Color(0xFF141414), text = Color(0xFFF2F0EC),
    secondary = Color(0xFF8E8A85), hairline = Color(0x1FFFFFFF),
    accent = lerp(a, Color.White, 0.25f), onAccent = Color.Black, dark = true,
)

val LocalMColors = staticCompositionLocalOf { lightColors(Accents[0].second) }

object M {
    val colors: MColors
        @Composable @ReadOnlyComposable get() = LocalMColors.current
}

object Radius { val card = 16.dp; val small = 12.dp }

@Composable
fun MarginTheme(mode: ThemeMode, accentIndex: Int, content: @Composable () -> Unit) {
    val dark = when (mode) {
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
    }
    val accent = Accents.getOrElse(accentIndex) { Accents[0] }.second
    val colors = if (dark) darkColors(accent) else lightColors(accent)

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            val c = WindowCompat.getInsetsController(window, view)
            c.isAppearanceLightStatusBars = !dark
            c.isAppearanceLightNavigationBars = !dark
        }
    }

    val scheme = if (dark) {
        darkColorScheme(primary = colors.accent, onPrimary = colors.onAccent, background = colors.bg,
            surface = colors.surface, onSurface = colors.text)
    } else {
        lightColorScheme(primary = colors.accent, onPrimary = colors.onAccent, background = colors.bg,
            surface = colors.surface, onSurface = colors.text)
    }

    MaterialTheme(colorScheme = scheme) {
        CompositionLocalProvider(LocalMColors provides colors, LocalContentColor provides colors.text) {
            ProvideTextStyle(TextStyle(fontFamily = AppFont, color = colors.text), content)
        }
    }
}
