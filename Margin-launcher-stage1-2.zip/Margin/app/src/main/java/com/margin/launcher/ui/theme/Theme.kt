package com.margin.launcher.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import com.margin.launcher.data.ThemeMode

/** Swap for Inter by adding res/font/inter_*.ttf and building a FontFamily(Font(R.font...)). */
val AppFont: FontFamily = FontFamily.Default

/**
 * Design tokens for the frosted-glass look.
 * bg is an opaque base colour; surface / surfaceStrong are translucent glass fills meant to sit on the
 * ambient background drawn by Modifier.glassBackground().
 */
@Immutable
data class MColors(
    val bg: Color,
    val surface: Color,
    val surfaceStrong: Color,
    val text: Color,
    val secondary: Color,
    val hairline: Color,
    val accent: Color,
    val onAccent: Color,
    val alert: Color,
    val borderTop: Color,
    val borderBottom: Color,
    val highlight: Color,
    val bgTop: Color,
    val bgMid: Color,
    val bgBottom: Color,
    val glowA: Color,
    val glowB: Color,
    val glowC: Color,
    val dark: Boolean,
)

val Accents: List<Pair<String, Color>> = listOf(
    "Azure" to Color(0xFF4C8DFF),
    "Violet" to Color(0xFF8A6CFF),
    "Teal" to Color(0xFF22B8B0),
    "Rose" to Color(0xFFFF6B8A),
    "Amber" to Color(0xFFFFB347),
)

private fun onColor(accent: Color) = if (accent.luminance() > 0.5f) Color(0xFF10121F) else Color.White

private fun darkColors(a: Color) = MColors(
    bg = Color(0xFF070A1A),
    surface = Color.White.copy(alpha = 0.08f),
    surfaceStrong = Color.White.copy(alpha = 0.14f),
    text = Color(0xFFF4F5FF),
    secondary = Color(0xFF9EA4C4),
    hairline = Color.White.copy(alpha = 0.12f),
    accent = a, onAccent = onColor(a), alert = Color(0xFFFF5A52),
    borderTop = Color.White.copy(alpha = 0.22f), borderBottom = Color.White.copy(alpha = 0.06f),
    highlight = Color.White.copy(alpha = 0.08f),
    bgTop = Color(0xFF0B1235), bgMid = Color(0xFF070816), bgBottom = Color(0xFF051218),
    glowA = Color(0xFF3550D8), glowB = Color(0xFF7A3CC8), glowC = Color(0xFF14A3A8),
    dark = true,
)

private fun lightColors(a: Color) = MColors(
    bg = Color(0xFFEFF2FF),
    surface = Color.White.copy(alpha = 0.60f),
    surfaceStrong = Color.White.copy(alpha = 0.82f),
    text = Color(0xFF12142B),
    secondary = Color(0xFF565C7C),
    hairline = Color(0xFF5B64A8).copy(alpha = 0.18f),
    accent = a, onAccent = onColor(a), alert = Color(0xFFD0382E),
    borderTop = Color.White.copy(alpha = 0.95f), borderBottom = Color(0xFF8A93C9).copy(alpha = 0.28f),
    highlight = Color.White.copy(alpha = 0.55f),
    bgTop = Color(0xFFDCE6FF), bgMid = Color(0xFFF3EEFF), bgBottom = Color(0xFFE3F6F5),
    glowA = Color(0xFF9DB4FF), glowB = Color(0xFFC9A8FF), glowC = Color(0xFF8FE3DA),
    dark = false,
)

val LocalMColors = staticCompositionLocalOf { darkColors(Accents[0].second) }

object M {
    val colors: MColors
        @Composable @ReadOnlyComposable get() = LocalMColors.current
}

object Radius { val card = 28.dp; val small = 16.dp }

@Composable
fun MarginTheme(mode: ThemeMode, accentIndex: Int, fontScale: Float, content: @Composable () -> Unit) {
    val dark = when (mode) {
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
    }
    val accent = Accents.getOrElse(accentIndex) { Accents[0] }.second
    val colors = if (dark) darkColors(accent) else lightColors(accent)

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            val c = WindowCompat.getInsetsController(window, view)
            c.isAppearanceLightStatusBars = !dark
            c.isAppearanceLightNavigationBars = !dark
        }
    }

    val scheme = if (dark) {
        darkColorScheme(primary = colors.accent, onPrimary = colors.onAccent, background = colors.bg,
            surface = colors.bg, onSurface = colors.text)
    } else {
        lightColorScheme(primary = colors.accent, onPrimary = colors.onAccent, background = colors.bg,
            surface = colors.bg, onSurface = colors.text)
    }

    MaterialTheme(colorScheme = scheme) {
        val density = LocalDensity.current
        CompositionLocalProvider(
            LocalMColors provides colors,
            LocalContentColor provides colors.text,
            LocalDensity provides Density(density.density, density.fontScale * fontScale),
        ) {
            ProvideTextStyle(TextStyle(fontFamily = AppFont, color = colors.text), content)
        }
    }
}
