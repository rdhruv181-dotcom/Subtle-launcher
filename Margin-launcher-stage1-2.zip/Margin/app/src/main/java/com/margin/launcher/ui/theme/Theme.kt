package com.margin.launcher.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import com.margin.launcher.R
import com.margin.launcher.data.ThemeMode

/** Inter (SIL Open Font License): the closest free match to Apple's SF Pro. */
val AppFont: FontFamily = FontFamily(
    Font(R.font.inter_light, FontWeight.Light),
    Font(R.font.inter_regular, FontWeight.Normal),
    Font(R.font.inter_medium, FontWeight.Medium),
    Font(R.font.inter_semibold, FontWeight.SemiBold),
    Font(R.font.inter_bold, FontWeight.Bold),
)

/** iOS system colours (dark-mode variants), used for icon tiles and list colours. */
object IOS {
    val Blue = Color(0xFF0A84FF)
    val Green = Color(0xFF30D158)
    val Red = Color(0xFFFF453A)
    val Orange = Color(0xFFFF9F0A)
    val Yellow = Color(0xFFFFD60A)
    val Purple = Color(0xFFBF5AF2)
    val Teal = Color(0xFF40C8E0)
    val Pink = Color(0xFFFF375F)
    val Indigo = Color(0xFF5E5CE6)
    val Gray = Color(0xFF8E8E93)
}

/**
 * Design tokens for the frosted-glass look.
 * bg is an opaque base colour; surface / surfaceStrong are translucent glass fills meant to sit on the
 * ambient background drawn by Modifier.glassBackground().
 */
@Immutable
data class MColors(
    val bg: Color,
    val surface: Color,
    val surfaceStrong: Color,
    val text: Color,
    val secondary: Color,
    val hairline: Color,
    val accent: Color,
    val onAccent: Color,
    val alert: Color,
    val borderTop: Color,
    val borderBottom: Color,
    val highlight: Color,
    val bgTop: Color,
    val bgMid: Color,
    val bgBottom: Color,
    val glowA: Color,
    val glowB: Color,
    val glowC: Color,
    val dark: Boolean,
)

val Accents: List<Pair<String, Color>> = listOf(
    "Blue" to IOS.Blue,
    "Purple" to IOS.Purple,
    "Green" to IOS.Green,
    "Pink" to IOS.Pink,
    "Orange" to IOS.Orange,
)

private fun onColor(accent: Color) = if (accent.luminance() > 0.5f) Color(0xFF10121F) else Color.White

private fun darkColors(a: Color) = MColors(
    bg = Color(0xFF070A1A),
    surface = Color.White.copy(alpha = 0.08f),
    surfaceStrong = Color.White.copy(alpha = 0.14f),
    text = Color(0xFFF4F5FF),
    secondary = Color(0xFF9C9CB5),
    hairline = Color.White.copy(alpha = 0.12f),
    accent = a, onAccent = onColor(a), alert = IOS.Red,
    borderTop = Color.White.copy(alpha = 0.22f), borderBottom = Color.White.copy(alpha = 0.06f),
    highlight = Color.White.copy(alpha = 0.08f),
    bgTop = Color(0xFF0C0E2B), bgMid = Color(0xFF07050F), bgBottom = Color(0xFF030307),
    glowA = Color(0xFF2B2A9C), glowB = Color(0xFF6A2DB8), glowC = Color(0xFF3B1A70),
    dark = true,
)

private fun lightColors(a: Color) = MColors(
    bg = Color(0xFFEFF2FF),
    surface = Color.White.copy(alpha = 0.60f),
    surfaceStrong = Color.White.copy(alpha = 0.82f),
    text = Color(0xFF12142B),
    secondary = Color(0xFF565C7C),
    hairline = Color(0xFF5B64A8).copy(alpha = 0.18f),
    accent = a, onAccent = onColor(a), alert = Color(0xFFD0382E),
    borderTop = Color.White.copy(alpha = 0.95f), borderBottom = Color(0xFF8A93C9).copy(alpha = 0.28f),
    highlight = Color.White.copy(alpha = 0.55f),
    bgTop = Color(0xFFDCE6FF), bgMid = Color(0xFFF3EEFF), bgBottom = Color(0xFFE3F6F5),
    glowA = Color(0xFF9DB4FF), glowB = Color(0xFFC9A8FF), glowC = Color(0xFF8FE3DA),
    dark = false,
)

val LocalMColors = staticCompositionLocalOf { darkColors(Accents[0].second) }

object M {
    val colors: MColors
        @Composable @ReadOnlyComposable get() = LocalMColors.current
}

object Radius { val card = 28.dp; val small = 16.dp }

@Composable
fun MarginTheme(mode: ThemeMode, accentIndex: Int, fontScale: Float, content: @Composable () -> Unit) {
    val dark = when (mode) {
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
    }
    val accent = Accents.getOrElse(accentIndex) { Accents[0] }.second
    val colors = if (dark) darkColors(accent) else lightColors(accent)

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            val c = WindowCompat.getInsetsController(window, view)
            c.isAppearanceLightStatusBars = !dark
            c.isAppearanceLightNavigationBars = !dark
        }
    }

    val scheme = if (dark) {
        darkColorScheme(primary = colors.accent, onPrimary = colors.onAccent, background = colors.bg,
            surface = colors.bg, onSurface = colors.text)
    } else {
        lightColorScheme(primary = colors.accent, onPrimary = colors.onAccent, background = colors.bg,
            surface = colors.bg, onSurface = colors.text)
    }

    MaterialTheme(colorScheme = scheme) {
        val density = LocalDensity.current
        CompositionLocalProvider(
            LocalMColors provides colors,
            LocalContentColor provides colors.text,
            LocalDensity provides Density(density.density, density.fontScale * fontScale),
        ) {
            ProvideTextStyle(TextStyle(fontFamily = AppFont, color = colors.text), content)
        }
    }
}
